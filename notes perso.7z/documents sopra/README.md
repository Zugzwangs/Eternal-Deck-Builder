# cloud_formation_infra
Repository contains all CloudFormation templates required to build Insider protection infrasctructure.


# branch strategy:
   * On master: lastest prod infra version
   * On dev: latest non-prod infra version
   * Other branch: alternative infra version, POC, new stuff
     ...

# folder strategy:
Template are organized into several folders at top level:
   * s3
   * EC2

import boto3
import unittest
import json
from moto import mock_dynamodb2, mock_cloudformation, mock_ec2
from global_config import ROOT_DIR
from os.path import join

DYNAMO_TEMPLATE_PATH = join(ROOT_DIR, "resources/storage/dynamodb/")


class dynamodb_mock:

    def __init__(self):
        self.db = boto3.resource('dynamodb',
                            'eu-west-1',
                            aws_access_key_id="whatever",
                            aws_secret_access_key="whatever")
        # create AlgorithmExecutionStatus Table
        with open(DYNAMO_TEMPLATE_PATH+"dynamodb_alg_execution_status.json") as file:
            j = json.load(file)
            self.db.create_table(**self.parse_json_cf_template(j))
        # create AlgorithmExecutionRecipe
        with open(DYNAMO_TEMPLATE_PATH + "dynamodb_alg_execution_recipe.json") as file:
            j = json.load(file)
            self.db.create_table(**self.parse_json_cf_template(j))
        # create AnomalyCaseIngestionManagement
        with open(DYNAMO_TEMPLATE_PATH + "dynamodb_ac_ingestion_management.json") as file:
            j = json.load(file)
            db.create_table(**parse_json_cf_template(j))
        # create IndexIngestionManagement
        with open(DYNAMO_TEMPLATE_PATH + "dynamodb_index_ingestion_management.json") as file:
            j = json.load(file)
            self.db.create_table(**self.parse_json_cf_template(j))
        # create IndexConfiguration
        with open(DYNAMO_TEMPLATE_PATH + "dynamodb_index_configuration.json") as file:
            j = json.load(file)
            db.create_table(**parse_json_cf_template(j))

    @staticmethod
    def parse_json_cf_template(json_):
        parsed_dict = dict()
        parsed_dict["TableName"] = json_["Resources"]["DynamoDb"]["Properties"]["TableName"]["Ref"]
        parsed_dict["KeySchema"] = json_["Resources"]["DynamoDb"]["Properties"]["KeySchema"]
        parsed_dict["AttributeDefinitions"] = json_["Resources"]["DynamoDb"]["Properties"]["AttributeDefinitions"]
        return parsed_dict


from test.mock.dynamodb_mock import dynamodb_mock
from global_config import ROOT_DIR
import sys
import json
import boto3
from moto import mock_ec2, mock_dynamodb2, mock_cloudformation, mock_sns
from moto.ec2 import ec2_backend
from os.path import join
sys.path.append(join(ROOT_DIR, "resources/computation/orchestration/lambda/code/computing_job_completion_management/"))

from instance_handler import InstanceHandler
from storage import StorageHandler
from main import LambdaHandler
from configuration import *
import unittest


class TestStorageHandler(unittest.TestCase):

    @mock_dynamodb2
    def test_table_names(self):
        """
        Test that the names of the tables in the config file correspond to the names in the json template of the
        dynamodb tables.
        """
        dynamodb = dynamodb_mock().db
        table_list = [x.name for x in list(dynamodb.tables.all())]
        self.assertTrue(ANOMALY_CASE_TABLE in table_list)
        self.assertTrue(AC_STEPS_TABLE in table_list)

    @mock_dynamodb2
    def test_set_ac_step_status(self):
        dynamodb = dynamodb_mock().db
        storage_handler = StorageHandler()
        storage_handler.db = dynamodb
        # Check no data in the table
        r = dynamodb.Table(ANOMALY_CASE_TABLE).scan()
        self.assertEqual(r["Count"], 0)
        # Create message
        message = {DATE_ANOMALY_STEP_DB: "2020-01-01:AC_TEST:fit:results", STATUS_DB: "success", DURATION_DB: "10"}
        # Run the tested function
        storage_handler.set_ac_step_status(message)
        # Check data properly recorded
        r = dynamodb.Table(ANOMALY_CASE_TABLE).scan()
        self.assertEqual(r["Count"], 1)
        self.assertEqual(r["Items"][0], message)

    @mock_dynamodb2
    def test_get_ac_steps(self):
        dynamodb = dynamodb_mock().db
        storage_handler = StorageHandler()
        storage_handler.db = dynamodb
        # Check no data in the table
        r = dynamodb.Table(AC_STEPS_TABLE).scan()
        self.assertEqual(r["Count"], 0)
        # Add one row of data
        message = {"anomaly_case": "AC_test", "steps": ["results"]}
        dynamodb.Table(AC_STEPS_TABLE).put_item(
            Item=message
        )
        r = dynamodb.Table(AC_STEPS_TABLE).scan()
        self.assertEqual(r["Count"], 1)
        # Run the tested function
        ac_steps = storage_handler.get_ac_steps("AC_test")
        # Check data properly get
        self.assertEqual(ac_steps, ["results"])

    @mock_dynamodb2
    def test_get_ac_step_status(self):
        dynamodb = dynamodb_mock().db
        storage_handler = StorageHandler()
        storage_handler.db = dynamodb
        # Check no data in the table
        r = dynamodb.Table(ANOMALY_CASE_TABLE).scan()
        self.assertEqual(r["Count"], 0)
        # Add one row of data
        message = {DATE_ANOMALY_STEP_DB: "2020-01-01:AC_TEST:fit:results", STATUS_DB: "success", DURATION_DB: "10"}
        dynamodb.Table(ANOMALY_CASE_TABLE).put_item(
            Item=message
        )
        r = dynamodb.Table(ANOMALY_CASE_TABLE).scan()
        self.assertEqual(r["Count"], 1)
        # Run the tested function
        ac_step_status = storage_handler.get_ac_step_status("2020-01-01:AC_TEST:fit:results")
        # Check data properly get
        self.assertEqual(ac_step_status, "success")


class TestInstanceHandler(unittest.TestCase):


    @mock_ec2
    def test_stop_instance(self):
        ## Initiate test
        # create EC2 client
        ec2_client = boto3.client("ec2", REGION)
        # assert there is no ec2 instance running
        self.assertEqual(len(ec2_client.describe_instances()["Reservations"]), 0)
        # Create EC2 instance
        ec2_client.run_instances(ImageId='ami-03cf127a', MinCount=1, MaxCount=1)
        # assert Creation of the instance
        self.assertEqual(len(ec2_client.describe_instances()["Reservations"][0]["Instances"]), 1)
        # assert the instance is running
        self.assertEqual(ec2_client.describe_instances()["Reservations"][0]["Instances"][0]["State"]["Name"], "running")
        # get ID of the created ec2 instance
        instance_id = ec2_client.describe_instances()["Reservations"][0]["Instances"][0]["InstanceId"]

        ## Run test
        # Instanciate instance_handler
        instance_handler = InstanceHandler()
        # Set the ec2 client
        instance_handler.ec2 = ec2_client
        # test the stop_instance function
        instance_handler.stop_instance([instance_id])

        ## Assert instance is stoppped
        self.assertEqual(ec2_client.describe_instances()["Reservations"][0]["Instances"][0]["State"]["Name"], "stopped")

    @mock_cloudformation
    def test_delete_cfn(self):
        # Instanciate cloudformation client
        cf_client = boto3.client('cloudformation', region_name=REGION)
        # Assert no stack exist
        self.assertEqual(len(cf_client.describe_stacks()["Stacks"]), 0)
        # Loading cloud formation template
        with open("stack.json") as file:
            template = json.load(file)
        # Creating the stack
        cf_client.create_stack(StackName="testStack", TemplateBody=str(template))
        # assert stack is created
        self.assertEqual(len(cf_client.describe_stacks()["Stacks"]), 1)
        # Get id of the stack
        stack_id = cf_client.describe_stacks()["Stacks"][0]["StackId"]
        # Run the tested function
        instance_handler = InstanceHandler()
        instance_handler.delete_cfn(stack_id)
        # Assert the function deleted the stack
        self.assertEqual(len(cf_client.describe_stacks()["Stacks"]), 0)

class TestLambdaHandler(unittest.TestCase):

    @mock_dynamodb2
    @mock_ec2
    @mock_cloudformation
    @mock_sns
    def test_main(self):
        # Instanciate mock
        dynamodb = dynamodb_mock().db
        ec2_client = boto3.client("ec2", REGION)
        cf_client = boto3.client('cloudformation', region_name=REGION)
        sns_client = boto3.client('sns', region_name=REGION)
        ## Assert resources are empty
        # assert db empty
        r = dynamodb.Table(ANOMALY_CASE_TABLE).scan()
        self.assertEqual(r["Count"], 0)
        r = dynamodb.Table(AC_STEPS_TABLE).scan()
        self.assertEqual(r["Count"], 0)
        # assert no ec2 instance
        self.assertEqual(len(ec2_client.describe_instances()["Reservations"]), 0)
        # assert no stack
        self.assertEqual(len(cf_client.describe_stacks()["Stacks"]), 0)

        ## Initiate resources
        # populate db
        dynamodb.Table(AC_STEPS_TABLE).put_item(
            Item={"anomaly_case": "AC_test", "steps": ["results"]}
        )
        # create ec2 instance
        ec2_client.run_instances(ImageId='ami-03cf127a', MinCount=1, MaxCount=1)
        ec2_id = ec2_client.describe_instances()["Reservations"][0]["Instances"][0]["InstanceId"]
        # create stack
        with open("stack.json") as file:
            template = json.load(file)
        cf_client.create_stack(StackName="testStack", TemplateBody=str(template))
        stack_id = cf_client.describe_stacks()["Stacks"][0]["StackId"]
        # create sns Topic
        topic_arn = sns_client.create_topic(Name="TopicTest")["TopicArn"]

        ## Run lambda
        lambda_handler = LambdaHandler()
        lambda_handler.storage_handler.db = dynamodb
        lambda_handler.instance_handler.ec2 = ec2_client
        lambda_handler.sns_client = sns_client
        lambda_handler.sns_topic_arn = topic_arn
        event = {
                  "Records": [
                    {
                      "EventSource": "aws:sns",
                      "EventVersion": "1.0",
                      "EventSubscriptionArn": "arn:aws:sns:eu-west-1:{{{accountId}}}:ExampleTopic",
                      "Sns": {
                        "Message": {
                          "anomaly_case": "AC_test",
                          "fit_or_predict": "fit",
                          "details": "execution of AC_test",
                          "ami_id": ec2_id,
                          "step": "results",
                          "date": "2020-01-01",
                          "status": "success",
                          "stack_name": stack_id,
                          "ac_duration": "EXAMPLE"
                        }
                      }
                    }
                  ]
                }
        lambda_handler.main(event=event, context=None)

        ## Assert lambda has been executed properly
        # Assert ec2 instance deleted
        self.assertEqual(ec2_client.describe_instances()["Reservations"][0]["Instances"][0]["State"]["Name"], "stopped")
        # Assert cloudofrmation stack deleted
        self.assertEqual(len(cf_client.describe_stacks()["Stacks"]), 0)
        # Assert results written in dynamodb
        r = dynamodb.Table(ANOMALY_CASE_TABLE).scan()
        self.assertEqual(r["Count"], 1)


if __name__ == "__main__":
    unittest.main()

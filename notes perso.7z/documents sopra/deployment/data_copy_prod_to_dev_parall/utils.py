#!/usr/bin/env python
# -*- coding: utf-8 -*-

from config import (
    s3_client
)


def list_sublevel_prefix(bucket,prefix):
    paginator = s3_client.get_paginator('list_objects')
    result = paginator.paginate(Bucket=bucket, Prefix= prefix, Delimiter='/')
    sublevel_prefix = []
    for prefix in result.search('CommonPrefixes'):
        prefix_name = prefix.get('Prefix')
        sublevel_prefix.append(prefix_name)
    return sublevel_prefix
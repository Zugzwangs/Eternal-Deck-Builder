#!/usr/bin/env python
# -*- coding: utf-8 -*-

import config
import utils
import subprocess


def main():
    list_idx = utils.list_sublevel_prefix(config.SOURCE_BUCKET, config.PREFIX)
    for idx in list_idx:
        command_argument = ["nohup", "python3", "slave.py", idx]
        process = subprocess.Popen(command_argument, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)


if __name__ == '__main__':
    main()


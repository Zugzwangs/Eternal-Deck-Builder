#!/usr/bin/env python
# -*- coding: utf-8 -*-

import boto3
import datetime

SOURCE_BUCKET = "s3-2s33-prod-scheduled-raw-data-eu-west-1"
DESTINATION_BUCKET = "s3-2s33-int-scheduled-raw-data-eu-west-1"

PREFIX = "parquetfiles/"

DATE_0 = "2022-08-01"
DATE_F = "2023-02-05"

date_0 = datetime.datetime.strptime(DATE_0, "%Y-%m-%d")
date_f = datetime.datetime.strptime(DATE_F, "%Y-%m-%d")

s3_client = boto3.client('s3')
s3_resource = boto3.resource('s3')

inline_args = [

    {'long': '--index',
     'short': '-idx',
     'help': 'idx prefix'}
]
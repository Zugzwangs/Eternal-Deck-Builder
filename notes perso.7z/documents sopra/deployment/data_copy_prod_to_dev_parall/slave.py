#!/usr/bin/env python
# -*- coding: utf-8 -*-

import config
import utils
import datetime
import sys


def main():
    list_days = utils.list_sublevel_prefix(config.SOURCE_BUCKET, idx)
    if idx == "parquetfiles/idx_01/":
        date_0 = datetime.datetime.strptime("2022-09-29", "%Y-%m-%d")
    else:
        date_0 = config.date_0
    date_f = config.date_f

    for day in list_days:
        date_string = day[:-1][-10:]
        try:
            date_parsed = datetime.datetime.strptime(date_string, "%Y-%m-%d")
            if date_0 <= date_parsed <= date_f:
                print(date_string)
                resp = config.s3_client.list_objects(Bucket=config.SOURCE_BUCKET, Prefix=day)
                list_objects = resp['Contents']
                for obj in list_objects:
                    print(f"Copying {obj['Key']} ...")
                    copy_source = {
                        'Bucket': config.SOURCE_BUCKET,
                        'Key': obj['Key']
                    }
                    config.s3_resource.Bucket(config.DESTINATION_BUCKET).copy(copy_source, obj['Key'], ExtraArgs= {'ACL': 'bucket-owner-full-control'})

        except Exception:
            pass


if __name__ == '__main__':
    idx = sys.argv[1]
    print(idx)
    main()


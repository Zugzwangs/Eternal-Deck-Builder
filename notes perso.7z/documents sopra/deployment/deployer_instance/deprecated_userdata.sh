#!/bin/bash -x

USERDATA_LOG=/tmp/userdata.log

echo 'installing CloudWatch agent...' >> $USERDATA_LOG

aws_profile=/etc/profile.d/awsenv.sh
echo export USERDATA_LOG=${USERDATA_LOG} >> $aws_profile
BASE_INSTANCE_ID=$(curl -s http://169.254.169.254/latest/meta-data/instance-id)
echo export BASE_INSTANCE_ID=${BASE_INSTANCE_ID} >> $aws_profile
INSTANCE_ID=$(curl -s http://169.254.169.254/latest/meta-data/instance-id)
echo export INSTANCE_ID=$INSTANCE_ID >> $aws_profile
echo export REGION=$(curl -s http://169.254.169.254/latest/meta-data/placement/region) >> $aws_profile
BASE_STACK_ID=$(aws ec2 describe-tags --region eu-west-1 --filter Name=resource-id,Values=$BASE_INSTANCE_ID --output=text | grep -F aws:cloudformation:stack-id | cut -f 5)
echo export BASE_STACK_ID=$BASE_STACK_ID >> $aws_profile
STACK_ID=$(aws ec2 describe-tags --region eu-west-1 --filter "Name=resource-id,Values=$INSTANCE_ID" --output=text | grep -F "aws:cloudformation:stack-id" | cut -f 5)
echo export STACK_ID=$STACK_ID >> $aws_profile

source $aws_profile
echo current base instance is ${BASE_INSTANCE_ID} and is instanciated by the stack ${STACK_ID}  >> $USERDATA_LOG

cd /tmp
wget -q https://s3.amazonaws.com/amazoncloudwatch-agent/redhat/amd64/latest/amazon-cloudwatch-agent.rpm
sudo rpm -U ./amazon-cloudwatch-agent.rpm

echo '{"logs":{"logs_collected": {"files": {"collect_list": [{"file_path": '\"$USERDATA_LOG\"',"log_group_name": "/2s33/administration/deployer"}]}}}}' > /tmp/deployer-cloud-watch-cfg.json
/opt/aws/amazon-cloudwatch-agent/bin/amazon-cloudwatch-agent-ctl -a append-config -m ec2 -c file:/tmp/deployer-cloud-watch-cfg.json -s
/opt/aws/amazon-cloudwatch-agent/bin/amazon-cloudwatch-agent-ctl -a append-config -m ec2 -c file:/tmp/deployer_instance_metrics.json -s

sudo /opt/aws/amazon-cloudwatch-agent/bin/amazon-cloudwatch-agent-ctl -m ec2 -a start


echo 'installing development tools and python' >> $USERDATA_LOG
sudo yum install -y scl-utils
sudo yum install -y scl-utils-build
sudo yum install -y rh-python38
sudo yum install -y @development
sudo yum install -y crudini


echo 'fetching artifactory secret' >> $USERDATA_LOG
ARTIFACTORY_HOST=artifactory.2b82.aws.cloud.airbus.corp
ARTIFACTORY_DEVOPTOOL_SECRET_ID=/airbus/platform/secretsmanager/sa-2s33-devtool/artifactory/v1
ARTIFACTORY_DEVOPTOOL_SECRET=$(aws secretsmanager get-secret-value --secret-id $ARTIFACTORY_DEVOPTOOL_SECRET_ID --region eu-west-1)
APIKEY=$(echo $ARTIFACTORY_DEVOPTOOL_SECRET | jq '.SecretString | fromjson | ."api_key"' | tr -d \")
APIKEY=$(sed -e 's/^"//' -e 's/"$//' <<< $APIKEY)
mkdir ~/.pip
echo '[global]' >> ~/.pip/pip.conf
echo 'trusted-host = ${ARTIFACTORY_HOST}' >>  ~/.pip/pip.conf
echo 'index-url = https://sa-2s33-devtool, sa-2s33-devtool:'$APIKEY'@artifactory.2b82.aws.cloud.airbus.corp/artifactory/api/pypi/r-2s33-insider-pypi-virtual/simple' >> ~/.pip/pip.conf

echo 'Activate target python collection and complete environment' >> $USERDATA_LOG
source scl_source enable rh-python38
python -V
pip install setuptools==58.0.0
pip install wheel==0.37.0
pip install boto3

echo 'Make python3.8 available at startup' >> $USERDATA_LOG
python_profile_file='/etc/profile.d/enablepython38.sh'
echo '#!/bin/bash' > $python_profile_file
echo 'source scl_source enable rh-python38' >> $python_profile_file

userdata_exit_code=$?
echo userdata_exit_code: $userdata_exit_code >> $USERDATA_LOG
echo 'User data setup done' >> $USERDATA_LOG

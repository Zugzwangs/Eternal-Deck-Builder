#!/usr/bin/env python
# -*- coding: utf-8 -*-

import boto3
from pathlib import Path


class CloudFormationAssistant:

    def __init__(self):
            self.region = 'eu-west-1'
            self.cfn = boto3.resource('cloudformation', region_name=self.region)

    def list_stack_deployed(self):
        statuses = ['CREATE_COMPLETE']
        stacks = [stack.stack_name for stack in self.cfn.stacks.all() if stack.stack_status in statuses]
        return stacks


    def list_templates(self, working_directory):
        file_list = list(Path(working_directory).rglob("*.[jJ][sS][oO][nN]"))
        return file_list


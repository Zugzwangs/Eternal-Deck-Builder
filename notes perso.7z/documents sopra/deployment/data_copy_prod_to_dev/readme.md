***
## Readme
***
The python script "copy_raw_data_prod_to_dev.py" allows to make a copy of a set of data from Prod env scheduled-raw-data bucket to Dev env scheduled-raw-data bucket.


### How to use it
Edit the script file copy_raw_data_prod_to_dev.py and change the following parameters to fit your needs:

DATE_0 = "2021-10-13" => initial date

DATE_F = "2021-10-14" => final date

The script will crawl the S3 bucket in parquetfiles prefix and then will copy each object that fall into the initial date and the final date.

###  Runtime Environment
This script must be executed from the Deployer Instance in Prod environment.

### IAM
Please note that the deployer instance in Prod has a specific role with all actions rights on all resources in Prod env.

deployer role == 2s33RoleForDeployerInstance

deployer policy == 2s33DeployerPolicy

Nevertheless, the following additional permissions are required if not already set-up.

- **KMS**: the RoleId of the deployer in Prod must be added to the permission list of the KMS used in the destination bucket in Dev 
- **source bucket**: 

 ```json
{
  "Action": [
    "s3:Get*",
    "s3:List*"
  ],
  "Resource": [
    "arn:aws:s3:::s3-2s33-prod-scheduled-raw-data-eu-west-1",
    "arn:aws:s3:::s3-2s33-prod-scheduled-raw-data-eu-west-1/*"
  ],
  "Condition": {
    "StringLike": {
      "aws:userId": [
        "AROAWWPRBVJTBBJZKGVIK:*"
      ]
    }
  }
}
```
- **destination bucket**: 

````json
   {
    "Effect": "Allow",
    "Principal": {
        "AWS": "arn:aws:sts::460603894374:assumed-role/2s33RoleForDeployerInstance/i-029ab3ca4e002a2cd"
    },
    "Action": [
        "s3:Put*",
        "s3:Get*",
        "s3:List*"
    ],
    "Resource": [
        "arn:aws:s3:::s3-2s33-dev-scheduled-raw-data-eu-west-1",
        "arn:aws:s3:::s3-2s33-dev-scheduled-raw-data-eu-west-1/*"
    ]
   },
  {
    "Effect": "Allow",
    "Principal": {
        "AWS": "arn:aws:sts::460603894374:assumed-role/2s33RoleForDeployerInstance/i-029ab3ca4e002a2cd"
    },
    "Action": "s3:PutObject",
    "Resource": "arn:aws:s3:::s3-2s33-dev-scheduled-raw-data-eu-west-1/*",
    "Condition": {
        "StringEquals": {
            "s3:x-amz-acl": "bucket-owner-full-control"
        }
    }
  }
````
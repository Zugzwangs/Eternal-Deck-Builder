#!/usr/bin/env python
# -*- coding: utf-8 -*-

import boto3
import datetime

SOURCE_BUCKET = "s3-2s33-prod-scheduled-raw-data-eu-west-1"
DESTINATION_BUCKET = "s3-2s33-dev-scheduled-raw-data-eu-west-1"
DESTINATION_KEY = "arn:aws:kms:eu-west-1:309711267128:key/e60af803-8093-41f2-afc2-41a6faa7e4ec"
OBJECT_KEY = 'test.txt'


s3_resource = boto3.resource('s3')

copy_source = {
                'Bucket': SOURCE_BUCKET,
                'Key': OBJECT_KEY
               }
extra_args = {'ACL': 'bucket-owner-full-control'}

def main():
    s3_resource.Bucket(DESTINATION_BUCKET).copy(copy_source, OBJECT_KEY, ExtraArgs=extra_args)


if __name__ == '__main__':
    main()

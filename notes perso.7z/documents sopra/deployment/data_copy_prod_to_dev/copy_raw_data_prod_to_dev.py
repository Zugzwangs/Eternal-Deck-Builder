#!/usr/bin/env python
# -*- coding: utf-8 -*-

import boto3
import datetime

SOURCE_BUCKET = "s3-2s33-prod-scheduled-raw-data-eu-west-1"
DESTINATION_BUCKET = "s3-2s33-dev-scheduled-raw-data-eu-west-1"
DESTINATION_KEY = "arn:aws:kms:eu-west-1:309711267128:key/e60af803-8093-41f2-afc2-41a6faa7e4ec"

PREFIX = "parquetfiles/"

DATE_0 = "2021-10-13"
DATE_F = "2021-10-14"

date_0_parsed = datetime.datetime.strptime(DATE_0, "%Y-%m-%d")
date_f_parsed = datetime.datetime.strptime(DATE_F, "%Y-%m-%d")

s3_client = boto3.client('s3')
s3_resource = boto3.resource('s3')


def list_sublevel_prefix(bucket,prefix):
    paginator = s3_client.get_paginator('list_objects')
    result = paginator.paginate(Bucket=bucket, Prefix= prefix, Delimiter='/')
    sublevel_prefix = []
    for prefix in result.search('CommonPrefixes'):
        prefix_name = prefix.get('Prefix')
        sublevel_prefix.append(prefix_name)
    return sublevel_prefix


def main():
    list_idx = list_sublevel_prefix(SOURCE_BUCKET, PREFIX)
    for idx in list_idx:
        print(idx)
        list_days = list_sublevel_prefix(SOURCE_BUCKET, idx)
        for day in list_days:
            date_string = day[:-1][-10:]
            try:
                date_parsed = datetime.datetime.strptime(date_string, "%Y-%m-%d")
                if date_parsed >= date_0_parsed and date_parsed <= date_f_parsed:
                    print(date_string)
                    resp = s3_client.list_objects(Bucket=SOURCE_BUCKET, Prefix=day)
                    list_objects = resp['Contents']
                    for obj in list_objects:
                        print(f"Copying {obj['Key']} ...")
                        copy_source = {
                            'Bucket': SOURCE_BUCKET,
                            'Key': obj['Key']
                        }
                        s3_resource.Bucket(DESTINATION_BUCKET).copy(copy_source, obj['Key'], ExtraArgs= {'ACL': 'bucket-owner-full-control'})
            except:
                pass

if __name__ == '__main__':
    main()

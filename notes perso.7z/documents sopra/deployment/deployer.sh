#!/bin/bash

#################################################################################################
# Insider protection (2s33)
# Description:
#   deploy Insider protection framework on PCP
# confluence page: https://confluence.airbus.corp/
#
# Dependencies:
#   - jq command
#   - dos2unix command
#   - zip command
#   - crudini command (see https://github.com/pixelb/crudini)
#   - an AWS CLI session open as admin to the target PCP account
#################################################################################################

#################################################################################################
# FUNCTIONS
#################################################################################################

# convenient function to display error through stderr
err() {
  echo "ERROR: $*" >> /dev/stderr
}

# convenient function to display debug messages if the verbose switch is on
debug() {
  if [[ "$verbose" == "yes" ]]; then
    echo "DEBUG: $*" >> ./trace.log
  fi
}

# scan CloudFormation template to determine it's official stack name when deployed
function get_template_stack_name() {
  if [ -z "$1" ]; then
    err "no template file path provide to get_template_stack_name()"
    return 1
  elif ! [[ -r "$1" ]]; then
    err "can't read or find $1"
    return 1
  fi
  debug "reading Metadata section of the template to retrieve stack name"
  stack_name=$(cat "$1" | jq -r '.Metadata.stack_name')
  echo "$stack_name"
  return 0
}

# scan CloudFormation template to determine which part of infrastructure it belongs (is it NIFI, COMPUTING, ...)
function get_template_block() {
  if [ -z "$1" ]; then
    err "no template file path provide to get_template_block()"
    return 1
  elif ! [[ -r "$1" ]]; then
    err "can't read or find $1"
    return 1
  fi
  debug "reading Metadata section of the template to retrieve infra category"
  block=$(cat "$1" | jq -r '.Metadata.block')
  echo "$block"
  return 0
}

# scan CloudFormation template to determine if it should be considered as elgible for automated deployment
function get_template_mode() {
  if [ -z "$1" ]; then
    err "no template file path provide to get_template_block()"
    return 1
  elif ! [[ -r "$1" ]]; then
    err "can't read or find $1"
    return 1
  fi
  debug "reading Metadata section of the template to retrieve deployment mode"
  _mode=$(cat "$1" | jq -r '.Metadata.mode')
  echo "$_mode"
  return 0
}

# scan a CloudFormation template to gather parameters
function get_template_parameters() {
  if [ -z "$1" ]; then
    err "no template file path provide to get_template_parameters()"
    return 1
  elif ! [[ -r "$1" ]]; then
    err "can't read or find $1"
    return 1
  fi
  debug "reading Parameters section of the template"
  params=$(cat "$1" | jq -r '.Parameters')
  echo "$params"
  return 0
}

# scan a CloudFormation template for dependencies
function get_template_dependencies() {
  if [ -z "$1" ]; then
    err "no template file path provide to get_template_dependencies()"
    return 1
  elif ! [[ -r "$1" ]]; then
    err "can't read or find $1"
    return 1
  fi
  debug "reading Metadata section of the template"
  deps=$(cat "$1" | jq -cr '.Metadata.dependencies')
  echo "$deps"
  return 0
}

#scan a Cloudformation template for resources
function get_template_resources() {
  if [ -z "$1" ]; then
    err "no template file path provide to get_template_resources()"
    return 1
  elif ! [[ -r "$1" ]]; then
    err "can't read or find $1"
    return 1
  fi
  debug "reading resources section of the template"
  deps=$(cat "$1" | jq -cr '.Metadata.resources')
  echo "$deps"
  return 0
}

# pass a stack name, the function will check if the stack is deployed correctly in a given AWS account
# see the list of existing stack state: https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/using-cfn-describing-stacks.html
function is_stack_deployed() {
  if [[ -z "$1" ]]; then 
    err "no stack name given to is_stack_deployed()"
    return 1
  else
    debug "checking on AWS account if the stack $1 is currently deployed"
    stack_status=$(aws cloudformation describe-stacks --region $aws_region --stack-name $1 --no-verify-ssl | jq -r '.Stacks[0].StackStatus')
    debug "status is $stack_status"
    case $stack_status in
      "")
        debug "no stack found"
    return 1
    ;;
      "CREATE_COMPLETE" | "UPDATE_COMPLETE" | "UPDATE_COMPLETE_CLEANUP_IN_PROGRESS")
    debug "healty stack found"
    return 0
    ;;
      *)
    debug "unhealty and/or others states of the stack found"
        return 3
    ;;
    esac
  fi  
}

# return 0 if the template file is correct
function is_template_correct() {
  if [[ -z "$1" ]]; then 
    err "no template file provided to is_template_correct()"
    return 1
  elif ! [[ -r "$1" ]]; then
    err "file $1 doesn't exists or unreadable"
    return 1
  else
    debug "check cloud formation template syntax"
    _template_size=$(cat "$1" | wc -c)
    if [[ "${_template_size}" -gt "51200" ]]; then
      # push the template on s3 before validate it
      _template_name=$(basename "$1")
      aws s3 cp "$1" "s3://${BackendBucketFullName}/templates/" --quiet --region $aws_region --no-verify-ssl
      aws cloudformation validate-template --template-url "https://${BackendBucketFullName}.s3-eu-west-1.amazonaws.com/templates/${_template_name}" --region $aws_region --no-verify-ssl > /tmp/template_validation_report.txt 2>&1
    else
      # simple in-line validation
      aws cloudformation validate-template --template-body "file://$1" --region $aws_region --no-verify-ssl > /tmp/template_validation_report.txt 2>&1
    fi
    if [[ "$?" == "0" ]]; then
      return 0
    else
      debug "template is not valid"
      return 2
    fi
  fi
}

# resolve/retrive the value of a parameter from the catalogue
function resolve_parameter() {
  if [[ -z "$1" ]]; then
    echo ""
    return 1
  else
    resolved_parameter=$(crudini --get "$conf_file" "$env" "$1")
    echo "$resolved_parameter"
    return 0
  fi
}

# resolve all parameters values given as an input json array
# return a string using the form param1=value1,param2=value2... 
# JSON version when stacking parameter into an array
#    => initiate param_build='[]'
#    => param_build=$(echo "$param_build" | jq --arg key "$key" --arg current_value "$current_value" '. + [{ '\"$key\"' : '\"$current_value\"' }] ')
function build_parameters() {
  if [[ -z "$1" ]]; then
    err "no param file provided to build_parameters()"
    return 1
  else
    debug "building parameters..."
    param_build=''
    separator=" "
    # read parameter by parameter
    while IFS="|" read -u 4 key value; do
      debug "# processing parameter name: $key"
      # check if current parameter is a secret
      is_secret=$(echo "$value" | jq '.NoEcho')
      if [[ "$is_secret" == true ]]; then
        # ask user to provide the value
        read -s -p $'\n'"please enter secret value for parameter $key: " current_value
      else
        # else try to resolve the value from the 'catalogue
        current_value=$(resolve_parameter "$key")
      fi

      if [[ -z "$current_value" ]]; then
        # ask user to provide a value because we can't resolve it automatically
        read -p $'\n'"unresolved parameter $key, see details: ${value}. Please enter a value:" current_value
      fi

      # TODO sanitize key and value => no = in it etc ...

      # aggregate current parameter to the list
      param_build=$(echo "${param_build}${separator}${key}=${current_value}")

    done 4< <(cat "$1" | jq -r 'to_entries | map(.key + "|" + (.value | tostring)) | .[]')
    # return full list of parameters with their values
    echo -e "$param_build"
    return 0
  fi
}

# function used to deploy required resources by templates on backend bucket
# deployment routine may vary according to the type of resource"
function deploy_resource() {
  if [[ -z "$1" ]]; then
    echo "warning: no file passed to deploy_to_backend()"
    return 1
  else
    case "$2" in
      lambda-code)
        echo "info: pushing lambda code to s3."
        if [[ -d "$1" ]]; then   # check if $1 is a directory
          package_name="/tmp/$(basename "$1").zip"
          pushd "$1"
          zip -r "${package_name}" ./*
          if [[ "$dry_run" == "yes" ]]; then
            echo "dry-run: aws s3 cp ${package_name} s3://${BackendBucketFullName}/lambda-code/  --no-verify-ssl"
          else
            echo "debug: deploy ${package_name} to s3://${BackendBucketFullName}/lambda-code/"
            aws s3 cp ${package_name} s3://${BackendBucketFullName}/lambda-code/ --no-verify-ssl
          fi
          rm -f "${package_name}" # don't forget to delete temporary archive
          popd
          return "$?"
        else
          echo "warning: $1 is not a folder. no deployment."
          return 1
        fi
      ;;
      
      lambda-layer)
        echo "info: pushing layer code to s3."
        if [[ -d "$1" ]]; then   # check if $1 is a directory
          package_name="/tmp/$(basename "$1").zip"
          pushd "$1"
          zip -r "${package_name}" ./*
          if [[ "$dry_run" == "yes" ]]; then
            echo "dry-run: aws s3 cp ${package_name} s3://${BackendBucketFullName}/layers/ --no-verify-ssl"
          else
            echo "debug: deploy ${package_name} to s3://${BackendBucketFullName}/layers/"
            aws s3 cp ${package_name} s3://${BackendBucketFullName}/layers/ --no-verify-ssl
          fi
          rm -f "${package_name}" # don't forget to delete temporary archive
          popd
          return "$?"
        else
          echo "warning: $1 is not a folder. no deployment."
          return 1
        fi        
      ;;
      
      ec2-userdata)
        echo "info: pushing userdata script to s3."
        dos2unix "$1" # convert to UNIX type file
        if [[ "$dry_run" == "yes" ]]; then
          echo "dry-run: aws s3 cp $1 s3://${BackendBucketFullName}/userdata/ --no-verify-ssl"
        else
          echo "debug: deploy $1 to s3://${BackendBucketFullName}/userdata/  "
          aws s3 cp $1 s3://${BackendBucketFullName}/userdata/ --no-verify-ssl
        fi
        return "$?"
      ;;

      template)
        echo "info: pushing template file to s3."
        if [[ "$dry_run" == "yes" ]]; then
          echo "dry-run: aws s3 cp $1 s3://${BackendBucketFullName}/template/ --no-verify-ssl"
        else
          echo "debug: deploy $1 to s3://${BackendBucketFullName}/template/  "
          aws s3 cp $1 s3://${BackendBucketFullName}/template/ --no-verify-ssl
        fi
        return "$?"
      ;;

      lifecycle-configuration-notebook-instance)
        echo "info: pushing template file to s3."
        if [[ "$dry_run" == "yes" ]]; then
          echo "dry-run: aws s3 cp $1 s3://${BackendBucketFullName}/lifecycle-configurations/mlops-notebook-instances/ \\
            --no-verify-ssl"
        else
          echo "debug: deploy $1 to s3://${BackendBucketFullName}/lifecycle-configurations/mlops-notebook-instances/"
          aws s3 sync $1 s3://${BackendBucketFullName}/lifecycle-configurations/mlops-notebook-instances/ \
            --no-verify-ssl
        fi
        return "$?"
      ;;
      
      *)
        echo "info: default method to push resource to s3."
        if [[ -f "$1" ]]; then
          if [[ "$dry_run" == "yes" ]]; then
            echo "dry-run: aws s3 cp $1 s3://${BackendBucketFullName}/ --no-verify-ssl"
          else
            echo "debug: deploy $1 to s3://${BackendBucketFullName}/ "
            aws s3 cp $1 s3://${BackendBucketFullName}/ --no-verify-ssl
          fi
          return "$?"
        else
          echo "no default method defined to deploy non file object."
        fi
      ;;
      
    esac
  fi
}

#################################################################################################
# Handle positionnals parameters
#################################################################################################
myself=$(basename "$0")
absolute_script_path=$(readlink -f "$0")
working_directory=$(dirname "$absolute_script_path")
conf_file="${working_directory}/environment.ini"
root_directory=$(dirname "$working_directory")

GETOPT_TEMP=$(getopt -n "$myself" \
            --options='hvm:e:t:f:s:do' \
            --longoptions='help,verbose,mode:,env:,target:,file:,sourcedir:,dry,onlydeps' -- "$@")

if [ $? != 0 ]; then
    # getopt a retourne une erreur.
    exit 1
fi
eval set -- "$GETOPT_TEMP"

function usage() {
[[ -n $1 ]] && echo "Error: $1"
    cat <<EOF
This script is a deployment tool. Its scan a folder and deploy all cloudformation template it found on selected environement.
Usage: $myself [options] | -h
    -h, --help           To list options (this help).
    -v, --verbose        Verbose mode.
    -m, --mode M         select Mode among 'deploy', 'update', 'delete' and 'display' (default is deploy). TODO.
    -e, --env E          Select on which environment you want to deploy (default is DEV). Authorized values are DEV or PROD.
    -t, --target T       Select part of infrastructure you want to deploy (default is ALL).
    -f, --file F         Pass directly a Cloud formation template file as only target.
    -s, --sourcedir D    force the script to scan directory D for templates files instead of script's parent folder.
    -o, --onlydeps       will deploy only dependencies when Mode deploy is selected.
    -d, --dry            Dry run, do nothing but display all details about operation that would be executed.
EOF
    exit -1
}

while true; do
    case "$1" in
        -h|--help) usage                        ; shift   ;;    
        -v|--verbose) verbose=yes               ; shift   ;;
        -m|--mode) mode=$2                      ; shift 2 ;; 
        -e|--env) env=$2                        ; shift 2 ;;
        -t|--target) target=$2                  ; shift 2 ;;
        -f|--file) template_file=$2             ; shift 2 ;;
        -s|--sourcedir) working_directory=$2    ; shift 2 ;;
	-o|--onlydeps) only_deps=yes            ; shift   ;;
        -d|--dry) dry_run=yes                   ; shift   ;;
        --) shift                               ; break   ;;
        *) echo "Parsed unhandled options: $*" >&2  ; exit 1  ;;
    esac
done

#################################################################################################
# INIT
#################################################################################################
if [[ ! -r "${conf_file}" ]]; then
    echo "missing or unreadable environment config file."
    echo "deployer will not be able to resolve automatically parameters settings."
    read -p "do you want to continue anyway (y/n) ?" answer
    case ${answer:0:1} in
      y|Y) echo Yes;;
      * )   echo No; exit 0;;
    esac    
fi

if [[ -z "$mode" ]]; then
  mode="deploy"
  debug "no mode specified, now set to deploy"
else
  case "$mode" in
    deploy) debug "mode deploy selected" ;;
    update) debug "mode update selected" ;;
    delete) debug "mode delete selected" ;;
    display) debug "mode display selected" ;;
    *) echo "incorrect mode selected. Correct values are debug, update, delete or display"; exit 1 ;;
  esac  
fi

if [[ -z "$env" ]]; then
    env="DEV"
    debug "no environement specified, now set to 'DEV' by default."
elif [[ "$env" == "DEV" ]]; then
    debug "DEV environment selected."
elif [[ "$env" == "PROD" ]]; then
    debug "PROD environment selected."
else
    err "unknown environment ${env} specified, deployment aborded."
    exit 1
fi

if [[ -z "$target" ]]; then
    target="ALL"
    debug "no target specified, now set to 'ALL' by default."
fi

if [[ -z "$verbose" ]]; then
    verbose="no"
fi

if [[ -z "$dry_run" ]]; then
    dry_run="no"
fi


#################################################################################################
# load environments
#################################################################################################

# try to suppress boring warning
export PYTHONWARNINGS="ignore:Unverified HTTPS request"

# load settings from environment.ini
BackendBucketFullName=$(crudini --get "$conf_file" "$env" "BackendBucketFullName")
aws_region=$(crudini --get "$conf_file" "GLOBAL" "AWS_REGION")
aws_profil=$(crudini --get "$conf_file" "GLOBAL" "AWS_PROFIL")


# DEBUG SWITCH VALUES
debug "verbose: $verbose"
debug "env: $env"
debug "mode: $mode"
debug "target: $target"
debug "dry_run: $dry_run"
debug "backendbucketfullname: $BackendBucketFullName"
debug "myself: $myself"
debug "absolutescriptpath: $absolute_script_path"
debug "workingdir: $working_directory"
debug "configfile: $conf_file"
debug "rootdirectory: $root_directory"

#################################################################################################
# MAIN
#################################################################################################

### GATHERING TEMPLATES
echo '-----------------------------------------------------------------------'
echo 'GATHERING TEMPLATE'
echo '-----------------------------------------------------------------------'
task_list="/tmp/task_list.csv"  # this temp file hold list of templates to deploy in order to complet the target
echo -n "" > "$task_list"   # clear the file before starting

if [[ ! -z "$template_file" ]]; then

  # single forced template mode
  echo "INFO: forced mode as a specific template has been provided"
  if [[ -d "$template_file" ]]; then
    echo "the -f option do not accept folder as argument."
    exit 1
  elif [[ ! -r "$template_file" ]]; then
    err "can't find or read the template file. deployment aborded."
    exit 1
  else
    single_template_path=$(echo "$(cd "$(dirname "$template_file")"; pwd -P)/$(basename "$template_file")")
    is_template_correct "$single_template_path"
    if [[ "$?" == "0" ]]; then
      echo "template is valid => added to the list of tasks."
      echo "$single_template_path" > "$task_list"
    else
      echo "template is not valid, please fix the template before continuing. deployment is aborded."
      read -p "do you want to see the template validation report error (y/n)? " answer
      case ${answer:0:1} in
        y|Y) cat "/tmp/template_validation_report.txt" ;;
	*) echo "deployment aborted" ;;
      esac
      exit 1
    fi
  fi

else

  # folder crawling mode
  echo "INFO: browsing mode selected, template will be fetched from folder ${working_directory}"  
  while IFS='' read -u 3 _template_file; do
    echo "### potential template detected: $_template_file"
    _current_block=$(get_template_block $_template_file)
    _current_mode=$(get_template_mode $_template_file)

    if [[ "$_current_block" == "$target" || ("$target" == "ALL" && "$_current_block" != "null") ]]; then
      echo -e "\tbelongs to the target"
      if [[ "$_current_mode" == "manual" ]]; then
        # propose to deploy anyway
        read -p $'\t'"this template is restricted to manual deployment, do you want to proceed anyway (y/n)? " answer
        case ${answer:0:1} in
          y|Y) echo -e "\ttemplate will be processed" ;;
          * )  echo -e "\ttemplate will be skipped."; continue ;;
        esac
      fi
      echo -ne "\ttesting validity... "
      is_template_correct "$_template_file"
      if [[ "$?" == "0" ]]; then
        echo "VALID => added to the task list."
        echo "$_template_file" >> "$task_list"
      else
        echo "INVALID => please fix the template."
        read -p "do you want to see the template validation report error (y/n)? " answer
        case ${answer:0:1} in
          y|Y) cat "/tmp/template_validation_report.txt" ;;
          esac
        read -p "do you want to ignore this template and continue the deployment (y/n)? " answer
	case ${answer:0:1} in
          y|Y) continue ;;
	  *) echo "deployment aborted"; exit 1 ;;
	esac
      fi   
    else
      echo -e "\trejected because is not part of the target."
    fi
  done 3< <(find $working_directory -type f -name '*.json')

fi

listed_tasks_number=$(wc -l < "$task_list")
echo '-----------------------------------------------------------------------'
echo "TEMPLATES LISTING (${listed_tasks_number} templates):"
echo '-----------------------------------------------------------------------'
cat "$task_list"

### SWITCH MOD
echo '-----------------------------------------------------------------------'
echo "APPLYING SELECTED MODE"
echo '-----------------------------------------------------------------------'
case "$mode" in
  display)
    echo "INFO: do display stuff (TODO)"
    # build root node of the graph
    # dunno wich tool to use yet
    while IFS='' read item; do
      # get metadata attributes
      _current_name=$(basename "$item")
      _current_block=$(get_template_block "$item")
      _current_mode=$(get_template_mode "$item")
      _current_stack_name=$(get_template_stack_name "$item")
      _current_deps=$(get_template_dependencies "$item")
      _current_resources=$("$item")
      # convert all these metadata to a node object and build the graph using it

      # compile stats
      # total temalates and how many template by blocks

    done <"$task_list"
    exit 0
    ;;

  deploy)
    echo "INFO: deploy mode"
    ;;

  update)
    echo "INFO: mode not implemented yet (TODO)"
    exit 0
    ;;

  delete)
    echo "INFO: mode not implemented yet (TODO)"
    exit 0
    ;;

  *)
    echo "ERROR: unknown mode, exiting."
    exit 1
    ;;  
esac

### DETERMINE DEPENDENCIES AND DEPLOYMENT ORDER
echo '-----------------------------------------------------------------------'
echo "PREPARING EXECUTION PLAN"
echo '-----------------------------------------------------------------------'
sorted_task_list="/tmp/sorted_task_list.csv"       # contain ordered list of templates to deploy (act as FIFO stask)
remaining_task_list="/tmp/remaining_task_list.csv" # intermediate file containing remaining/unsorted templates between rounds of ordering
echo -n "" > "$sorted_task_list" # clean the list before starting
counter="0"
round=1
total_tasks=$(wc -l < "$task_list")
while [[ "$counter" -lt "$total_tasks" && "$round" -le "$total_tasks" ]]; do 
  echo -e "\n### Round $round:"
  while IFS='' read item; do
    echo "checking [$item] dependencies..."
    item_deps=$(get_template_dependencies "$item")
    dependencies_number=$(jq '. | length ' <<< "$item_deps")
    if [[ "$dependencies_number" == 0 ]]; then
      echo -e "\tno dependencies => added [$item] to the execution plan"
      echo "$item" >> "$sorted_task_list"
    else
      echo -e "\t$dependencies_number dependencies found:"
      all_deps_ok=true # init the flag on true
      while IFS='|' read dep_stack dep_template; do
        echo -e "\tdependency [${dep_stack}||${dep_template}]"
        echo -en "\t\tstack $dep_stack already deployed ? "
        is_stack_deployed "$dep_stack" 2>/dev/null 
        if [[ "$?" == "0" ]]; then
          echo "YES => depedency resolved."
          continue
        else
          echo "NO"
        fi
        echo -en "\t\ttemplate $dep_template already in the deployment plan ? "
        grep -c "/$dep_template" "$sorted_task_list" >/dev/null
        if [[ "$?" == "0" ]]; then
          echo "YES => dependency resolved."
        else
          echo "NO => dependency not resolved."
          all_deps_ok=false
        fi
      done< <(jq -rc '.[] | .stacks + "|" + .template' <<< "$item_deps")

      if [[ "$all_deps_ok" == "true" ]]; then
        echo -e "\tall dependencies are satisfied => add [$item] to the execution plan"
        echo "$item" >> "$sorted_task_list"
      else
        echo -e"\tsome dependencies are not satisfied => item will be re-processed during next round."
      fi
    fi
  done <"$task_list"
  round=$((round+1))
  counter=$(wc -l < "$sorted_task_list")
  grep -vFx -f "$sorted_task_list" "$task_list" > "$remaining_task_list"
  mv "$remaining_task_list" "$task_list"
done

planned_task_number=$(wc -l < "$sorted_task_list")
echo '-----------------------------------------------------------------------'
echo "SORTED LISTING (${planned_task_number} templates):"
echo '-----------------------------------------------------------------------'
cat "$sorted_task_list"
echo ''

if [[ "$planned_task_number" -lt "$total_tasks" ]]; then
  echo "some tasks are missing in the plan, it could be due to unresolved or circular dependencies."
  read -p "do you want to deploy anyway (y/n)? " answer
  case ${answer:0:1} in
      y|Y) echo Yes;;
      * )   echo No; exit 0;;
  esac
elif [[ "$planned_task_number" -eq "$total_tasks" ]]; then
  echo "all tasks has been put into the plan."
else
  echo "the number of tasks planned is greater than total number of tasks found during scanning."
  echo "abnormal behaviour, script will exit without deploying anything"
  exit 1
fi

### DEPLOY TARGET
echo '-----------------------------------------------------------------------'
echo "DEPLOYING TARGET"
echo '-----------------------------------------------------------------------'
while IFS='' read -u 5 _template_file; do
  _stack_name=$(get_template_stack_name "$_template_file")
  echo "### deploying $_template_file as stack $_stack_name..."

  # TEST FIRST IF THE STACK IS ALREADY DEPLOYED AND ONLY DEPS NOT ACTIVATED
  is_stack_deployed "$_stack_name"
  if [[ "$?" == "0" && -z "$only_deps" ]]; then 
    echo "$_stack_name is already deployed, skipped."
    continue
  fi
 
  # DEPLOY RESOURCES
  echo "deploying resources... "
  get_template_resources "$_template_file" > "/tmp/current_template_resource.json"
  # for each resource do the deployment
  while IFS="|" read -u 6 current_path current_type; do
    echo "debug resource: $current_path $current_type"
    # build full path of the resources
    resource_fullpath="${root_directory}/${current_path}"
    deploy_resource "$resource_fullpath" "$current_type"
  done 6< <(cat "/tmp/current_template_resource.json" | jq -rc '.[] | .path + "|" + .type')

  # when only deps skip deployment part
  if [[ "$only_deps" == "yes" ]]; then
    echo "INFO: stack not deployed because onlydeps option has been selected"
    continue
  fi

  # check if _stack_name is not empt
  # TODO ask user if we can use file name replacing '_' by '-' as stack name
  # we can also edit the template to add the corresponding metadata
  if [[ -z "${_stack_name}" ]]; then
    echo "no stack name defined, deployment aborded."
    exit 1
  fi

  # BUILDING PARAMETERS
  echo "building parameters for template $_template_file"
  get_template_parameters "$_template_file" > "/tmp/current_template_param.json"
  computed_parameters=$(build_parameters "/tmp/current_template_param.json")
  #echo "DEBUG: computed parameter"
  #echo "$computed_parameters"
 
  # DEPLOY THE STACK
  _current_block=$(get_template_block "$_template_file")

  # check if the template reach the limit size of 51200 bytes
  _template_size=$(cat "${_template_file}" | wc -c)
  if [[ "${_template_size}" -gt "51200" ]]; then
    echo "warning: too big template, it need to be uploaded to the backend s3 bucket"
    _template_argument="--template-file ${_template_file} --s3-bucket ${BackendBucketFullName} --s3-prefix templates --force-upload"

  else
    _template_argument="--template-file ${_template_file}"
  fi

  # give more authorization if the stack required to created IAM resources
  if [[ "$_current_block" == "IAM" ]]; then
    _capabilities_argument="--capabilities CAPABILITY_NAMED_IAM"
  else
    _capabilities_argument="--capabilities CAPABILITY_IAM"
  fi

  # adjust the command if there is some template parameter values to pass
  if [[ -z "${computed_parameters}" ]]; then
    _parameters_argument=""
  else
    _parameters_argument="--parameter-overrides ${computed_parameters}"
  fi

  # execute the deployment or dry run
  if [[ "$dry_run" == "yes" ]]; then
    echo "dry run mode: deployment would be: "
    echo "aws cloudformation deploy ${_template_argument} --stack-name ${_stack_name} ${_parameters_argument} ${_capabilities_argument} --region ${aws_region} --no-verify-ssl"
  else
    echo  aws cloudformation deploy ${_template_argument} --stack-name ${_stack_name} ${_parameters_argument} ${_capabilities_argument} --region ${aws_region} --no-verify-ssl
    aws cloudformation deploy ${_template_argument} --stack-name ${_stack_name} ${_parameters_argument} ${_capabilities_argument} --region ${aws_region} --no-verify-ssl
  fi
  echo "" # force line feed

done 5< "$sorted_task_list"



const AWS = require('aws-sdk');
const cloudwatchlogs = new AWS.CloudWatchLogs();
const s3 = new AWS.S3();
const lambda = new AWS.Lambda();

exports.handler = async function(input, context) {
    const promise = new Promise(async function(resolve, reject) {
        try {
            console.log('=== Begin ===');
            
            // define log group to export
            const dbLogGroup = '/2s33/nifi/nifi-app';
            
            // get the DB logs from the endTime of the last execution to 10s ago
            const now = new Date();
            const startTime = +process.env.lastEndTime;
            const endTime = now.getTime() - 10000;
            console.log('startTime: ' + new Date(startTime).toISOString());
            console.log('endTime: ' + new Date(endTime).toISOString());
            
            // update the lambda lastEndTime environment variable to prepare the next execution
            await updateEndTime(endTime);
            console.log('lastEndTime environment variable updated from ' + startTime + ' to ' + endTime);
            
            // export the logs to the S3 bucket shared with RTM
            console.log('= Export logs to splunk-logs buckets =');
            await sendLogsToRtm(dbLogGroup, startTime, endTime, 'db');


            
            console.log('=== End ===');
            resolve('OK');
        } catch (error) {
            reject(error);
        }
    });
    return promise;
};

const sendLogsToRtm = async function(logGroup, startTime, endTime, prefix) {
    const promise = new Promise(async function(resolve, reject) {
        try {
        
            // get the first log page
            console.log('Get ' + prefix + ' logs page 1');
            let logsRes = await getLogs(logGroup, startTime, endTime, prefix, null);
            let logs = logsRes.events;
            console.log('Page 1 : ' + logs.length + ' lines added to the exported file');
            let i = 2;
            // get all the next log pages (max. 40 pages)
            while(logsRes.nextToken) {
                if (i >= 41) {
                    console.log('Break: Too much pages to load...');
                    break;
                }
                console.log('Get ' + prefix + ' logs page ' + i);
                logsRes = await getLogs(logGroup, startTime, endTime, prefix, logsRes.nextToken);
                if (logsRes.events) {
                    logs = logs.concat(logsRes.events);
                    console.log('Page ' + i + ' : ' + logsRes.events.length + ' lines added to the exported file');
                }
                i++;
            }
            
            // upload the logs on S3
            console.log('Export the ' + prefix + ' log file to S3: ' + logs.length + ' lines');
            await uploadToS3(logs, endTime, prefix);
            
            resolve();
            
        } catch (error) {
            reject(error);
        }
    });
    return promise;
};

const getLogs = async function(logGroup, startTime, endTime, prefix, nextToken) {
    const promise = new Promise(function(resolve, reject) {
        try {
            const params = {
                logGroupName: logGroup,
                startTime: startTime,
                endTime: endTime
            };
            if (nextToken) {
                params.nextToken = nextToken;
            }
            if (prefix === 'db') {
                params.filterPattern = '-"incomplete startup packet"';
            }
            
            cloudwatchlogs.filterLogEvents(params, async function(err, data) {
                if (err) {
                    console.log('getLogs err');
                    console.log(err, err.stack);
                    reject(err);
                } else {
                    resolve(data);
                }
            });
        } catch (error) {
            reject(error);
        }
    });
    return promise;
};

const uploadToS3 = async function(content, endTime, prefix) {
    const promise = new Promise(function(resolve, reject) {
        try {
            const params = {
                Body: JSON.stringify(content),
                Bucket: 's3-2s33-prod-splunk-logs-eu-west-1',
                Key: prefix + '/' + prefix + '-logs-' + endTime + '.json',
                ServerSideEncryption: 'AES256'
            };
            
            s3.putObject(params, function(err, data) {
                if (err) {
                    console.log('s3 err');
                    console.log(err, err.stack);
                    reject(err);
                } else {
                    resolve(data);
                }
            });
        } catch (error) {
            reject(error);
        }
    });
    return promise;
};

const updateEndTime = async function(endTime) {
    const promise = new Promise(function(resolve, reject) {
        try {
            const params = {
                FunctionName: 'monitoring-splunkcollection',
                Environment: {
                    Variables: {
                        'lastEndTime': '' + endTime
                    }
                }
            };
            
            lambda.updateFunctionConfiguration(params, function(err, data) {
                if (err) {
                    console.log('lambda err');
                    console.log(err, err.stack);
                    reject(err);
                } else {
                    resolve(data);
                }
            });
        } catch (error) {
            reject(error);
        }
    });
    return promise;
};

import json
import time
import datetime
import traceback
import boto3
from botocore.exceptions import ClientError
from requests import Session
from cryptography.hazmat.primitives import serialization
import cryptography.hazmat.primitives.serialization.pkcs12


from settings import *
from custom_logging_2s33.insider_protection_logging import InsiderProtectionLogging

logger = InsiderProtectionLogging(__name__, 'DEBUG').logger

def lambda_handler(event, context):

    message = ''
    not_valid_after = '-'
    not_valid_before = '-'
    cert_issuer = '-'
    cert_subject = '-'    
    try:
        ### TODO update ROLE to be able to access NiFi private S3 ###
        logger.info('checking client certificates file')
        
        s3_client = boto3.client('s3')          
        bucket_name = "s3-2s33-prod-nifi-eu-west-1"
        cert_s3_key = "prod-3.0.0/CN=admin_OU=NIFI.p12"
        pass_s3_key = "prod-3.0.0/CN=admin_OU=NIFI.password"
        local_cert_file = '/tmp/' + "cert.p12"
        local_pass_file = '/tmp/' + "pass.password"

        logger.info('password will be download to the local file: ' + local_pass_file)
        s3_client.download_file(bucket_name, pass_s3_key, local_pass_file)
        with open(local_pass_file) as passf:
            CLIENT_CERT_KEY = passf.readline().strip()
            logger.info("CLIENT_CERT_KEY: " + CLIENT_CERT_KEY)

        logger.info('cert will be download to the local file: ' + local_cert_file)
        s3_client.download_file(bucket_name, cert_s3_key, local_cert_file)
        with open(local_cert_file, "rb") as f:
            (
                private_key,
                certificate,
                additional_certificates,
            ) = serialization.pkcs12.load_key_and_certificates(
                f.read(), CLIENT_CERT_KEY.encode()
            )
            
        # key will be available in user readable temporary file for the time of the program run (until key and cert get gc'ed)
        not_valid_after = str(certificate.not_valid_after)
        not_valid_before = str(certificate.not_valid_before)
        cert_issuer = str(certificate.issuer)
        cert_subject = str(certificate.subject)
        #print (str(certificate.))
        #print (str(certificate.))
        message = 'client certificate has been scanned succesfully'
    except:
        message = 'an error occurs'
        logger.error('something went wrong')
        logger.error(traceback.format_exc())

    return {
        'subject': '[2s33] certificate surveil',
        'body': json.dumps(message),
        'cert_issuer' : cert_issuer,
        'cert_subject' : cert_subject,
        'not_valid_after' : not_valid_after,
        'not_valid_before' : not_valid_before
    }


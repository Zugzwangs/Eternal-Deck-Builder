
# common settings
REGION = 'eu-west-1'

# NiFi s3
NIFI_BUCKET = 's3-2s33-prod-nifi-eu-west-1'


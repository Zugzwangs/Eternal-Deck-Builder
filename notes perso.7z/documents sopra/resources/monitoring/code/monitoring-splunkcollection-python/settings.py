# common settings
REGION = 'eu-west-1'

# destination s3
LOGS_BUCKET = 's3-2s33-dev-splunk-logs-eu-west-1'

# cloudwatch logs groups
LOGS_GROUPS = ['/2s33/computing/braincell/anomalie_case/uc_46', '/2s33/computing/braincell/anomalie_case/kti_2s33']


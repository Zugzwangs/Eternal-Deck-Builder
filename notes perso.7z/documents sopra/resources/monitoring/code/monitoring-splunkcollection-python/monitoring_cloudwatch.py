import json
import time
import datetime
import traceback
import boto3
from botocore.exceptions import ClientError

from settings import *
from custom_logging_2s33.insider_protection_logging import InsiderProtectionLogging

logger = InsiderProtectionLogging(__name__, 'DEBUG').logger

def lambda_handler(event, context):

    message = ''
 
    try:
        logger.info('scan cloudwatch logs groups and ppublish new logs')
        
        s3_client = boto3.client('s3')          

        logger.info('yeah ')

    except:
        message = 'an error occurs'
        logger.error('something went wrong')
        logger.error(traceback.format_exc())

    return {
        'subject': '[2s33] cloudwatch logs publishing',
        'body': json.dumps(message),

    }

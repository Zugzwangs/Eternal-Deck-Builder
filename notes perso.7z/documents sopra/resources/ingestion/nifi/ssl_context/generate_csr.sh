#!/bin/bash
# ####################################################
# usage: generate a CSR for wildcard certificate
# edit [req_distinguished_name] section to fit your need and save the changes
# run the script and get the CSR output in /tmp/csr
# ####################################################

# specify server caracteristics
touch "/tmp/req.txt"
#private_bucket="s3-2s33-prod-nifi-eu-west-1"
private_bucket="s3-2s33-nifi-eu-west-1"
#my_domain="2s33-insiderprotection.aws.cloud.airbus.corp"
my_domain="nlb-nifi-frontend.2s33-insiderprotection.aws.cloud.airbus.corp"

echo "[req]
default_bits = 2048
distinguished_name = req_distinguished_name
prompt = no
req_extensions = req_ext

[req_ext]
subjectAltName = @alt_names

[alt_names]
IP.1 = 10.102.212.132
IP.2 = 10.102.212.164

[req_distinguished_name]
C = FR
O = Airbus
OU = DSO
CN = ${my_domain}
" > "/tmp/req.txt"

# generate private key and CSR
openssl genrsa -out "/tmp/myserver.key" 2048
openssl req -new -config "/tmp/req.txt" -key "/tmp/myserver.key" -out "/tmp/myserver.csr"

# check a CSR content
#openssl req -text -noout -verify -in "/tmp/myserver.csr"

# backup the key
aws s3 cp "/tmp/myserver.key" "s3://${private_bucket}/airbus-certs/${my_domain}/${my_domain}.key"
aws s3 cp "/tmp/myserver.csr" "s3://${private_bucket}/airbus-certs/${my_domain}/${my_domain}.csr"


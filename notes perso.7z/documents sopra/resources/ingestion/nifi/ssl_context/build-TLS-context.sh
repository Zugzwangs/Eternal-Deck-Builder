#!/bin/bash
# ####################################################
# author: ng55235
# usage: check Airbus server certificate and authority keychain
# and build java keystore/trustore from them for NiFi SSL context usage
# dependencies:
#   - airbus signed server cert (.pem)
#   - server private key (.key)
#   - Airbus CA certs (.pem)
#   - openssl, keytool

# Note: 
#   - NiFi accept JSK or PKCS12 format for stores

# TODO:
#   - handle secrets generation/export and use it in commands
# ####################################################

# define variables
#private_bucket="s3-2s33-prod-nifi-eu-west-1"
private_bucket="s3-2s33-nifi-eu-west-1"
private_key="nlb-nifi-frontend.2s33-insiderprotection.aws.cloud.airbus-v.corp.key"
server_cert="nlb-nifi-frontend.2s33-insiderprotection.aws.cloud.airbus-v.corp.pem"


# download the stuff
echo "* dowloading certificates and keys..."
echo "--------------------------------"
aws s3 cp "s3://${private_bucket}/airbus-certs/nlb-nifi-frontend.2s33-insiderprotection.aws.cloud.airbus-v.corp/${private_key}" .
aws s3 cp "s3://${private_bucket}/airbus-certs/nlb-nifi-frontend.2s33-insiderprotection.aws.cloud.airbus-v.corp/${server_cert}" .
aws s3 cp s3://${private_bucket}/airbus-certs/nlb-nifi-frontend.2s33-insiderprotection.aws.cloud.airbus-v.corp/Airbus\ S2\ sigCA\ P01.pem .
aws s3 cp s3://${private_bucket}/airbus-certs/nlb-nifi-frontend.2s33-insiderprotection.aws.cloud.airbus-v.corp/Airbus\ S2\ Intermediate\ CA\ 1.pem .
aws s3 cp s3://${private_bucket}/airbus-certs/nlb-nifi-frontend.2s33-insiderprotection.aws.cloud.airbus-v.corp/EADS\ S2\ Root\ CA\ 1.pem . 

# [optional] check private key
#openssl rsa -check -in ${private_key}
# [optional] check Airbus server cetificate:

#openssl x509 -inform PEM -in ${server_cert} # simple check/output
#openssl x509 -text -noout -in ${server_cert} # show certs details

# [optional] check CA certs details:
#openssl x509 -text -noout -in Airbus\ S2\ sigCA\ P01.pem
#openssl x509 -text -noout -in Airbus\ S2\ Intermediate\ CA\ 1.pem
#openssl x509 -text -noout -in EADS\ S2\ Root\ CA\ 1.pem

# export pkcs#1 formated key and server cert into pkcs12 format:
echo "building keystore..."
echo "--------------------------------"
openssl pkcs12 -export -in "./${server_cert}" -inkey "./${private_key}" -out "./keystore.p12"
# import the pkcs#12 structure into a java keystore
echo "converting keystore format..."
echo "--------------------------------"
keytool -importkeystore -srckeystore "./keystore.p12" -destkeystore "keystore.jks" -deststoretype JKS

# import Airbus CA certs into a truststore:
echo "building trustore..."
echo "--------------------------------"
keytool -import -alias "sigca" -file "Airbus S2 sigCA P01.pem" -storetype "JKS" -keystore "./truststore.jks"
keytool -import -alias "intermediate" -file "Airbus S2 Intermediate CA 1.pem" -storetype "JKS" -keystore "./truststore.jks"
keytool -import -alias "root" -file "EADS S2 Root CA 1.pem" -storetype "JKS" -keystore "./truststore.jks"

# show entry in keystores
#keytool -list -v -keystore "./keystore.jks"
#keytool -list -v -keystore "./truststore.jks"

# push back stores to private bucket
aws s3 cp ./keystore.jks s3://${private_bucket}/airbus-certs/nlb-nifi-frontend.2s33-insiderprotection.aws.cloud.airbus-v.corp/
aws s3 cp ./truststore.jks s3://${private_bucket}/airbus-certs/nlb-nifi-frontend.2s33-insiderprotection.aws.cloud.airbus-v.corp/

# fix an alias
#keytool -changealias -alias "your-very-very-long-alias" -destalias "new-alias" -keystore "/path/to/keystore"


#!/bin/bash

echo 'updating yum repo...'
yum-config-manager --enable rhel-7-server-rhui-extras-rpms
yum-config-manager --enable rhel-7-server-optional-rpms
yum-config-manager --enable rhel-server-rhui-rhscl-7-rpms

echo 'installing packages...'
sudo yum install -y git
sudo yum install -y nmap-ncat
sudo yum install -y java-1.8.0-openjdk.x86_64
sudo yum install -y java-1.8.0-openjdk-devel.x86_64
sudo yum install -y xmlstarlet
sudo yum install -y jq
sudo yum install -y scl-utils
sudo yum install -y scl-utils-build
sudo yum install -y rh-python38
sudo yum install -y collectd

echo 'installing additionals disks'
cd /tmp
echo 'create partitions'
mkfs.xfs /dev/nvme1n1; mkfs.xfs /dev/nvme2n1; mkfs.xfs /dev/nvme3n1; mkfs.xfs /dev/nvme4n1; mkfs.xfs /dev/nvme5n1
echo 'list all available block devices disks'
blkid | grep "nvme[1-5]" | cut -d" " -f 1,2 > block_device_list.csv
echo 'checking if we find the expected number of devices'
block_device_number=$(wc -l < block_device_list.csv)
if [[ $block_device_number == 5 ]]; then
  echo "all required block device are there."
else
  echo "only $block_device_number devices are found. Installation abord."
  exit 1
fi
echo "creating list of mount points"
echo '/mnt/content' > mount_point_list.csv
echo '/mnt/provenance' >> mount_point_list.csv
echo '/mnt/flowfile' >> mount_point_list.csv
echo '/mnt/database' >> mount_point_list.csv
echo '/mnt/install' >> mount_point_list.csv
while IFS=" " read -r field_name field_uuid field_mount_point; do
  #echo "$field_name || $field_uuid || $field_mount_point"
  device_name=${field_name//:}
  device_uuid=${field_uuid//\"}
  echo "creating ${field_mount_point} folder"
  mkdir "${field_mount_point}"
  echo "create fstab entry for device $device_name ($device_uuid)"
  echo "$device_uuid $field_mount_point   xfs   defaults,noatime 0 0" >> /etc/fstab
done < <(paste -d " " block_device_list.csv mount_point_list.csv)
echo "reload fstab"
mount -a
df -h

echo '# custom OS settings...'
echo "* hard  nofile  131072" >> /etc/security/limits.conf
echo "* soft  nofile  131072" >> /etc/security/limits.conf

echo "# custom settings for NiFi" >> /etc/sysctl.conf
echo "vm.swappiness=0" >> /etc/sysctl.conf
echo "net.ipv4.tcp_fin_timeout=10" >> /etc/sysctl.conf
echo "net.ipv4.ip_local_port_range=10000 65000" >> /etc/sysctl.conf
echo "net.core.rmem_default=262144" >> /etc/sysctl.conf
echo "net.core.wmem_default=262144" >> /etc/sysctl.conf
echo "net.core.rmem_max=16777216" >> /etc/sysctl.conf
echo "net.core.wmem_max=16777216" >> /etc/sysctl.conf
echo "net.ipv4.tcp_rmem = 4096 87380 16777216" >> /etc/sysctl.conf
echo "net.ipv4.tcp_wmem = 4096 65536 16777216 " >> /etc/sysctl.conf
# apply settings
sysctl -p

echo 'downloading conf files from private folder...'
aws s3 cp ${NIFI_CLUSTER_FOLDER}/nifi-manifest.txt /nifi-manifest.txt
aws s3 cp ${NIFI_CLUSTER_FOLDER}/nifi-hosts /tmp/nifi-hosts
cat /tmp/nifi-hosts >> /etc/hosts
grep "$INSTANCE_BASENAME-[0-9]*-" /tmp/nifi-hosts | cut -d' ' -f 2 >> /tmp/nodes-list

echo 'fetching github secret'
GITHUB_TOKEN_SECRET_NAME=/airbus/platform/secretsmanager/sa-2s33-devtool/github/v1
GITHUB_ACCESS_TOKEN_SECRET=$(aws secretsmanager get-secret-value --secret-id $GITHUB_TOKEN_SECRET_NAME --region eu-west-1)
GITHUB_ACCESS_TOKEN=$(echo $GITHUB_ACCESS_TOKEN_SECRET | jq '.SecretString | fromjson | ."github_token"' | tr -d \")

echo 'cloning infra configuration repository...'
cd ~
git clone "https://${GITHUB_ACCESS_TOKEN}@github.airbus.corp/Airbus/${INFRA_REPO}.git"
cd "$INFRA_REPO"
git_infra_repo=$(pwd)
git fetch
git checkout -t origin/$INFRA_REPO_BRANCH
git status
cp ./resources/ingestion/nifi/config/nifihome.sh /etc/profile.d/ 
source /etc/profile.d/nifihome.sh
echo 'Env var check:'
echo "  NIFI_ROOT=${NIFI_ROOT}"
echo "  NIFI_HOME=${NIFI_HOME}"
echo "  NIFI_TOOLKIT_HOME=${NIFI_TOOLKIT_HOME}"

echo 'installing CloudWatch agent...'
cd /tmp
wget -nv https://s3.amazonaws.com/amazoncloudwatch-agent/redhat/amd64/latest/amazon-cloudwatch-agent.rpm
sudo rpm -U ./amazon-cloudwatch-agent.rpm
sudo /opt/aws/amazon-cloudwatch-agent/bin/amazon-cloudwatch-agent-ctl -a fetch-config -m ec2 -c file:${git_infra_repo}/resources/ingestion/nifi/monitoring/cloudwatch_agent/nifi_cluster.json -s
sudo /opt/aws/amazon-cloudwatch-agent/bin/amazon-cloudwatch-agent-ctl -m ec2 -a start
sudo /opt/aws/amazon-cloudwatch-agent/bin/amazon-cloudwatch-agent-ctl -a append-config -m ec2 -s -c file:${git_infra_repo}/resources/ingestion/nifi/monitoring/cloudwatch_agent/nifi_nodes_metrics.json

echo 'fetching artifactory secret'
ARTIFACTORY_SECRET_NAME="/airbus/platform/secretsmanager/sa-2s33-devtool/artifactory/idtoken/v1"
ARTIFACTORY_SECRET_VALUE=$(aws secretsmanager get-secret-value --secret-id ${ARTIFACTORY_SECRET_NAME} --region eu-west-1)
ARTIFACTORY_ID_TOKEN=$(echo $ARTIFACTORY_SECRET_VALUE | jq '.SecretString | fromjson | ."identity_token"' | tr -d \")
ARTIFACTORY_ID_TOKEN=$(sed -e 's/^"//' -e 's/"$//' <<< $ARTIFACTORY_ID_TOKEN)

echo 'grabing NiFi tarballs...'
cd /tmp
ARTIFACTORY_HOST=artifactory.2b82.aws.cloud.airbus.corp
curl --retry 3 -k -H "Authorization: Bearer ${ARTIFACTORY_ID_TOKEN}" -O https://${ARTIFACTORY_HOST}/artifactory/r-2s33-insider-generic-local/nifi/nifi-${NIFI_VERSION}-bin.tar.gz
#aws s3 cp "s3://${NIFI_PRIVATE_BUCKET}/src/nifi-${NIFI_VERSION}-bin.tar.gz" "/tmp/"
curl --retry 3 -k -H "Authorization: Bearer ${ARTIFACTORY_ID_TOKEN}" -O https://${ARTIFACTORY_HOST}/artifactory/r-2s33-insider-generic-local/nifi/nifi-toolkit-${NIFI_VERSION}-bin.tar.gz
echo 'unpacking files...'
tar xzf ./nifi-${NIFI_VERSION}-bin.tar.gz -C ${NIFI_ROOT}
tar xzf ./nifi-toolkit-${NIFI_VERSION}-bin.tar.gz -C ${NIFI_ROOT}
echo 'normalize nifi install directories.'
mv ${NIFI_ROOT}/nifi-${NIFI_VERSION} ${NIFI_HOME}
mv ${NIFI_ROOT}/nifi-toolkit-${NIFI_VERSION} ${NIFI_TOOLKIT_HOME}

echo 'download certificates and stores...'
aws s3 cp ${NIFI_CLUSTER_FOLDER}/$(hostname)/keystore.jks $NIFI_HOME/conf/ 
aws s3 cp ${NIFI_CLUSTER_FOLDER}/$(hostname)/truststore.jks $NIFI_HOME/conf/
aws s3 cp ${NIFI_CLUSTER_FOLDER}/$(hostname)/nifi.properties $NIFI_HOME/conf/

echo 'download configured authorizers.xml file'
aws s3 cp ${NIFI_CLUSTER_FOLDER}/authorizers.xml ${NIFI_HOME}/conf/

echo "computed best heap size for the JVM is $java_mem"
total_mem=$(free -g | awk '/^Mem:/{print $2}')
echo "total memory in gigabytes is $total_mem"
user_space_mem=$(($total_mem - 2))
echo "memory available for application: $user_space_mem"
if [[ "$user_space_mem" -le "2" ]]; then
  echo "FATAL: no enough memory to run NiFi properly"
  exit 1
elif [[ "$user_space_mem" -gt "2" && "$user_space_mem" -le "4" ]]; then
  echo "set custom value to 2"
  java_mem="2"
elif [[ "$user_space_mem" -gt "4" && "$user_space_mem" -le "8" ]]; then
  echo "set custom value to 4"
  java_mem="4"
elif [[ "$user_space_mem" -gt "8" && "$user_space_mem" -lt "20" ]]; then
  echo "set custom value to 8"
  java_mem="8"
else
  echo "set to the MAX heap size"
  java_mem="16"
fi
echo 'update NiFi boostrap file'
mkdir "/mnt/install/nifi/tmp"
chmod -R "/mnt/install/nifi/tmp"
sed -i "/java.arg.2=/ s/=.*/=-Xms${java_mem}g/" $NIFI_HOME/conf/bootstrap.conf
sed -i "/java.arg.3=/ s/=.*/=-Xmx${java_mem}g/" $NIFI_HOME/conf/bootstrap.conf
echo "java.arg.snappy=-Dorg.xerial.snappy.tempdir=/mnt/install/nifi/tmp" >> $NIFI_HOME/conf/bootstrap.conf

echo 'update nifi properties file...'
sed -i "/nifi.flowcontroller.graceful.shutdown.period=/ s/=.*/=30 sec/" $NIFI_HOME/conf/nifi.properties
sed -i "/nifi.cluster.node.connection.timeout=/ s/=.*/=30 sec/" $NIFI_HOME/conf/nifi.properties
sed -i "/nifi.cluster.node.read.timeout=/ s/=.*/=30 sec/" $NIFI_HOME/conf/nifi.properties
sed -i "/nifi.web.https.port=/ s/=.*/=443/" $NIFI_HOME/conf/nifi.properties
sed -i "/nifi.database.directory=/ s|=.*|=/mnt/database|" $NIFI_HOME/conf/nifi.properties
sed -i "/nifi.flowfile.repository.directory=/ s|=.*|=/mnt/flowfile|" $NIFI_HOME/conf/nifi.properties
sed -i "/nifi.content.repository.directory.default=/ s|=.*|=/mnt/content|" $NIFI_HOME/conf/nifi.properties
sed -i "/nifi.provenance.repository.directory.default=/ s|=.*|=/mnt/provenance|" $NIFI_HOME/conf/nifi.properties
hstnm=$(hostname)
banner_txt="${hstnm} $(cat ~/$INFRA_REPO/standard_Airbus_IT_disclaimer_banner.txt)"
sed -i "/nifi.ui.banner.text=/ s|=.*|=${banner_txt}|" $NIFI_HOME/conf/nifi.properties
sed -i "/nifi.cluster.is.node=/ s|=.*|=true|" $NIFI_HOME/conf/nifi.properties
sed -i "/nifi.zookeeper.client.secure=/ s|=.*|=true|" $NIFI_HOME/conf/nifi.properties
connect_string=$(awk '{printf "%s:2281,", $0}' < <(grep -F 'zoo' "/tmp/nifi-hosts" |cut -d' ' -f 2 ) )
sed -i "/nifi.zookeeper.connect.string=/ s|=.*|=${connect_string}|" $NIFI_HOME/conf/nifi.properties
sed -i "/nifi.state.management.embedded.zookeeper.start=/ s|=.*|=false|" $NIFI_HOME/conf/nifi.properties
sed -i "/nifi.zookeeper.session.timeout=/ s|=.*|=60 secs|" $NIFI_HOME/conf/nifi.properties
sed -i "/nifi.zookeeper.connect.timeout=/ s|=.*|=60 secs|" $NIFI_HOME/conf/nifi.properties
xmlstarlet edit --inplace --update '/stateManagement/cluster-provider/property[@name="Connect String"]' --value ${connect_string} ${NIFI_HOME}/conf/state-management.xml
sed -i "/nifi.security.user.authorizer=/ s|=.*|=managed-authorizer|" $NIFI_HOME/conf/nifi.properties
sed -i "/nifi.security.user.login.identity.provider=/ s|=.*|=|" $NIFI_HOME/conf/nifi.properties
sed -i "/nifi.content.claim.max.appendable.size=/ s|=.*|=5 MB|" $NIFI_HOME/conf/nifi.properties
sed -i "/nifi.content.repository.archive.max.usage.percentage=/ s|=.*|=20%|" $NIFI_HOME/conf/nifi.properties
sed -i "/nifi.content.repository.archive.max.retention.period=/ s|=.*|=2 hours|" $NIFI_HOME/conf/nifi.properties

echo 'fetching sensitive props key secret'
NIFI_SENSITIVE_KEY_SECRET_NAME=/airbus/platform/secretsmanager/nifi/sensitivepropskey/v1
NIFI_SENSITIVE_KEY_SECRET=$(aws secretsmanager get-secret-value --secret-id $NIFI_SENSITIVE_KEY_SECRET_NAME --region eu-west-1)
NIFI_SENSITIVE_KEY=$(echo $NIFI_SENSITIVE_KEY_SECRET | jq '.SecretString | fromjson | ."sensitive_props_key"' | tr -d \")
echo 'set sensitive key in nifi.properties'
sed -i "/nifi.sensitive.props.key=/ s|=.*|=${NIFI_SENSITIVE_KEY}|" ${NIFI_HOME}/conf/nifi.properties

echo 'fetching Master Key secret'
NIFI_MASTER_KEY_SECRET_NAME=/airbus/platform/secretsmanager/nifi/masterkey/v1
NIFI_MASTER_KEY_SECRET=$(aws secretsmanager get-secret-value --secret-id $NIFI_MASTER_KEY_SECRET_NAME --region eu-west-1)
NIFI_MASTER_KEY=$(echo $NIFI_MASTER_KEY_SECRET | jq '.SecretString | fromjson | ."master_key"' | tr -d \")
echo 'encrypt conf with master key'
${NIFI_TOOLKIT_HOME}/bin/encrypt-config.sh -n ${NIFI_HOME}/conf/nifi.properties -b ${NIFI_HOME}/conf/bootstrap.conf -k $NIFI_MASTER_KEY

echo 'adjust NiFi logs rotation to prevent overflood...'
xmlstarlet edit --inplace -s '/configuration/appender/rollingPolicy' -t elem -n 'totalSizeCap' -v '5GB' ${NIFI_HOME}/conf/logback.xml
xmlstarlet edit --inplace -s '/configuration' -t elem -n 'logger' --var noob '$prev' -i '$noob' -t attr -n "name" -v "org.apache.nifi.processors.standard.ListenTCP" -i '$noob' -t attr -n "level" -v "DEBUG" "${NIFI_HOME}/conf/logback.xml"
echo 'get load balancer IP and hostname to declare it as a proxy'
echo "$NIFI_NLB_DNS" >> /tmp/loadbalancer.txt
echo "$(dig +short $NIFI_NLB_DNS)" >> /tmp/loadbalancer.txt
loadbalancer=$(cat /tmp/loadbalancer.txt |tr '\n' ',')
allproxyname="${loadbalancer}${NIFI_NLB_ALIAS}"
sed -i "/nifi.web.proxy.host=/ s|=.*|=${allproxyname}|" $NIFI_HOME/conf/nifi.properties

echo 'installing additional libraries'
cd ${NIFI_HOME}/extensions
cp ${git_infra_repo}/resources/ingestion/nifi/config/core-site.xml ${NIFI_HOME}/extensions
curl --retry 3 -k -H "Authorization: Bearer ${ARTIFACTORY_ID_TOKEN}" -O https://${ARTIFACTORY_HOST}/artifactory/r-2s33-insider-generic-local/nifi/hadoop-common-3.2.1.jar
curl --retry 3 -k -H "Authorization: Bearer ${ARTIFACTORY_ID_TOKEN}" -O https://${ARTIFACTORY_HOST}/artifactory/r-2s33-insider-generic-local/nifi/hadoop-aws-3.2.1.jar
curl --retry 3 -k -H "Authorization: Bearer ${ARTIFACTORY_ID_TOKEN}" -O https://${ARTIFACTORY_HOST}/artifactory/r-2s33-insider-generic-local/nifi/hadoop-client-3.2.1.jar
curl --retry 3 -k -H "Authorization: Bearer ${ARTIFACTORY_ID_TOKEN}" -O https://${ARTIFACTORY_HOST}/artifactory/r-2s33-insider-generic-local/nifi/aws-java-sdk-bundle-1.11.808.jar
curl --retry 3 -k -H "Authorization: Bearer ${ARTIFACTORY_ID_TOKEN}" -O https://${ARTIFACTORY_HOST}/artifactory/r-2s33-insider-generic-local/nifi/aws-java-sdk-1.11.807.jar

echo 'install Airbus signed certificate and CA'
mkdir -p /mnt/install/nifi/airbus
aws s3 cp s3://${NIFI_PRIVATE_BUCKET}/airbus-certs/keystore.jks /mnt/install/nifi/airbus/
aws s3 cp s3://${NIFI_PRIVATE_BUCKET}/airbus-certs/truststore.jks /mnt/install/nifi/airbus/

echo 'install flow file'
aws s3 cp ${NIFI_CLUSTER_FOLDER}/flow.xml.gz ${NIFI_HOME}/conf/flow.xml.gz
echo 'schedule flow file daily backup'
chmod u+x ${git_infra_repo}/resources/ingestion/nifi/backup/backup_flowfile.sh
(crontab -l 2>/dev/null; echo "0 22 * * * ${git_infra_repo}/resources/ingestion/nifi/backup/backup_flowfile.sh > /dev/null 2>&1") | crontab - 

echo 'install custom scripts and dependencies' >> /tmp/userdata.log
mkdir -p /mnt/install/nifi/scripts
cp ${git_infra_repo}/resources/ingestion/nifi/monitoring/generate_queueSize_metrics.sh /mnt/install/nifi/scripts
cp ${git_infra_repo}/resources/ingestion/nifi/monitoring/get_processors_states.sh /mnt/install/nifi/scripts
cp ${git_infra_repo}/resources/ingestion/nifi/scripts/athenaManagement.py /mnt/install/nifi/scripts
cp ${git_infra_repo}/resources/ingestion/nifi/scripts/anonymize.java /mnt/install/nifi/scripts
cp ${git_infra_repo}/resources/ingestion/nifi/scripts/backflow_processing.groovy /mnt/install/nifi/scripts
cp ${git_infra_repo}/resources/ingestion/nifi/scripts/splitByDate.java /mnt/install/nifi/scripts

echo 'install python3.8 dependencies for custom scripts'
source scl_source enable rh-python38
pip install --upgrade pip
pip install pyarrow
pip install boto3

echo 'install maven for custom scripts'
LIB_FOLDER="/usr/lib"
MVN_VERSION="3.8.1"
MVN_BIN="apache-maven-${MVN_VERSION}-bin"
cd ${LIB_FOLDER}
curl --retry 3 -k -H "Authorization: Bearer ${ARTIFACTORY_ID_TOKEN}" -O https://${ARTIFACTORY_HOST}/artifactory/r-2s33-insider-generic-local/nifi/${MVN_BIN}.tar.gz
tar -C ${LIB_FOLDER} -xzvf ${LIB_FOLDER}/${MVN_BIN}.tar.gz
rm -y ${LIB_FOLDER}/${MVN_BIN}.tar.gz
ln -s /usr/lib/apache-maven-$MVN_VERSION/bin/mvn /usr/bin/mvn
export JAVA_HOME=/usr/lib/jvm/java-1.8.0-openjdk	# Set JAVA home (if needed)

echo 'install custom sorting script'
cp -R ${git_infra_repo}/resources/ingestion/nifi/scripts/grouperAttributes/ /mnt/install/nifi/scripts/
cd /mnt/install/nifi/scripts/grouperAttributes/
mvn package -Dmaven.test.skip=true  #build library for the script

echo 'daemonize NiFi and start it...'
$NIFI_HOME/bin/nifi.sh install
service nifi start



exit 0


#!/bin/bash

echo 'updating and installing packages'
sudo yum install -y git
sudo yum install -y nmap-ncat
sudo yum install -y java-1.8.0-openjdk.x86_64
sudo yum install -y xmlstarlet
sudo yum install -y jq

sudo groupadd zookeeper
sudo useradd -g zookeeper -d /opt/zookeeper -s /sbin/nologin zookeeper

echo 'fetch contextual data from private bucket'
aws s3 cp ${NIFI_CLUSTER_FOLDER}/nifi-manifest.txt /nifi-manifest.txt 
aws s3 cp ${NIFI_CLUSTER_FOLDER}/nifi-hosts /tmp/nifi-hosts
cat /tmp/nifi-hosts >> /etc/hosts

echo 'fetching github secret'
GITHUB_TOKEN_SECRET_NAME=/airbus/platform/secretsmanager/sa-2s33-devtool/github/v1
GITHUB_ACCESS_TOKEN_SECRET=$(aws secretsmanager get-secret-value --secret-id $GITHUB_TOKEN_SECRET_NAME --region eu-west-1)
GITHUB_ACCESS_TOKEN=$(echo $GITHUB_ACCESS_TOKEN_SECRET | jq '.SecretString | fromjson | ."github_token"' | tr -d \")

echo 'cloning infra configuration repository'
cd ~
git clone "https://${GITHUB_ACCESS_TOKEN}@github.airbus.corp/Airbus/${INFRA_REPO}.git"
cd $INFRA_REPO
git_infra_repo=$(pwd)
git fetch
git checkout -t origin/$INFRA_REPO_BRANCH
git status

echo 'installing CloudWatch agent...'
cd /tmp
wget -nv https://s3.amazonaws.com/amazoncloudwatch-agent/redhat/amd64/latest/amazon-cloudwatch-agent.rpm
sudo rpm -U ./amazon-cloudwatch-agent.rpm
sudo /opt/aws/amazon-cloudwatch-agent/bin/amazon-cloudwatch-agent-ctl -a fetch-config -m ec2 -c file:${git_infra_repo}/resources/ingestion/nifi/monitoring/cloudwatch_agent/zookeeper.json -s
sudo /opt/aws/amazon-cloudwatch-agent/bin/amazon-cloudwatch-agent-ctl -m ec2 -a start            



echo 'fetching artifactory secret'
ARTIFACTORY_SECRET_NAME="/airbus/platform/secretsmanager/sa-2s33-devtool/artifactory/idtoken/v1"
ARTIFACTORY_SECRET_VALUE=$(aws secretsmanager get-secret-value --secret-id ${ARTIFACTORY_SECRET_NAME} --region eu-west-1)
ARTIFACTORY_ID_TOKEN=$(echo $ARTIFACTORY_SECRET_VALUE | jq '.SecretString | fromjson | ."identity_token"' | tr -d \")
ARTIFACTORY_ID_TOKEN=$(sed -e 's/^"//' -e 's/"$//' <<< $ARTIFACTORY_ID_TOKEN)

echo 'download zookeeper'
cd /tmp
ARTIFACTORY_HOST=artifactory.2b82.aws.cloud.airbus.corp
curl --retry 3 -k -v -H "Authorization: Bearer ${ARTIFACTORY_ID_TOKEN}" -O https://${ARTIFACTORY_HOST}/artifactory/r-2s33-insider-generic-local/nifi/apache-zookeeper-${ZOOKEEPER_VERSION}-bin.tar.gz
tar xvzf ./apache-zookeeper-${ZOOKEEPER_VERSION}-bin.tar.gz  -C /tmp
mv -f /tmp/apache-zookeeper-${ZOOKEEPER_VERSION}-bin/* /opt/zookeeper

echo 'configure zookeeper cfg file'
cd /opt/zookeeper
cp "${git_infra_repo}/resources/ingestion/nifi/zookeeper/zoo.cfg" "/opt/zookeeper/conf/zoo.cfg"
counter_id=1
while IFS=" " read -r current_ip current_name; do
    echo "server.${counter_id}=${current_name}:2888:3888" >> "/opt/zookeeper/conf/zoo.cfg"
    ((counter_id++))
done < <(grep -F 'zoo' "/tmp/nifi-hosts")
mkdir /opt/zookeeper/data
echo "${ZOOKEEPER_ID}" >> /opt/zookeeper/data/myid

echo 'download generated certificate for TLS setup'
zoo_cert_path="/opt/zookeeper/trust"
mkdir "${zoo_cert_path}"
cd "${zoo_cert_path}"
aws s3 cp ${NIFI_CLUSTER_FOLDER}/$(hostname)/keystore.jks "${zoo_cert_path}/" 
aws s3 cp ${NIFI_CLUSTER_FOLDER}/$(hostname)/truststore.jks "${zoo_cert_path}/" 
aws s3 cp ${NIFI_CLUSTER_FOLDER}/$(hostname)/nifi.properties "${zoo_cert_path}/"

echo 'retrieve keystore passwords'
keystorePasswd=$(cat "${zoo_cert_path}/nifi.properties" | grep -F "nifi.security.keystorePasswd=" | cut -d"=" -f 2-)
truststorePasswd=$(cat "${zoo_cert_path}/nifi.properties" | grep -F "nifi.security.truststorePasswd=" | cut -d"=" -f 2-)

echo 'setup zookeeper TLS configuration'
echo "sslQuorum=true" >> "/opt/zookeeper/conf/zoo.cfg"
echo "serverCnxnFactory=org.apache.zookeeper.server.NettyServerCnxnFactory" >> "/opt/zookeeper/conf/zoo.cfg"
echo "ssl.quorum.keyStore.location=${zoo_cert_path}/keystore.jks" >> "/opt/zookeeper/conf/zoo.cfg"
echo "ssl.quorum.keyStore.password=${keystorePasswd}" >> "/opt/zookeeper/conf/zoo.cfg"
echo "ssl.quorum.trustStore.location=${zoo_cert_path}/truststore.jks" >> "/opt/zookeeper/conf/zoo.cfg"
echo "ssl.quorum.trustStore.password=${truststorePasswd}" >> "/opt/zookeeper/conf/zoo.cfg"
echo "secureClientPort=2281" >> "/opt/zookeeper/conf/zoo.cfg"
echo "ssl.hostnameVerification=false" >> "/opt/zookeeper/conf/zoo.cfg"
echo "authProvider.x509=org.apache.zookeeper.server.auth.X509AuthenticationProvider" >> "/opt/zookeeper/conf/zoo.cfg"
echo "ssl.keyStore.location=${zoo_cert_path}/keystore.jks" >> "/opt/zookeeper/conf/zoo.cfg"
echo "ssl.keyStore.password=${keystorePasswd}" >> "/opt/zookeeper/conf/zoo.cfg"
echo "ssl.trustStore.location=${zoo_cert_path}/truststore.jks" >> "/opt/zookeeper/conf/zoo.cfg"
echo "ssl.trustStore.password=${truststorePasswd}" >> "/opt/zookeeper/conf/zoo.cfg"
echo "audit.enable=true" >> "/opt/zookeeper/conf/zoo.cfg"

echo 'install zookeeper as a service'
chown -R zookeeper:zookeeper /opt/zookeeper
cp ${git_infra_repo}/resources/ingestion/nifi/zookeeper/zookeeper.service  '/usr/lib/systemd/system/zookeeper.service'
sudo systemctl daemon-reload
systemctl start zookeeper
systemctl enable zookeeper

exit 0


#!/bin/bash

echo 'updating yum repo...' 
yum-config-manager --enable rhel-7-server-rhui-extras-rpms 
yum-config-manager --enable rhel-7-server-optional-rpms 
yum-config-manager --enable rhel-server-rhui-rhscl-7-rpms 

echo 'installing packages...'
sudo yum install -y git 
sudo yum install -y nmap-ncat 
sudo yum install -y java-1.8.0-openjdk.x86_64 
sudo yum install -y xmlstarlet 
sudo yum install -y jq 

echo 'building NiFi manifest file...'
MANIFEST_FILE='/nifi-manifest.txt' 
echo "NIFI_VERSION=$NIFI_VERSION" >> $MANIFEST_FILE 
echo "REGISTRY_VERSION=$NIFI_REGISTRY_VERSION" >> $MANIFEST_FILE 
echo "NIFI_CLUSTER_VERSION=$ENVIRONMENT-$ETL_VERSION" >> $MANIFEST_FILE 
echo "NIFI_PRIVATE_BUCKET=s3://$NIFI_PRIVATE_BUCKET_NAME" >> $MANIFEST_FILE 
echo "PRIVATE_CLUSTER_FOLDER=${NIFI_CLUSTER_FOLDER}" >> $MANIFEST_FILE 
echo "NIFI_NLB_DNS=${NIFI_NLB_DNS}" >> $MANIFEST_FILE 
echo "NIFI_NLB_ALIAS=${NIFI_NLB_ALIAS}" >> $MANIFEST_FILE 
echo "REGISTRY_NLB_DNS=${REGISTRY_NLB_DNS}" >> $MANIFEST_FILE 
echo "REGISTRY_NLB_ALIAS=${REGISTRY_NLB_ALIAS}" >> $MANIFEST_FILE 

echo 'publishing manifest to the private bucket'
aws s3 cp "$MANIFEST_FILE" "${NIFI_CLUSTER_FOLDER}/"

echo 'building NiFi cluster hosts file...' 
echo $(hostname --all-ip-addresses)  $(hostname)  >> /tmp/nifi-hosts 
echo "$ETH0R $INSTANCE_BASENAME-reg-$ENVIRONMENT.$TARGET_DOMAIN" >> /tmp/nifi-hosts 
echo "$ETH0Z1 zoo-1-$ENVIRONMENT.$TARGET_DOMAIN" >> /tmp/nifi-hosts 
echo "$ETH0Z2 zoo-2-$ENVIRONMENT.$TARGET_DOMAIN" >> /tmp/nifi-hosts 
echo "$ETH0Z3 zoo-3-$ENVIRONMENT.$TARGET_DOMAIN" >> /tmp/nifi-hosts 
echo "$ETH0A $INSTANCE_BASENAME-1-$ENVIRONMENT.$TARGET_DOMAIN" >> /tmp/nifi-hosts 
echo "$ETH0B $INSTANCE_BASENAME-2-$ENVIRONMENT.$TARGET_DOMAIN" >> /tmp/nifi-hosts 
echo "$ETH0C $INSTANCE_BASENAME-3-$ENVIRONMENT.$TARGET_DOMAIN" >> /tmp/nifi-hosts 
cat /tmp/nifi-hosts >> /etc/hosts 
echo 'publishing hosts file to the private bucket' 
aws s3 cp "/tmp/nifi-hosts" "${NIFI_CLUSTER_FOLDER}/nifi-hosts"

echo 'fetching github secret'
GITHUB_TOKEN_SECRET_NAME=/airbus/platform/secretsmanager/sa-2s33-devtool/github/v1
GITHUB_ACCESS_TOKEN_SECRET=$(aws secretsmanager get-secret-value --secret-id $GITHUB_TOKEN_SECRET_NAME --region eu-west-1)
GITHUB_ACCESS_TOKEN=$(echo $GITHUB_ACCESS_TOKEN_SECRET | jq '.SecretString | fromjson | ."github_token"' | tr -d \")

echo 'cloning infra configuration repository...' 
cd ~ 
git clone "https://${GITHUB_ACCESS_TOKEN}@github.airbus.corp/Airbus/${INFRA_REPO}.git"
cd "${INFRA_REPO}"
git_infra_repo=$(pwd)
git fetch 
git checkout -t origin/"$INFRA_REPO_BRANCH"

echo 'installing CloudWatch agent...' 
cd /tmp 
wget https://s3.amazonaws.com/amazoncloudwatch-agent/redhat/amd64/latest/amazon-cloudwatch-agent.rpm 
sudo rpm -U ./amazon-cloudwatch-agent.rpm 
sudo /opt/aws/amazon-cloudwatch-agent/bin/amazon-cloudwatch-agent-ctl -a fetch-config -m ec2 -c file:${git_infra_repo}/resources/ingestion/nifi/monitoring/cloudwatch_agent/nifi_caserver.json -s 
sudo /opt/aws/amazon-cloudwatch-agent/bin/amazon-cloudwatch-agent-ctl -m ec2 -a start 

echo 'generating nifi authorizers file' 
cp ${git_infra_repo}/resources/ingestion/nifi/config/authorizers.xml /tmp 
cd /tmp 
xmlstarlet edit --inplace --update '/authorizers/userGroupProvider/property[@name="Initial User Identity 1"]' --value "CN=admin, OU=NIFI" /tmp/authorizers.xml 
xmlstarlet edit --inplace --update '/authorizers/accessPolicyProvider/property[@name="Initial Admin Identity"]' --value "CN=admin, OU=NIFI" /tmp/authorizers.xml 
counter_id=1 
while IFS=" " read -r current_ip current_name; do 
  echo "  - inserting $current_name elements " 
  current_dn="CN=${current_name}, OU=NIFI" 
  xmlstarlet edit --inplace -s '/authorizers/accessPolicyProvider' -t elem -n "property" -v "${current_dn}" /tmp/authorizers.xml 
  xmlstarlet edit --inplace --var tempname "'${current_dn}'" -i '/authorizers/accessPolicyProvider/property[.=$tempname]' -t attr -n "name" -v "Node Identity $counter_id"  /tmp/authorizers.xml 
  ((counter_id++)) 
  xmlstarlet edit --inplace -s '/authorizers/userGroupProvider' -t elem -n "property" -v "${current_dn}" /tmp/authorizers.xml 
  xmlstarlet edit --inplace --var tempname "'${current_dn}'" -i '/authorizers/userGroupProvider/property[.=$tempname]' -t attr -n "name" -v "Initial User Identity $counter_id"  /tmp/authorizers.xml 
done < <(grep "$INSTANCE_BASENAME-[1-9]-" "/tmp/nifi-hosts") 
echo 'uploading authorizers.xml to private bucket' 
aws s3 cp /tmp/authorizers.xml ${NIFI_CLUSTER_FOLDER}/ 

echo 'generating registry authorizers file' 
cp ${git_infra_repo}/resources/ingestion/nifi/config/authorizers-registry.xml /tmp 
cd /tmp 
counter_id=1 
while IFS=" " read -r current_ip current_name; do 
  echo "  - inserting $current_name elements " 
  current_dn="CN=${current_name}, OU=NIFI" 
  ((counter_id++)) 
  xmlstarlet edit --inplace -s '/authorizers/userGroupProvider' -t elem -n "property" -v "${current_dn}" /tmp/authorizers-registry.xml 
  xmlstarlet edit --inplace --var tempname "'${current_dn}'" -i '/authorizers/userGroupProvider/property[.=$tempname]' -t attr -n "name" -v "Initial User Identity $counter_id"  /tmp/authorizers-registry.xml 
done < <(grep "$INSTANCE_BASENAME-[1-9]-" "/tmp/nifi-hosts")               
echo 'uploading authorizers-registry.xml to private bucket' 
aws s3 cp /tmp/authorizers-registry.xml ${NIFI_CLUSTER_FOLDER}/ 

echo 'fetching artifactory secret'
ARTIFACTORY_SECRET_NAME="/airbus/platform/secretsmanager/sa-2s33-devtool/artifactory/idtoken/v1"
ARTIFACTORY_SECRET_VALUE=$(aws secretsmanager get-secret-value --secret-id ${ARTIFACTORY_SECRET_NAME} --region eu-west-1)
ARTIFACTORY_ID_TOKEN=$(echo $ARTIFACTORY_SECRET_VALUE | jq '.SecretString | fromjson | ."identity_token"' | tr -d \")
ARTIFACTORY_ID_TOKEN=$(sed -e 's/^"//' -e 's/"$//' <<< $ARTIFACTORY_ID_TOKEN)

echo 'installing NiFi toolkit...' 
cd /tmp 
ARTIFACTORY_HOST=artifactory.2b82.aws.cloud.airbus.corp
curl -k -H "Authorization: Bearer ${ARTIFACTORY_ID_TOKEN}" -O https://${ARTIFACTORY_HOST}/artifactory/r-2s33-insider-generic-local/nifi/nifi-toolkit-${NIFI_VERSION}-bin.tar.gz 
echo 'unpacking toolkit tarball...' 
tar xvzf ./nifi-toolkit-${NIFI_VERSION}-bin.tar.gz -C /opt 

echo 'creating certificate for all NiFi instances...' 
cd /opt/nifi-toolkit-${NIFI_VERSION} 
mkdir target 
aws s3 cp "s3://$NIFI_PRIVATE_BUCKET_NAME/nifi-cert.pem" "./target" 
aws s3 cp "s3://$NIFI_PRIVATE_BUCKET_NAME/nifi-key.key" "./target" 

echo 'fetching NiFi load balancer hostname, alias and IPs'  
nlb_nifi_hostname="$NIFI_NLB_DNS" 
nbl_alias="$NIFI_NLB_ALIAS"
echo "$(dig +short ${nlb_nifi_hostname})" >> /tmp/loadbalancer.txt 
nlb_ip_a=$(sed '1q;d' /tmp/loadbalancer.txt) 
nlb_ip_b=$(sed '2q;d' /tmp/loadbalancer.txt) 

echo 'fetching Registry load balancer hostname and IP'
nlb_registry_hostname="$REGISTRY_NLB_DNS"
nlb_registry_alias="$REGISTRY_NLB_ALIAS"
nlb_registry_ip=$(dig +short ${nlb_registry_hostname}) # TODO complete the line to put clean IPv4 address into the var

# certificate for NiFi nodes:
while IFS=" " read -r current_ip current_name; do 
    echo "generating $current_name certificate..."
    ./bin/tls-toolkit.sh standalone -d '365' -n ${current_name} --subjectAlternativeNames ${current_ip},${nlb_nifi_hostname},${nbl_alias},${nlb_ip_a},${nlb_ip_b} -o './target' 
    aws s3 cp --recursive ./target/${current_name} ${NIFI_CLUSTER_FOLDER}/${current_name} 
done < <(grep -vF 'zoo' "/tmp/nifi-hosts"| grep -vF 'registry') 
# certificate for the registry:
while IFS=" " read -r current_ip current_name; do 
    echo "generating registry certificate..."
    ./bin/tls-toolkit.sh standalone -d '365' -n ${current_name} --subjectAlternativeNames ${current_ip},${nlb_registry_hostname},${nlb_registry_alias},${nlb_registry_ip} -o './target' 
    aws s3 cp --recursive ./target/${current_name} ${NIFI_CLUSTER_FOLDER}/${current_name} 
done < <(grep -F 'registry' "/tmp/nifi-hosts") 
# certificate for Zookeeper nodes:
while IFS=" " read -r current_ip current_name; do 
    echo "generating registry certificate..."
    ./bin/tls-toolkit.sh standalone -d '365' -n ${current_name} --subjectAlternativeNames ${current_ip} -o './target' 
    aws s3 cp --recursive ./target/${current_name} ${NIFI_CLUSTER_FOLDER}/${current_name} 
done < <(grep -F 'zoo' "/tmp/nifi-hosts") 

echo 'creating clients certificates...' 
./bin/tls-toolkit.sh standalone -C 'CN=admin, OU=NIFI' -C 'CN=developer, OU=NIFI' -o './target' 
aws s3 cp ./target/ ${NIFI_CLUSTER_FOLDER} --recursive --exclude "*" --include "*.p12" 
aws s3 cp ./target/ ${NIFI_CLUSTER_FOLDER} --recursive --exclude "*" --include "*.password"
aws s3 cp ./target/nifi-cert.pem ${NIFI_CLUSTER_FOLDER}/ 
aws s3 cp ./target/nifi-key.key ${NIFI_CLUSTER_FOLDER}/ 

echo 'generating flow file from backup' 
cd /tmp 
registry_ip="$ETH0R" 
aws s3 cp "$BACKUP_FLOW_FILE_URI" "./flow.xml.gz"
if [ -r ./flow.xml.gz ]; then 
  echo 'backup file found, updating registry IP value...' 
  gzip -d ./flow.xml.gz 
  xmlstarlet edit --inplace --update '/flowController/registries/flowRegistry/url' --value https://${registry_ip}:443 ./flow.xml 
  gzip ./flow.xml 
else 
  echo 'no flow file backup found, generating new one...' 
  cp ${git_infra_repo}/resources/ingestion/nifi/config/flow.xml . 
  xmlstarlet edit --inplace --update '/flowController/registries/flowRegistry/name' --value "$ENVIRONMENT registry" ./flow.xml 
  xmlstarlet edit --inplace --update '/flowController/registries/flowRegistry/url' --value https://${registry_ip}:443 ./flow.xml 
  xmlstarlet edit --inplace --update '/flowController/registries/flowRegistry/description' --value 'auto generated during provisionning' ./flow.xml 
  gzip ./flow.xml 
fi 
echo 'publishing flow file on private bucket' 
aws s3 cp ./flow.xml.gz ${NIFI_CLUSTER_FOLDER}/flow.xml.gz 

exit 0
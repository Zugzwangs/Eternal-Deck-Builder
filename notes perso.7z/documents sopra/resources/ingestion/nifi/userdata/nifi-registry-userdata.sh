#!/bin/bash
     
echo 'updating yum repo...' 
yum-config-manager --enable rhel-7-server-rhui-extras-rpms
yum-config-manager --enable rhel-7-server-optional-rpms
yum-config-manager --enable rhel-server-rhui-rhscl-7-rpms

echo 'installing packages...'
sudo yum install -y git
sudo yum install -y nmap-ncat
sudo yum install -y java-1.8.0-openjdk.x86_64 
sudo yum install -y xmlstarlet 
sudo yum install -y jq 

echo 'fetching github secret'
GITHUB_TOKEN_SECRET_NAME=/airbus/platform/secretsmanager/sa-2s33-devtool/github/v1
GITHUB_ACCESS_TOKEN_SECRET=$(aws secretsmanager get-secret-value --secret-id $GITHUB_TOKEN_SECRET_NAME --region eu-west-1)
GITHUB_ACCESS_TOKEN=$(echo $GITHUB_ACCESS_TOKEN_SECRET | jq '.SecretString | fromjson | ."github_token"' | tr -d \")

echo 'cloning infra configuration repository...' 
cd ~ 
git clone "https://${GITHUB_ACCESS_TOKEN}@github.airbus.corp/Airbus/${INFRA_REPO}.git"
cd "${INFRA_REPO}"
git_infra_repo=$(pwd)
git fetch 
git checkout -t origin/"$INFRA_REPO_BRANCH"
git status

echo 'downloading conf files from private folder...' 
aws s3 cp ${NIFI_CLUSTER_FOLDER}/nifi-manifest.txt /nifi-manifest.txt 
aws s3 cp ${NIFI_CLUSTER_FOLDER}/nifi-hosts /tmp/nifi-hosts 
cat /tmp/nifi-hosts >> /etc/hosts 
grep "$INSTANCE_BASENAME-[0-9]*-" /tmp/nifi-hosts | cut -d' ' -f 2 >> /tmp/nodes-list 
NIFI_REGISTRY_HOME=/opt/nifi-registry 
NIFI_TOOLKIT_HOME=/opt/nifi-toolkit 

echo 'installing cloudwatch...'
cd /tmp 
wget https://s3.amazonaws.com/amazoncloudwatch-agent/redhat/amd64/latest/amazon-cloudwatch-agent.rpm 
sudo rpm -U ./amazon-cloudwatch-agent.rpm 
sudo /opt/aws/amazon-cloudwatch-agent/bin/amazon-cloudwatch-agent-ctl -a fetch-config -m ec2 -c file:${git_infra_repo}/resources/ingestion/nifi/monitoring/cloudwatch_agent/nifi_registry.json -s 
sudo /opt/aws/amazon-cloudwatch-agent/bin/amazon-cloudwatch-agent-ctl -m ec2 -a start 

echo 'fetching artifactory secret'
ARTIFACTORY_SECRET_NAME="/airbus/platform/secretsmanager/sa-2s33-devtool/artifactory/idtoken/v1"
ARTIFACTORY_SECRET_VALUE=$(aws secretsmanager get-secret-value --secret-id ${ARTIFACTORY_SECRET_NAME} --region eu-west-1)
ARTIFACTORY_ID_TOKEN=$(echo $ARTIFACTORY_SECRET_VALUE | jq '.SecretString | fromjson | ."identity_token"' | tr -d \")
ARTIFACTORY_ID_TOKEN=$(sed -e 's/^"//' -e 's/"$//' <<< $ARTIFACTORY_ID_TOKEN)


echo 'grabing NiFi Registry tarballs...'
cd /tmp
ARTIFACTORY_HOST=artifactory.2b82.aws.cloud.airbus.corp 
curl -k -H "Authorization: Bearer ${ARTIFACTORY_ID_TOKEN}" -O https://${ARTIFACTORY_HOST}/artifactory/r-2s33-insider-generic-local/nifi/nifi-registry-$NIFI_REGISTRY_VERSION-bin.tar.gz 
curl -k -H "Authorization: Bearer ${ARTIFACTORY_ID_TOKEN}" -O https://${ARTIFACTORY_HOST}/artifactory/r-2s33-insider-generic-local/nifi/nifi-toolkit-$NIFI_VERSION-bin.tar.gz 
echo 'unpacking files...'
tar xvzf "./nifi-registry-$NIFI_REGISTRY_VERSION-bin.tar.gz" -C /opt 
mv "/opt/nifi-registry-$NIFI_REGISTRY_VERSION" ${NIFI_REGISTRY_HOME}
tar xvzf "./nifi-toolkit-$NIFI_VERSION-bin.tar.gz" -C /tmp 
mv "/tmp/nifi-toolkit-$NIFI_VERSION" ${NIFI_TOOLKIT_HOME} 
cd $NIFI_REGISTRY_HOME 

echo 'download certificates and stores...' 
aws s3 cp ${NIFI_CLUSTER_FOLDER}/$(hostname)/keystore.jks $NIFI_REGISTRY_HOME/conf/ 
aws s3 cp ${NIFI_CLUSTER_FOLDER}/$(hostname)/truststore.jks $NIFI_REGISTRY_HOME/conf/ 
aws s3 cp ${NIFI_CLUSTER_FOLDER}/$(hostname)/nifi.properties $NIFI_REGISTRY_HOME/conf/ 
echo 'download configured authorizers.xml file' 
aws s3 cp ${NIFI_CLUSTER_FOLDER}/authorizers-registry.xml ${NIFI_REGISTRY_HOME}/conf/authorizers.xml 

echo 'update nifi properties file...' 
keystore=$(grep -F "nifi.security.keystore=" $NIFI_REGISTRY_HOME/conf/nifi.properties | cut -d'=' -f2) 
keystoreType=$(grep -F "nifi.security.keystoreType=" $NIFI_REGISTRY_HOME/conf/nifi.properties | cut -d'=' -f2) 
keystorePasswd=$(grep -F "nifi.security.keystorePasswd=" $NIFI_REGISTRY_HOME/conf/nifi.properties | cut -d'=' -f2) 
keyPasswd=$(grep -F "nifi.security.keyPasswd=" $NIFI_REGISTRY_HOME/conf/nifi.properties | cut -d'=' -f2) 
truststore=$(grep -F "nifi.security.truststore=" $NIFI_REGISTRY_HOME/conf/nifi.properties | cut -d'=' -f2) 
truststoreType=$(grep -F "nifi.security.truststoreType=" $NIFI_REGISTRY_HOME/conf/nifi.properties | cut -d'=' -f2) 
truststorePasswd=$(grep -F "nifi.security.truststorePasswd=" $NIFI_REGISTRY_HOME/conf/nifi.properties | cut -d'=' -f2) 
httpshostname=$(grep -F "nifi.web.https.host=" $NIFI_REGISTRY_HOME/conf/nifi.properties | cut -d'=' -f2) 
sed -i "/nifi.registry.security.keystore=/ s|=.*|=${keystore}|" $NIFI_REGISTRY_HOME/conf/nifi-registry.properties 
sed -i "/nifi.registry.security.keystoreType=/ s|=.*|=${keystoreType}|" $NIFI_REGISTRY_HOME/conf/nifi-registry.properties 
sed -i "/nifi.registry.security.keystorePasswd=/ s|=.*|=${keystorePasswd}|" $NIFI_REGISTRY_HOME/conf/nifi-registry.properties 
sed -i "/nifi.registry.security.keyPasswd=/ s|=.*|=${keyPasswd}|" $NIFI_REGISTRY_HOME/conf/nifi-registry.properties 
sed -i "/nifi.registry.security.truststore=/ s|=.*|=${truststore}|" $NIFI_REGISTRY_HOME/conf/nifi-registry.properties 
sed -i "/nifi.registry.security.truststoreType=/ s|=.*|=${truststoreType}|" $NIFI_REGISTRY_HOME/conf/nifi-registry.properties 
sed -i "/nifi.registry.security.truststorePasswd=/ s|=.*|=${truststorePasswd}|" $NIFI_REGISTRY_HOME/conf/nifi-registry.properties 
sed -i "/nifi.registry.web.http.host=/ s|=.*|=|" $NIFI_REGISTRY_HOME/conf/nifi-registry.properties 
sed -i "/nifi.registry.web.https.host=/ s|=.*|=${httpshostname}|" $NIFI_REGISTRY_HOME/conf/nifi-registry.properties 
sed -i "/nifi.registry.web.http.port=/ s|=.*|=|" $NIFI_REGISTRY_HOME/conf/nifi-registry.properties 
sed -i "/nifi.registry.web.https.port=/ s|=.*|=443|" $NIFI_REGISTRY_HOME/conf/nifi-registry.properties 

echo 'fetching sensitive props key secret'
NIFI_SENSITIVE_KEY_SECRET_NAME=/airbus/platform/secretsmanager/nifi/sensitivepropskey/v1
NIFI_SENSITIVE_KEY_SECRET=$(aws secretsmanager get-secret-value --secret-id $NIFI_SENSITIVE_KEY_SECRET_NAME --region eu-west-1)
NIFI_SENSITIVE_KEY=$(echo $NIFI_SENSITIVE_KEY_SECRET | jq '.SecretString | fromjson | ."sensitive_props_key"' | tr -d \")
# TODO don't remember if i need to set sensitive props key here (we are using secret now)
#sed -i "/nifi.sensitive.props.key=/ s|=.*|=${NIFI_SENSITIVE_KEY}|" $NIFI_REGISTRY_HOME/conf/nifi-registry.properties 

echo 'fetching Master Key secret'
NIFI_MASTER_KEY_SECRET_NAME=/airbus/platform/secretsmanager/nifi/masterkey/v1
NIFI_MASTER_KEY_SECRET=$(aws secretsmanager get-secret-value --secret-id $NIFI_MASTER_KEY_SECRET_NAME --region eu-west-1)
NIFI_MASTER_KEY=$(echo $NIFI_MASTER_KEY_SECRET | jq '.SecretString | fromjson | ."master_key"' | tr -d \")

echo 'encrypt Registry configuration files.' 
${NIFI_TOOLKIT_HOME}/bin/encrypt-config.sh --nifiRegistry -r ${NIFI_REGISTRY_HOME}/conf/nifi-registry.properties -b ${NIFI_REGISTRY_HOME}/conf/bootstrap.conf -k "$NIFI_MASTER_KEY"

echo 'tuning NiFi bootstrap...'
sed -i "/java.arg.2=/ s/=.*/=-Xms1g/" $NIFI_REGISTRY_HOME/conf/bootstrap.conf 
sed -i "/java.arg.3=/ s/=.*/=-Xmx1g/" $NIFI_REGISTRY_HOME/conf/bootstrap.conf 

echo 'Link registry to GitHub...' 
cd $NIFI_REGISTRY_HOME 
git clone "https://${GITHUB_ACCESS_TOKEN}@github.airbus.corp/Airbus/${REGISTRY_REPO}.git" 
cd "${REGISTRY_REPO}" 
git fetch 
git checkout -t origin/${REGISTRY_REPO_BRANCH}
git status

echo "setup post commit git hook"
echo "#!/bin/bash" > "${NIFI_REGISTRY_HOME}/${REGISTRY_REPO}/.git/hooks/post-commit"
echo "git push origin" >> "${NIFI_REGISTRY_HOME}/${REGISTRY_REPO}/.git/hooks/post-commit"
chmod ugo+x "${NIFI_REGISTRY_HOME}/${REGISTRY_REPO}/.git/hooks/post-commit"

echo "setup local repo as flow provider"
cp -f ${git_infra_repo}/resources/ingestion/nifi/config/providers.xml ${NIFI_REGISTRY_HOME}/conf/providers.xml 
xmlstarlet edit  --inplace --update '/providers/flowPersistenceProvider/property[@name="Remote Access Password"]' --value "$GITHUB_ACCESS_TOKEN" ${NIFI_REGISTRY_HOME}/conf/providers.xml 
xmlstarlet edit  --inplace --update '/providers/flowPersistenceProvider/property[@name="Flow Storage Directory"]' --value "${NIFI_REGISTRY_HOME}/$REGISTRY_REPO" ${NIFI_REGISTRY_HOME}/conf/providers.xml 


echo 'daemonize NiFi Registry...'
${NIFI_REGISTRY_HOME}/bin/nifi-registry.sh install 
service nifi-registry start 

echo 'spawning ACL...'
sleep 30 
cd ${git_infra_repo}/resources/ingestion/nifi/config 
chmod u+x ./registry-acl-deployment.sh 
./registry-acl-deployment.sh

exit 0
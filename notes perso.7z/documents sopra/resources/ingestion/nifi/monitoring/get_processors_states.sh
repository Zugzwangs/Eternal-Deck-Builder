#!/bin/bash
# #####################################################################
# author: ng55235
# usage: request NiFi API to get all relevant queue size in the Flow
# dependencies:
#   - NiFi client cert with password file
#   - NiFi registry IP/hostname
#   - wget, jq, openssl
# ressources:
#   - http://nifi.apache.org/docs/nifi-registry-docs/rest-api/index.html
# #####################################################################

#################################################################################################
# Handle positionnals parameters
#################################################################################################
myself=$(basename "$0")
absolute_script_path=$(readlink -f "$0")
working_directory=$(dirname "$absolute_script_path")
log_file="/tmp/get_processors_states.log"
buffer_id_file="/tmp/processor_id_list.txt"  # default ID file
source /nifi-manifest.txt  # get PRIVATE_CLUSTER_FOLDER var

GETOPT_TEMP=$(getopt -n "$myself" \
            --options='hf:i:n' \
            --longoptions='help,file:id:names' -- "$@")

if [ $? != 0 ]; then
    exit 1 # getopt a retourne une erreur.
fi
eval set -- "$GETOPT_TEMP"

function usage() {
[[ -n $1 ]] && echo "ERROR: $1"
    cat <<EOF
This script get the current load of a list of connexion between processors.
Usage: $myself [options] | -h
    -h, --help           To list options (this help).
    -n, --names          Output fields names as a header line
    -i, --id             a comma delimited list of processors Ids
    -f, --file F         specify a file the script will used to get the list of processors UUID.
EOF
    exit -1
}

while true; do
    case "$1" in
        -h|--help) usage                            ; shift   ;;
        -f|--file) id_file=$2                       ; shift 2 ;;
        -i|--id) id_list=$2                         ; shift 2 ;;
        -n|--names) headers="true"                  ; shift   ;;
        --) shift                                   ; break   ;;
        *) echo "Parsed unhandled options: $*" >&2  ; exit 1  ;;
    esac
done

#################################################################################################
# INIT
#################################################################################################
execution_date=$(date)
echo "$execution_date - start $myself execution" > "${log_file}"
echo 'preparing environment...' >> "${log_file}"

truncate -s 0 "${buffer_id_file}" # clear buffer IDs list from previous executions

# acquire the IDs list
if [[ ! -z "$id_file" ]]; then
  echo "reading IDs from file..." >> "${log_file}"
  if [[ -r "$id_file" ]]; then
    cat "${id_file}" > "${buffer_id_file}"
  else	
    echo "can't read IDs file ${id_file}" >&2
    exit 1
  fi
elif [[ ! -z "${id_list}" ]]; then
  echo "reading IDs from command line argument -i..." >> "${log_file}"
  echo "${id_list}" | cut -d',' --output-delimiter=$'\n' -f1-  > "${buffer_id_file}"
else
  echo "ERROR: no IDs found" >&2
  exit 1
fi 


#################################################################################################
# setup connexion
#################################################################################################
echo 'setup connexion to NIFI API...' >> "${log_file}"
current_node_ip=$(hostname -I | xargs)
base_url="https://${current_node_ip}"
cert_path='admin_certificate.pem'
cert_key='admin_private_key.pem'
echo "DEBUG: using base_url=${base_url}" >> "${log_file}"
cd "${working_directory}"


if [[ ! -r "./${cert_path}" || ! -r "./${cert_key}" ]]; then

    echo "download client certificate from private bucket ${PRIVATE_CLUSTER_FOLDER}"  >> "${log_file}"
    aws s3 cp ${PRIVATE_CLUSTER_FOLDER}/CN=admin_OU=NIFI.p12 . >> "${log_file}"
    aws s3 cp ${PRIVATE_CLUSTER_FOLDER}/CN=admin_OU=NIFI.password . >> "${log_file}"

    echo 'extract client certificate stuff to talk with registry'  >> "${log_file}"
    key_passphrase="$(cat CN\=admin_OU\=NIFI.password)"
    openssl pkcs12 -in ./CN\=admin_OU\=NIFI.p12 -out "./${cert_path}" -passin pass:${key_passphrase} -clcerts -nokeys
    openssl pkcs12 -in ./CN\=admin_OU\=NIFI.p12 -out "./${cert_key}" -passin pass:${key_passphrase} -nocerts -nodes

else
    echo "client certificate already available, download skipped." >> "${log_file}"
fi


#################################################################################################
# output statistics
#################################################################################################
# display header line if required
if [[ "${headers}" == "true" ]]; then
  echo "time,currentProcessorId,processorName,"
fi

# init counters, timestamp
timestamp=$(date "+%s%3N")  # generate scan time
total_processor_moniroted=$(wc -l < "${buffer_id_file}")
echo "total_processor_moniroted is $total_processor_moniroted" >> "${log_file}"
running_processor_count=0
stopped_processor_count=0
disabled_processor_count=0


# scanned listed processors states and apply remediation
while IFS=" " read -r current_processor_id; do

    echo "# getting processor [${current_processor_id}] state..."  >> "${log_file}"
    wget --quiet --no-check-certificate --certificate="${cert_path}" --private-key="${cert_key}" "${base_url}/nifi-api/processors/${current_processor_id}" --output-document="/tmp/processor_status.json"
    processorStatus="$(cat /tmp/processor_status.json | jq -r '.status.runStatus')"
    processorName="$(cat /tmp/processor_status.json | jq -r '.status.name')"
    clientId="$(cat /tmp/processor_status.json | jq -r '.revision.clientId')"
    processorVersion="$(cat /tmp/processor_status.json | jq -r '.revision.version')"

    case "$processorStatus" in
        Running)
          echo "${timestamp} - processor $processorName [$current_processor_id] is $processorStatus" >> "${log_file}"
          ((running_processor_count=running_processor_count+1))
          ;;

        Stopped)
          echo "${timestamp} - processor $processorName [$current_processor_id] is $processorStatus" >> "${log_file}"
          echo -ne "\trestarting processor... " >> "${log_file}"
          ((stopped_processor_count=stopped_processor_count+1))
          processorRunStatusEntity="{\"revision\":{\"clientId\":\"$clientId\",\"version\":$processorVersion},\"state\":\"RUNNING\",\"disconnectedNodeAcknowledged\":true}"
          update_processor_return_code=$(curl -k --cert ./admin_certificate.pem --key ./admin_private_key.pem --silent --write-out '%{http_code}' --output "/tmp/update_processor_response.json" -X PUT -H 'Content-Type:application/json' -d "$processorRunStatusEntity" "${base_url}/nifi-api/processors/${current_processor_id}/run-status")
          case "$update_processor_return_code" in
            200)
              echo "restart success" >> "${log_file}"
              ;;
            400)
              echo "invalid request" >> "${log_file}"
              ;;
            401)
              echo "client authentication failed" >> "${log_file}"
              ;;
            403)
              echo "client unauthorized to perform the request" >> "${log_file}"
              ;;
            404)
              echo "processor $current_processor_id doesn't exists" >> "${log_file}"
              ;;
            409)
              echo "valid request but NiFi unable to proceed. It can be an issue within the revision json body passed through the PUT call (make sure versionreflect the last state of processor)" >> "${log_file}"
              ;;
            *)
              echo "unhandled HTTP return code from processor update API call" >> "${log_file}"
              ;;
          esac
          ;;

        Disabled)
          echo "${timestamp} - processor $processorName [$current_processor_id] is $processorStatus" >> "${log_file}"
          echo -e "\tkeep processor disabled no automatic restart." >> "${log_file}"
          ((disabled_processor_count=disabled_processor_count+1))
          ;;

        *) 
          echo "ERROR unknown state [$processorStatus] or processor ID [$current_processor_id] unreachable" 1>&2
          ;;
    esac

#    echo "${timestamp},${current_queue_id},${queueName},${bytesQueued},${flowFilesQueued},${percentUseBytes}"

done < <(cat "${buffer_id_file}")

#################################################################################################
# produce metrics
#################################################################################################

echo "timestamp,running_processors,stopped_processors,disabled_processor"
echo "$timestamp,$running_processor_count,$stopped_processor_count,$disabled_processor_count"

echo 'scanning done.' >> "${log_file}"
exit 0




#!/bin/bash
# #####################################################################
# author: ng55235
# usage: request NiFi API to get all relevant queue size in the Flow
# dependencies:
#   - NiFi client cert with password file
#   - NiFi registry IP/hostname
#   - wget, jq, openssl
# ressources:
#   - http://nifi.apache.org/docs/nifi-registry-docs/rest-api/index.html
# TODO:
#   -
# #####################################################################

#################################################################################################
# Handle positionnals parameters
#################################################################################################
myself=$(basename "$0")
absolute_script_path=$(readlink -f "$0")
working_directory=$(dirname "$absolute_script_path")
log_file="/tmp/generate_queueSize_metrics.log"
buffer_id_file="/tmp/queue_id_list.txt"  # default ID file
source /nifi-manifest.txt  # get PRIVATE_CLUSTER_FOLDER var

GETOPT_TEMP=$(getopt -n "$myself" \
            --options='hf:i:n' \
            --longoptions='help,file:id:names' -- "$@")

if [ $? != 0 ]; then
    exit 1 # getopt a retourne une erreur.
fi
eval set -- "$GETOPT_TEMP"

function usage() {
[[ -n $1 ]] && echo "ERROR: $1"
    cat <<EOF
This script get the current load of a list of connexion between processors.
Usage: $myself [options] | -h
    -h, --help           To list options (this help).
    -n, --names          Output fields names as a header line
    -i, --id             a comma delimited list of Ids
    -f, --file F         specify a file the script will used to get the list of connexion UUID.
EOF
    exit -1
}

while true; do
    case "$1" in
        -h|--help) usage                            ; shift   ;;
        -f|--file) id_file=$2                       ; shift 2 ;;
        -i|--id) id_list=$2                         ; shift 2 ;;
        -n|--names) headers="true"                  ; shift   ;;
        --) shift                                   ; break   ;;
        *) echo "Parsed unhandled options: $*" >&2  ; exit 1  ;;
    esac
done

#################################################################################################
# INIT
#################################################################################################
execution_date=$(date)
echo "$execution_date - start $myself execution" > "${log_file}"
echo 'preparing environment...' >> "${log_file}"

truncate -s 0 "${buffer_id_file}" # clear buffer IDs list from previous executions

# acquire the IDs list
if [[ ! -z "$id_file" ]]; then
  echo "reading IDs from file..." >> "${log_file}"
  if [[ -r "$id_file" ]]; then
    cat "${id_file}" > "${buffer_id_file}"
  else	
    echo "can't read IDs file ${id_file}" >&2
    exit 1
  fi
elif [[ ! -z "${id_list}" ]]; then
  echo "reading IDs from command line argument -i..." >> "${log_file}"
  echo "${id_list}" | cut -d',' --output-delimiter=$'\n' -f1-  > "${buffer_id_file}"
else
  echo "ERROR: no IDs found" >&2
  exit 1
fi 


#################################################################################################
# setup connexion
#################################################################################################
echo 'setup connexion to NIFI API...' >> "${log_file}"
current_node_ip=$(hostname -I | xargs)
base_url="https://${current_node_ip}"
cert_path='admin_certificate.pem'
cert_key='admin_private_key.pem'
echo "DEBUG: using base_url=${base_url}" >> "${log_file}"
cd "${working_directory}"

# setup connexion
if [[ ! -r "./${cert_path}" || ! -r "./${cert_key}" ]]; then

    echo "download client certificate from private bucket ${PRIVATE_CLUSTER_FOLDER}"  >> "${log_file}"
    aws s3 cp ${PRIVATE_CLUSTER_FOLDER}/CN=admin_OU=NIFI.p12 .  >> "${log_file}"
    aws s3 cp ${PRIVATE_CLUSTER_FOLDER}/CN=admin_OU=NIFI.password .  >> "${log_file}"

    echo 'extract client certificate stuff to talk with registry'  >> "${log_file}"
    key_passphrase="$(cat CN\=admin_OU\=NIFI.password)"
    openssl pkcs12 -in ./CN\=admin_OU\=NIFI.p12 -out "./${cert_path}" -passin pass:${key_passphrase} -clcerts -nokeys
    openssl pkcs12 -in ./CN\=admin_OU\=NIFI.p12 -out "./${cert_key}" -passin pass:${key_passphrase} -nocerts -nodes

else
	echo "client certificate already available, download skipped." >> "${log_file}"
fi


#################################################################################################
# output statistics
#################################################################################################
# generate scan time
timestamp=$(date "+%s%3N")
# data arbitraire pour tester
#timestamp=1625479200000

# display header line if required
if [[ "${headers}" == "true" ]]; then
  echo "time,currentQueueId,queueName,bytesQueued,flowFilesQueued,percentUseBytes"
fi

# load the list of connexion to monitor
while IFS=" " read -r current_queue_id; do
    echo "=> get queue status for connexion ID: ${current_queue_id}"  >> "${log_file}"
    wget --quiet --no-check-certificate --certificate="${cert_path}" --private-key="${cert_key}" "${base_url}/nifi-api/connections/${current_queue_id}" --output-document=queue_status.json

    # TODO: use only one jq pass to get all relevant fields should be faster
    # TODO: use the last update time (statsLastRefreshed) as a timestamp for the data ?
    queueName=$(cat queue_status.json | jq -r '.status.name')
    statsLastRefreshed=$(cat queue_status.json | jq -r '.status.statsLastRefreshed')
    bytesQueued=$(cat queue_status.json | jq -r '.status.aggregateSnapshot.bytesQueued')
    flowFilesQueued=$(cat queue_status.json | jq -r '.status.aggregateSnapshot.flowFilesQueued')
    percentUseBytes=$(cat queue_status.json | jq -r '.status.aggregateSnapshot.percentUseBytes')
    echo "${timestamp},${current_queue_id},${queueName},${bytesQueued},${flowFilesQueued},${percentUseBytes}"

done < <(cat "${buffer_id_file}")

echo 'scanning done.' >> "${log_file}"
exit 0

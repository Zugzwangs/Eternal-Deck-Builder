#!/bin/bash
# #####################################################################
# author: ng55235
# usage: backup NiFi flow file to S3 - Intended to be root crontab job
#0 22 * * * /root/cloud_formation_infra/nifi/nodes/backup/backup_flowfile.sh > /dev/null 2>&1
# dependencies:
#   - NiFi manifest file (should be /nifi-manifest.txt)
# todo:
#    - path to flow file should be resolved from a global var
# #####################################################################

source /nifi-manifest.txt
backup_date=$(date +"%Y%m%d")
aws s3 cp /mnt/install/nifi/conf/flow.xml.gz ${NIFI_PRIVATE_BUCKET}/backup/flow.xml.gz-${backup_date}

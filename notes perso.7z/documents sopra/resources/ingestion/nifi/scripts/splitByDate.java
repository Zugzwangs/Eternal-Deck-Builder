import java.nio.charset.StandardCharsets

def flowFile = session.get()

if(!flowFile) return

def flowFiles = [] 
def dates = [] 
def originalDate = ""
def date = ""
String recordOut = ""
def recordOuts = []  
def index = ""
boolean firstLine= true
def inputStream = session.read(flowFile)

inputStream.eachLine { line ->
	
   fields = line.split('\\|')
   
   if(firstLine){
	   date = fields[1].take(10)
	   //We make the assumption that just one index can come in a flowfile!!
	   index = fields[0]
	   
	   dates << date	   
	   firstLine = false
	}
	   
   
   if (fields[1].take(10) != date){ 
		
	recordOuts << recordOut
	//first line sets the value of date for the new flowfile
	date = fields[1].take(10)
	dates << date
	//The recordOut has to be reset
	recordOut=""
   }
	recordOut = recordOut + line	+ "\n"
}

recordOuts << recordOut

Integer i=0 //to iterate in recordOuts as well

for(record in recordOuts){
	
	def newFlowFile = session.create(flowFile)
	// Add a new attribute with the date attribute
	newFlowFile = session.putAttribute(newFlowFile, 'date', dates[i])
	newFlowFile = session.putAttribute(newFlowFile, 'schema.name', index)
	newFlowFile = session.write(newFlowFile, { outputStream -> 
		outputStream.write( record.getBytes(StandardCharsets.UTF_8) )
			} as OutputStreamCallback)
	
	flowFiles << newFlowFile
	
	i=i+1
	
}

	
session.transfer(flowFiles, REL_SUCCESS)
session.remove(flowFile)
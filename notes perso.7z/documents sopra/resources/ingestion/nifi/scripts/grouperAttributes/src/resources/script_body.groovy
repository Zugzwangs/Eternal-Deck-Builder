import com.ingestion.app.GroupHandler

def ffs = session.get(100)

def handler = new GroupHandler(log, session)

ffs.each { flowFile ->
        handler.execute(flowFile)
        session.remove(flowFile)
}

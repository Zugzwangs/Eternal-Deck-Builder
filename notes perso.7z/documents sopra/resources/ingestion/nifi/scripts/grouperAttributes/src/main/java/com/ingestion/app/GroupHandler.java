package com.ingestion.app;
import java.util.logging.Logger;
import java.util.stream.Collectors;
import java.util.Map;
import java.util.List;
import java.util.Arrays;
import java.util.function.Function;

import org.apache.commons.io.IOUtils;
import java.io.OutputStream;
import java.io.InputStream;
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.nio.charset.StandardCharsets;

import org.apache.nifi.flowfile.FlowFile;
import org.apache.nifi.logging.ComponentLog;
import org.apache.nifi.processor.ProcessSession;
import org.apache.nifi.processor.ProcessContext;
//import org.apache.nifi.processor.exception.ProcessException;
import org.apache.nifi.processors.script.ExecuteScript;

public class GroupHandler {
        private ComponentLog log;
        private ProcessSession session;
        private FlowFile parentFlowFile = null;
        private String[] indexesWithLoginType;

        public GroupHandler(ComponentLog log, ProcessSession session) {
            this.log = log;
            this.session = session;
            this.indexesWithLoginType = new String[] {"idx_08"};
        }
        
        public void execute(FlowFile parentFlowFile) {
            try (InputStream is = session.read(parentFlowFile)) {
                Map<String, List<String>> output = groupByIndexDatetAndLogin(is, 
                  getAttributes);
                for (String attributes: output.keySet()) {
                  List<String> lines = output.get(attributes);
                  String content = String.join("\n", lines);
                  FlowFile newFlowFile = createFlowFile(parentFlowFile, attributes);
                  newFlowFile = writeFlowFile(newFlowFile, content);
                  session.transfer(newFlowFile, ExecuteScript.REL_SUCCESS);
                }
            } catch (Exception ex) {
                System.out.println(ex);
                session.transfer(parentFlowFile, ExecuteScript.REL_FAILURE);
            }
        }
        
        private Map<String, List<String>> groupByIndexDatetAndLogin(InputStream is, Function<String, String> groupingFunction) {    
            BufferedReader br = new BufferedReader( new InputStreamReader(is, StandardCharsets.UTF_8));
            
            // This line groups the input applying the given groupingFunction
            Map<String, List<String>> groups = br.lines().collect(Collectors.groupingBy(s -> 
              groupingFunction.apply(s)));
            return groups;
        }
        
        protected Function<String, String> getAttributes = s -> {
            String[] allFields = s.split("\\|");
            String[] attributes;
	    boolean indexHasLoginType = Arrays.asList(indexesWithLoginType).contains(allFields[0]);
            if (indexHasLoginType) {
              attributes = Arrays.copyOfRange(allFields, 0, 3);
            } else {
              attributes = Arrays.copyOfRange(allFields, 0, 2);
            }
            int dateIndex = 1;
            String date = attributes[dateIndex];
            Arrays.asList(attributes).set(dateIndex, date.substring(0, 10));
            return String.join(",", attributes);
        };
        
        private FlowFile createFlowFile(FlowFile parentFlowFile, String attributes) {
            String[] attributeList = attributes.split("\\,");
            String index = attributeList[0];
            String date = attributeList[1];
            String loginType = getLoginTypeAttribute(attributeList, 2); 
            String concatenation = index + date + loginType;
            FlowFile newFlowFile = session.create(parentFlowFile);
	    newFlowFile = session.putAttribute(newFlowFile, "schema.name", index);
            newFlowFile = session.putAttribute(newFlowFile, "date", date);
            newFlowFile = session.putAttribute(newFlowFile, "loginType", loginType);
            newFlowFile = session.putAttribute(newFlowFile, "concatenation", concatenation);
            return newFlowFile;
        }

        private String getLoginTypeAttribute(String[] arr, int index) {
            String value;
            try {
              value = "login_type=" + arr[index] + "/";
            } catch(ArrayIndexOutOfBoundsException ex) {
              value = "";
            }
            return value;
        } 
        
        private FlowFile writeFlowFile(FlowFile flowFile, String content) {
            return session.write(flowFile, 
            outputStream -> outputStream.write(content.getBytes(StandardCharsets.UTF_8))); 
            
        }
}


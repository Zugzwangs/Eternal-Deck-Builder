package com.ingestion.app;

import static org.junit.Assert.assertTrue;

import org.apache.commons.io.IOUtils;
import org.junit.Before;
import org.junit.Test;

import org.apache.nifi.processors.script.ExecuteScript;
import org.apache.nifi.processor.ProcessSession;
import org.apache.nifi.script.ScriptingComponentUtils;
import org.apache.nifi.util.TestRunner;
import org.apache.nifi.util.TestRunners;
import org.apache.nifi.util.MockComponentLog;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.io.File;
import java.io.InputStream;
import java.io.FileInputStream;
import java.util.List;
import java.util.Map;

import com.ingestion.app.GroupHandler;

public class GroupHandlerTest {

    private TestRunner runner;
    private String dataFolder;
    private String dataFile;
    private ProcessSession session; 
    private MockComponentLog log;
    
    @Before
    public void setup() throws IOException {
        String rootPath = "/root/cloud_formation_infra/resources/ingestion/nifi/scripts/grouperAttributes/";
        String srcPath = rootPath + "src/";

        dataFolder = srcPath + "test/data/";
        dataFile = "mixedInputLines";
        runner = TestRunners.newTestRunner(ExecuteScript.class);
        runner.setProperty("Script Engine", "Groovy");
        runner.setProperty(ScriptingComponentUtils.SCRIPT_FILE, srcPath + "resources/script_body.groovy");
        runner.setProperty(ScriptingComponentUtils.MODULES, rootPath 
          + "target/grouperAttributes-1.0-SNAPSHOT.jar");
        runner.assertValid();
        session = runner.getProcessSessionFactory().createSession();
        log = runner.getLogger();
    }
    
    
    @Test
    public void itReturnsTwoGroupsOfFlowFiles() throws IOException {
        int expectedFailures = 0;
        int expectedSuccess = 4;
        
        runTestPathInput(dataFolder + dataFile);
        
        runner.assertTransferCount(ExecuteScript.REL_FAILURE, expectedFailures);
        runner.assertTransferCount(ExecuteScript.REL_SUCCESS, expectedSuccess);
    }

    @Test
    public void itShouldHaveCorrectAttributes() throws IOException {
        String expectedAttributeSchemaName = "schema.name";
        String expectedAttributeDate = "date";
        String expectedAttributeLoginType = "loginType";
        String expectedAttributeConcatenation = "concatenation";

        runTestPathInput(dataFolder + dataFile);

        runner.assertAllFlowFilesContainAttribute(expectedAttributeConcatenation);
        runner.assertAllFlowFilesContainAttribute(expectedAttributeSchemaName);
        runner.assertAllFlowFilesContainAttribute(expectedAttributeDate);
        runner.assertAllFlowFilesContainAttribute(expectedAttributeLoginType);
    }
    
    void runTestPathInput(String path) throws IOException {
        runner.enqueue(Paths.get(path)); 
        runner.run();
    }

    
}

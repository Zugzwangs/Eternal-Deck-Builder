export JAVA_HOME=/usr/lib/jvm/jdk-18

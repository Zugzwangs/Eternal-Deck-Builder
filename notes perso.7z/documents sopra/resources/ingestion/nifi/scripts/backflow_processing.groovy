import java.nio.charset.StandardCharsets


// /////////////////////////////////////////////////////////////////////////////// //
// Notes: 
// this script apply a logic based on the shape of the s3 location URI from 
// where files are dowloaded.
// Determine which files to takes or not
//
// TODO:
//   - add test to make sure 
//       * field 'code_name' value is like (kti|ac_[0-9]{1,3})
//       * field 'mode' is like (fit/predict)
//       * field 'class_name' is like (model|sensor_[0-9]{1,3})
//   - handling of unexpected cases
// /////////////////////////////////////////////////////////////////////////////// //


// get current flowfile
flowFile = session.get()
if (!flowFile) return

// get source s3 path
filename = flowFile.getAttribute('filename')

// /////////////////////////////////////////////////////////////////////////////// //
// s3 path format is: results/{code_name}/{mode}/{class_name}/{date}/results.csv   //
//                    results/kti/{date}/results.csv                               //
// code_name:	ac_XX or kti                                                       //
// mode: 		fit / predict                                                      //
// class_name: 	sensor_xx/model                                                    // 
// date: 		YYYY-mm-dd                                                         //
// /////////////////////////////////////////////////////////////////////////////// //


// get name of the code who produce data first
def splits = []
splits = filename.split('\\/')
code_name  = splits[1]

// KTI DATA
if (code_name == 'kti') {
	date   = splits[2]
	file   = splits[3]
	file = code_name + '-' +  file 
	mode = 'predict'  // force value for consistancy
	class_name = ''   // force value for consistancy
	kti_anomalies_sensors ='kti'
}

else {
	// further break down the path into meaningful variables
	mode        = splits[2]
	class_name  = splits[3]
	date        = splits[4]
	file        = splits[5]

	// transfer flowfiles from FIT mode execution to failure relation (we don't want to process these files)
	if (mode == 'fit') {
		session.transfer(flowFile, REL_FAILURE)
		System.exit(0)
	}
	
	// examine the class_name 
	else {
		// ANOMALIES DATA
		if (class_name == 'model') {
			file = code_name + '-' +  file
			kti_anomalies_sensors ='anomalies'
		}
		
		// SENSORS DATA
		else {
			file = code_name + '-' + class_name + '-' + file
			kti_anomalies_sensors ='sensors'		
		}
	}
}

// Enrich flowfile's attributes and pass them to the succes relation 
flowFile = session.putAttribute(flowFile, 'filename', file)
flowFile = session.putAttribute(flowFile, 'date', date)
flowFile = session.putAttribute(flowFile, 'kti_anomalies_sensors', kti_anomalies_sensors)
session.transfer(flowFile, REL_SUCCESS)

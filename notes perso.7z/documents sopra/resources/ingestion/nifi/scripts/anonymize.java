import javax.crypto.Cipher
import javax.crypto.SecretKey
import javax.crypto.spec.IvParameterSpec
import javax.crypto.spec.SecretKeySpec
import java.nio.charset.StandardCharsets
import java.security.SecureRandom

//import static com.xlson.groovycsv.CsvParser.parseCsv

import org.apache.commons.io.IOUtils
import java.nio.charset.*

def flowFile = session.get()
if(!flowFile) return

def fail = false

flowFile = session.write(flowFile, {inputStream, outputStream ->
    try {
		def recordIn = IOUtils.toString(inputStream, StandardCharsets.UTF_8)
		
		//def data_iterator = parseCsv(recordIn, separator: '|', readFirstLine: true)
		
		String[] lines  = recordIn.split("\n")

		// Instantiate an encryption cipher
		// Lots of additional code could go here to generate a random key, derive a key from a password, read from a file or keyring, etc.
		String keyHex = "0123456789ABCDEFFEDCBA9876543210" // * 2 for 256-bit encryption
		SecretKey key = new SecretKeySpec(keyHex.getBytes(StandardCharsets.UTF_8), "AES")
		byte[] ivBytes = new byte[16]
		SecureRandom secureRandom = new SecureRandom()
		secureRandom.nextBytes(ivBytes)
		IvParameterSpec iv = new IvParameterSpec(ivBytes)

		Cipher aesGcmEncCipher = Cipher.getInstance("AES/GCM/NoPadding", "BC")

		String recordOut =""
		String separator ="|"
		Integer iterate = 1
		
		for (line in lines) {
			
			iterate = 1
			String[] fields  = line.split("\\|")
			fields.each { field -> 
			
				if (fields.length == iterate){
					separator ="\n"
				}
				
				if(field.take(1) =="#"){
					//We remove the first character
					field= field.substring(1)
					// Re-initialize the cipher
					secureRandom.nextBytes(ivBytes)
					iv = new IvParameterSpec(ivBytes)
					aesGcmEncCipher.init(Cipher.ENCRYPT_MODE, key, iv)
					//The anonymized field is saved
					cipherTextBase64 = Base64.encoder.encodeToString(aesGcmEncCipher.doFinal(field.bytes))
					field = "${Base64.encoder.encodeToString(ivBytes)};;${cipherTextBase64}"
					//field = Base64.encoder.encodeToString(aesGcmEncCipher.doFinal(field.bytes))
					
				}
				
				recordOut = recordOut + field	+ separator
				iterate = iterate + 1
			}
			separator ="|" // reset it to the field separator instead the return
		}
		
		outputStream.write(recordOut.getBytes(StandardCharsets.UTF_8))
    }
    catch(e) {
    log.error("Error during processing of validate.groovy", e)
    session.transfer(inputStream, REL_FAILURE)
    fail=true
    }
} as StreamCallback)
if(fail){
session.transfer(flowFile, REL_FAILURE)
fail = false
} else {
session.transfer(flowFile, REL_SUCCESS)
}

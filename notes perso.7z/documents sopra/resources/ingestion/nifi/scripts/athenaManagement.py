#! /opt/rh/rh-python38/root/usr/bin/python
import sys
import json
import boto3
import subprocess
from pyarrow.parquet import read_schema
from io import BytesIO

# definition of a function to create an athena table
def create_athena_table(avro_schema, database, table_name, bucket, region, index):
        ## creation of the table ##
        # creation of the query string
        query_start= "CREATE EXTERNAL TABLE IF NOT EXISTS {}.{} ".format(database,table_name)

        query_fields= "("
        l= len(avro_schema["parquet.avro.schema"]["fields"])
        i=0
        for field in avro_schema["parquet.avro.schema"]["fields"]:
                if i<(l-1):
                        query_fields= query_fields + field["name"] + " " + field["type"] + ","
                else:
                        query_fields= query_fields + field["name"] + " " +  field["type"]
                i+=1
        query_fields= query_fields + ") "

        query_partition= "PARTITIONED BY (date string) ROW FORMAT SERDE 'org.apache.hadoop.hive.ql.io.parquet.serde.ParquetHiveSerDe' WITH SERDEPROPERTIES ('serialization.format' = '1') LOCATION 's3://{}/parquetfiles/{}' TBLPROPERTIES ('has_encrypted_data'='false');".format(bucket,index)

        query= query_start + query_fields + query_partition

        # using boto3 to run the query
        athena= boto3.client('athena', region_name=region)
        s3_output= "s3://s3-2s33-dev-datalake-eu-west-1/athena_query_results/table_creation/"
        athena.start_query_execution(QueryString=query,QueryExecutionContext={'Database':database},ResultConfiguration={'OutputLocation':s3_output})


        ## update the partition ##
        query_repair= "MSCK REPAIR TABLE {}.{}".format(database,index)
        athena.start_query_execution(QueryString=query_repair,QueryExecutionContext={'Database':database},ResultConfiguration={'OutputLocation':s3_output})


# definition of a function to drop an athena table
def delete_athena_table(database, table_name, region):
        athena= boto3.client('athena', region_name=region)
        query= "DROP TABLE IF EXISTS {}.{}".format(database,table_name)
        s3_output= "s3://s3-2s33-dev-datalake-eu-west-1/athena_query_results/table_creation/"
        athena.start_query_execution(QueryString=query,QueryExecutionContext={'Database':database},ResultConfiguration={'OutputLocation':s3_output})

def main():
        try:
                # Load the flow
                flow= sys.stdin.readline()

                # Parse the json
                flow_object= json.loads(flow)

                # Extract index, date and format it as per bucket storage
                date= flow_object["exec-init"][:10]
                index= flow_object["idx"]


                # Use aws cli to get the key of the last modified file for the date in the s3 bucket
                bucket= "s3-2s33-dev-datalake-eu-west-1"
                aws_get_last_file= "aws s3api list-objects-v2 --bucket {} --prefix parquetfiles/{}/date={} --query 'sort_by(Contents,&LastModified)[-1].Key' --output=text".format(bucket,index,date)

                key= subprocess.check_output(aws_get_last_file, shell=True)
                key= key.decode('UTF-8')[:-1] #decoding bytes

                # Use boto3 to load the object and pyarrow to read the schema
                s3 = boto3.client('s3')
                obj= s3.get_object(Bucket=bucket, Key=key)

                new_schema= read_schema(BytesIO(obj['Body'].read())).metadata

                # decoding bytes
                new_schema= {y.decode('UTF-8'): new_schema.get(y).decode('UTF-8') for y in new_schema.keys()}
                new_schema['parquet.avro.schema']= json.loads(new_schema['parquet.avro.schema'])


                # list all Athena table available in splunk_raw_indexes database
                catalog= "AwsDataCatalog"
                database= "splunk_raw_indexes"
                region= "eu-west-1"

                aws_list_table= "aws athena list-table-metadata --catalog-name {} --database-name {} --region {}".format(catalog,database,region)

                tables= subprocess.check_output(aws_list_table, shell=True)
                tables= json.loads(tables)


                # get the table index of the subject table if any
                for table_index, table in enumerate(tables['TableMetadataList']):
                        if table['Name'] == index:
                                        break
                        else:
                                table_index=-1

                # check if a table already exists for this index
                # if no table exist create a new table
                if table_index == -1:
                        try:
                                create_athena_table(avro_schema=new_schema, database=database, table_name=index, bucket=bucket, region=region, index=index)
                                message={"status":"A new Athena table has been created for index {} and partitions have been updated".format(index)}
                        except Exception as e:
                                message={"status":"Fail to create the athena table","Exception":e}

                # if the table already exists, compare the old and new schema
                else:
                        # the new fields are available through the <<avro_schema>> object
                        new_fields= new_schema["parquet.avro.schema"]["fields"]

                        # the old fields of the existing table are available in <<tables>> object
                        old_fields= tables['TableMetadataList'][table_index]['Columns']

                        # convert the whole objects to lower case
                        new_fields= [{k.lower():v.lower() for k,v in x.items()} for x in new_fields]
                        old_fields= [{k.lower():v.lower() for k,v in x.items()} for x in old_fields]

                        # if the schema has changed, delete the existing table and create a new one
                        if new_fields != old_fields:
                                try:
                                        delete_athena_table(database, index, region)
                                        create_athena_table(avro_schema=new_schema, database=database, table_name=index, bucket=bucket, region=region, index=index)
                                        message={"status":"The Avro schema of the data has evolved. The Athena table of index {} has been deleted and re-created to modify its schema. Partitions have also been updated".format(index)}
                                except Exception as e:
                                        message={"status":"The Avro schema of the data has evolved. Fail to delete or re-create the athena table","Exception":e}

                        else:
                                message={"status":"The Avro schema of the data did not change. No action has been performed on the Athena table for index {}".format(index)}


                # updating the flowfile with the status of this script
                message= json.dumps(message)

                #write to the flow
                sys.stdout.write(message)

        except Exception as e:
                message={"status":"Something went wrong during script execution. No modification done on Athena tables"}
                message= json.dumps(message)
                sys.stdout.write(message)



if __name__ == '__main__':
        main()

#!/bin/bash

# #####################################################################
# author: ng55235
# usage: this tool reset the nifi registry metadata database and reset the service to force the rebuild after
# dependencies:
#  - git command
# TODO:
#   -
# #####################################################################

service nifi-registry stop
mv /opt/nifi-registry/database/nifi-registry-primary.mv.db /opt/nifi-registry/database/nifi-registry-primary.mv.db.backup
cd /opt/nifi-registry/nifi-processors/
git pull
service nifi-registry start



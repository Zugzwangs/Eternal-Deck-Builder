export NIFI_ROOT=/mnt/install
export NIFI_HOME=${NIFI_ROOT}/nifi
export NIFI_TOOLKIT_HOME=${NIFI_ROOT}/nifi-toolkit
export PATH=$PATH:$NIFI_HOME/bin
export JAVA_HOME=/

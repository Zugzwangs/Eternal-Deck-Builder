#!/bin/bash
# #####################################################################
# author: ng55235
# usage: create all policies required by NiFi nodes to works with buckets
# dependencies:
#   - NiFi client cert with password file
#   - json document template for policy creation (create_policy_template.json)
#   - NiFi registry IP/hostname
#   - cURL, wget, jq, openssl
# ressources:
#   - http://nifi.apache.org/docs/nifi-registry-docs/rest-api/index.html
# TODO:
#   - add options to control whioh update we want to operate on NiFi
#   - use global conf for bucket name, IP and so on
# #####################################################################

echo 'starting NiFi registry policies deployment...'

echo 'sets variables.'
registry_ip=$(grep "-reg-" /etc/hosts | cut -d" " -f1)
base_url="https://${registry_ip}/nifi-registry-api"
cert_path='admin_certificate.pem'
cert_key='admin_private_key.pem'
source /nifi-manifest.txt  # get PRIVATE_CLUSTER_FOLDER var
#PRIVATE_CLUSTER_FOLDER=s3://s3-2s33-prod-nifi-eu-west-1/prod-1.0.1 

# setup connexion
echo "download client certificate from private bucket ${PRIVATE_CLUSTER_FOLDER} "
aws s3 cp ${PRIVATE_CLUSTER_FOLDER}/CN=admin_OU=NIFI.p12 .
aws s3 cp ${PRIVATE_CLUSTER_FOLDER}/CN=admin_OU=NIFI.password .

echo 'extract client certificate stuff to talk with registry'
key_passphrase="$(cat CN\=admin_OU\=NIFI.password)"
openssl pkcs12 -in ./CN\=admin_OU\=NIFI.p12 -out "./${cert_path}" -passin pass:${key_passphrase} -clcerts -nokeys
openssl pkcs12 -in ./CN\=admin_OU\=NIFI.p12 -out "./${cert_key}" -passin pass:${key_passphrase} -nocerts -nodes


# get bucket ressources IDs list
echo "fetching available buckets ressources..."
wget --quiet --no-check-certificate --certificate="${cert_path}" --private-key="${cert_key}" "${base_url}/policies/resources" --output-document=ressources_list.json
cat ressources_list.json | jq -r '.[].identifier' | grep buckets/ > buckets_list.txt
echo -e "founded ressources are :\n---------------------------"
cat buckets_list.txt

echo "fetching initial users IDs (admin and nodes)."
wget --quiet --no-check-certificate --certificate="${cert_path}" --private-key="${cert_key}" "${base_url}/tenants/users" --output-document=users_list.json
cat users_list.json | jq -r '.[] | .identifier + ";" + .identity' > users_list.txt
admin_user_id=$(cat users_list.json | jq -r '.[] | select( .identity | contains("CN=admin, OU=NIFI") ).identifier' )
echo -e "founded Users IDs are:\n---------------------------"
cat users_list.txt
echo -e "\t=> admin is ${admin_user_id}"


# USERS LEVEL ACL
echo -e "allow the special privilege proxy user request to all nodes."
cat users_list.txt | grep -v ${admin_user_id}
# get policy IDs for read write and delete actions
echo -e "read\nwrite\ndelete" > actions_list.txt
wget --quiet --no-check-certificate --certificate="${cert_path}" --private-key="${cert_key}" "${base_url}/policies" --output-document="all_policies.json"

while IFS=" " read -r current_action; do

	echo -e "\nenable ${current_action} proxy actions for all nodes"
	echo "get the policy ID"  # policy should exists because admin is grant this access when registry startup the fist time.
	existing_policy_id=$(cat "all_policies.json" | jq -r --arg current_action "${current_action}" --arg current_bucket_ID "${current_bucket_ID}" '.[]| select(.resource == "/proxy" and .action == $current_action).identifier')
	echo -e "\tpolicy ID is [${existing_policy_id}]"
	echo '--------------- current policy content -----------------'
	wget --quiet --no-check-certificate --certificate="${cert_path}" --private-key="${cert_key}" "${base_url}/policies/${existing_policy_id}"  --output-document="current_policy_document.json"
	cat current_policy_document.json
	echo '--------------------------------------------------------'
	echo '------------ extracting authorized users ---------------'
	cat current_policy_document.json | jq -r '.users[].identifier' > existing_users.txt
	cat existing_users.txt
	echo '--------------------------------------------------------'
	while IFS=";" read -r current_user_ID current_identity; do
        echo "adding missing user ${current_identity} (${current_user_ID}) to the policy document."
		cat current_policy_document.json | jq --arg current_user_ID "${current_user_ID}" --arg current_identity "${current_identity}" '.users += [ {"configurable": true,"identifier": $current_user_ID, "identity": $current_identity} ]' > tmp_updated_policy.json
		cat tmp_updated_policy.json > current_policy_document.json #we need a swap file because jq doesn't handle a proper in place editing like sed -i does
	done < <(cat users_list.txt | grep -vFf existing_users.txt)
	# push updated document to Registry
	echo "push update to registry"
	curl -i -k --key "./${cert_key}" --cert "./${cert_path}" -X PUT -H "Content-Type: application/json; charset=utf-8" -d @"current_policy_document.json" "${base_url}/policies/${existing_policy_id}"
done < <(cat "actions_list.txt")

# BUCKET LEVEL ACL
echo -e "create read/write access policies for all users on each buckets\n----------------------------------------"
while IFS=" " read -r current_bucket_ID; do
    echo "building policy document for bucket ${current_bucket_ID}"
    while IFS=";" read -r current_user_ID current_identity; do
        echo -e "\t- target user: ${current_identity} (${current_user_ID})"
        cat create_policy_template.json \
          | jq '.action = "read" ' \
          | jq --arg current_bucket_ID "${current_bucket_ID}" '.resource = $current_bucket_ID '  \
          | jq --arg current_user_ID "${current_user_ID}" '.users[0].identifier = $current_user_ID ' \
          | jq --arg current_identity "${current_identity}" '.users[0].identity = $current_identity ' \
          > current_policy_read.json

        echo -e "\tcalling NiFi API to build the read access policy..."
        http_response_code=$(wget --quiet --server-response --no-check-certificate --certificate="${cert_path}" --private-key="${cert_key}" --header 'content-type: application/json' --post-file='current_policy_read.json' "${base_url}/policies" 2>&1| awk '/^  HTTP/{print $2}')
        echo -e "\tread policy creation response code is ${http_response_code}"
        case ${http_response_code} in
          '200'|'201')
            echo "policy created succesfully";;
          '409')
            echo "conflict with already existing policy."
                        # find ID of the policy
                        wget --quiet --no-check-certificate --certificate="${cert_path}" --private-key="${cert_key}" "${base_url}/policies" --output-document="all_policies.json"
                        # get rule IDs related to the current bucket ID
                        existing_policy_id=$(cat "all_policies.json" | jq -r --arg current_bucket_ID "${current_bucket_ID}" '.[]| select(.resource == $current_bucket_ID and .action == "read").identifier')
                        echo "policy ID found is ${existing_policy_id}"
                        # get current policy document
                        wget --quiet --no-check-certificate --certificate="${cert_path}" --private-key="${cert_key}" "${base_url}/policies/${existing_policy_id}"  --output-document="current_policy_document.json"
                        # check if user is declared in the policy document
                        retrieved_user=$(cat current_policy_document.json | jq -r --arg current_user_ID "${current_user_ID}" '.users[] | select(.identifier == $current_user_ID).identifier')
                        #echo '--------------- current policy content -----------------'
                        #cat current_policy_document.json
                        #echo '--------------------------------------------------------'
                        echo "retrieved user is [${retrieved_user}]"
                        if [[ "${retrieved_user}" == "${current_user_ID}" ]]; then
                          echo "user has already granted permission to this ressource. Nothing to do"
                        else
                          echo "user not found, updating document..."
                          cat current_policy_document.json | jq --arg current_user_ID "${current_user_ID}" --arg current_identity "${current_identity}" '.users += [ {"configurable": true,"identifier": $current_user_ID, "identity": $current_identity} ]' > current_updated_policy.json
                          #echo '--------------- updated policy content -----------------'
                          #cat  current_updated_policy.json
                          #echo '--------------------------------------------------------'
                          echo "sending update to registry"
                          curl -i -k --key "./${cert_key}" --cert "./${cert_path}" -X PUT -H "Content-Type: application/json; charset=utf-8" -d @"current_updated_policy.json" "${base_url}/policies/${existing_policy_id}"
                          # TODO check return code
                        fi ;;

          *) echo "others failed case";;
        esac

        echo -e "\tcalling NiFi API to build the new write access policy..."
        cat current_policy_read.json |  jq '.action = "write" ' > current_policy_write.json
        http_response_code=$(wget --quiet --server-response --no-check-certificate --certificate="${cert_path}" --private-key="${cert_key}" --header 'content-type: application/json' --post-file='current_policy_write.json' "${base_url}/policies"  2>&1| awk '/^  HTTP/{print $2}')
        echo -e "\twrite policy creation response code is ${http_response_code}"
        case ${http_response_code} in
          '200'|'201')
            echo "policy created succesfully";;

          '409')
            echo "conflict with already existing policy."
                        # find ID of the policy
                        wget --quiet --no-check-certificate --certificate="${cert_path}" --private-key="${cert_key}" "${base_url}/policies" --output-document="all_policies.json"
                        # get rule IDs related to the current bucket ID
                        existing_policy_id=$(cat "all_policies.json" | jq -r --arg current_bucket_ID "${current_bucket_ID}" '.[]| select(.resource == $current_bucket_ID and .action == "write").identifier')
                        echo "policy ID found is ${existing_policy_id}"
                        # get current policy document
                        wget --quiet --no-check-certificate --certificate="${cert_path}" --private-key="${cert_key}" "${base_url}/policies/${existing_policy_id}"  --output-document="current_policy_document"
                        # check if user is declared in the policy document
                        retrieved_user=$(cat current_policy_document | jq -r --arg current_user_ID "${current_user_ID}" '.users[] | select(.identifier == $current_user_ID).identifier')
                        echo "retrieved user is [${retrieved_user}]"
                        if [[ "${retrieved_user}" == "${current_user_ID}" ]]; then
                          echo "user has already granted permission to this ressource. Nothing to do"
                        else
                          echo "user not found, updating document..."
                          cat current_policy_document | jq --arg current_user_ID "${current_user_ID}" --arg current_identity "${current_identity}" '.users += [ {"configurable": true,"identifier": $current_user_ID, "identity": $current_identity} ]' > current_updated_policy.json
                          echo "sending update to registry"
                          curl -i -k --key "./${cert_key}" --cert "./${cert_path}" -X PUT -H "Content-Type: application/json; charset=utf-8" -d @"current_updated_policy.json" "${base_url}/policies/${existing_policy_id}"
                          # TODO check return code
                        fi ;;

          *) echo "others failed case";;
        esac

    # DEBUG
    #break 2
    done < <(cat "users_list.txt")

done < <(cat "buckets_list.txt")

echo 'configurations done.'
exit 0

						  

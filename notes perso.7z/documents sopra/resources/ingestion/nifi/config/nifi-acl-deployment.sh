#!/bin/bash
# #####################################################################
# author: ng55235
# usage: create all policies required by Admin user to operate on NiFi
# dependencies:
#   - NiFi client cert with password file
#   - cURL, wget, jq, openssl
# ressources:
#   - https://nifi.apache.org/docs/nifi-docs/rest-api/index.html
# TODO:
#   - add options to control whioh update we want to operate on NiFi
# Notes:
#  - sample query to try nifi api 
# wget --no-check-certificate --certificate=admin_certificate.pem --private-key=admin_private_key.pem https://nifi-1-dev.2s33-insiderprotection.aws.cloud.airbus-v.corp/nifi-api/tenants/users
# #####################################################################


# #####################################################################
# FUNCTIONS
# #####################################################################
# create a policy document for the given action ($1) and resource ($2) attributed to one user ($3)
function create_policy_document() {

echo '''
{
        "revision": {
                "version": 0
        },
        "permissions": {
                "canRead": "true",
                "canWrite": "true"
        },
        "bulletins": [],
        "component": {
                "resource": "/'$2'",
                "action": "'$1'",
                "configurable": true,
                "users": [
                        {
                                "revision": {
                                        "version": 0
                                },
                                "id": "'$3'",
                                "permissions": {
                                        "canRead": true,
                                        "canWrite": true
                                },
                                "component": {
                                        "id": "'$3'",
                                        "identity": "'${admin_identity}'",
                                        "configurable": true
                                }
                        }
                ],
                "userGroups": []
        }
}

'''

  return 0
}


# deploy a policy for the given action ($1) and resource ($2) attributed to one user ($3)
function deploy_policy() {

  create_policy_document $1 $2 $3 > "$current_policy_document"

  #echo wget --server-response --no-check-certificate --certificate="${cert_path}" --private-key="${cert_key}" --header 'content-type: application/json' --post-file="$current_policy_document" "${base_url}/policies"
  http_response_code=$(wget --quiet --server-response --no-check-certificate --certificate="${cert_path}" --private-key="${cert_key}" --header 'content-type: application/json' --post-file="$current_policy_document" "${base_url}/policies"  2>&1| awk '/^  HTTP/{print $2}')
  echo -e "\twrite policy creation response code is ${http_response_code}"

  return ${http_response_code}
}

# #####################################################################
# GLOBAL
# #####################################################################
echo 'setting vars.'
myself=$(basename "$0")
absolute_script_path=$(readlink -f "$0")
working_dir=$(dirname "$absolute_script_path")
temp_dir="/tmp"

nifi_ip=$(hostname)
base_url="https://${nifi_ip}/nifi-api"
cert_path="${working_dir}/admin_certificate.pem"
cert_key="${working_dir}/admin_private_key.pem"
source "/nifi-manifest.txt"  # get PRIVATE_CLUSTER_FOLDER var
current_policy_document="${temp_dir}/current_policy_document.json"
admin_identity="CN=admin, OU=NIFI"

# #####################################################################
# MAIN
# #####################################################################

# setup TLS context to talk to NiFi API if needeed
if [[ -f "${cert_path}" && -f "${cert_key}" ]]; then
  echo "TLS context already available."
else
  echo "download client certificate from private bucket ${PRIVATE_CLUSTER_FOLDER} "
  aws s3 cp ${PRIVATE_CLUSTER_FOLDER}/CN=admin_OU=NIFI.p12 .
  aws s3 cp ${PRIVATE_CLUSTER_FOLDER}/CN=admin_OU=NIFI.password .
  echo 'extract client certificate stuff to talk with registry'
  key_passphrase="$(cat CN\=admin_OU\=NIFI.password)"
  openssl pkcs12 -in ./CN\=admin_OU\=NIFI.p12 -out "${cert_path}" -passin pass:${key_passphrase} -clcerts -nokeys
  openssl pkcs12 -in ./CN\=admin_OU\=NIFI.p12 -out "${cert_key}" -passin pass:${key_passphrase} -nocerts -nodes
fi

#RETRIEVE ADMIN ID
echo "fetching initial users IDs (admin and nodes)."
wget --quiet --no-check-certificate --certificate="${cert_path}" --private-key="${cert_key}" "${base_url}/tenants/users" --output-document=users_list.json
cat users_list.json | jq -r '.users[] | select( .component.identity | contains("CN=admin, OU=NIFI") )' > "admin_document.json"
admin_user_id=$(cat admin_document.json | jq -r '.component.id' )
#cat "admin_document.json"
echo -e "Admin user ID is ${admin_user_id}"


# CREATE POLICIES
echo 'starting NiFi policies deployment...'
deploy_policy "read" "system" "${admin_user_id}"
deploy_policy "read" "counters" "${admin_user_id}"
deploy_policy "write" "counters" "${admin_user_id}"







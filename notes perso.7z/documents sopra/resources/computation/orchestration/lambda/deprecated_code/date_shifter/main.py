import os
import boto3
import json
from logger import logger
from date_shifter import DateShifter

DATE_FIELD = os.environ['DATE_FIELD']
DELTA_TIME_FIELD = os.environ['DELTA_TIME_FIELD']
BODY_FIELD = "body"
RECORDS_FIELD = 'Records'
DEPLOY_ALGORITHM_LAMBDA = os.environ["DEPLOY_ALGORITHM_LAMBDA"]

lambda_client = boto3.client("lambda")


def lambda_handler(event, context):
    input_payload_list: list = event.get(RECORDS_FIELD)

    for i in input_payload_list:
        input_payload: str = i.get(BODY_FIELD)
        input_payload: dict = json.loads(input_payload)
        output_payload = transform_payload(input_payload)
        invoke_deploy_algorithm_lambda(output_payload)

    return {
        'statusCode': 200,
        'body': json.dumps('Data transforming successful!')
    }


def transform_payload(input_payload: dict):
    logger.info(f"Processing payload {str(input_payload)}")
    date: str = input_payload.get(DATE_FIELD)
    logger.debug(f"Input date {date}")
    # Delta = 1 if no other delta specified
    delta: int = input_payload.pop(DELTA_TIME_FIELD, 1)

    date_shifter = DateShifter()
    shifted_date: str = date_shifter.shift_date(date, delta)
    logger.debug(f"Output date {shifted_date}")

    output_payload: dict = input_payload
    output_payload[DATE_FIELD] = shifted_date
    logger.debug(f"Output payload {str(output_payload)}")
    return output_payload


def invoke_deploy_algorithm_lambda(payload: dict):
    deploy_algorithm_lambda = os.environ["DEPLOY_ALGORITHM_LAMBDA"]
    logger.info(f"Calling {deploy_algorithm_lambda} with payload {str(payload)}")
    encoded_data = json.dumps(payload, indent=2).encode('utf-8')
    return lambda_client.invoke(
        FunctionName=deploy_algorithm_lambda,
        InvocationType='Event',
        Payload=encoded_data
    )

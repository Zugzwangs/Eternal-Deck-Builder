from unittest import TestCase
import os
from main import transform_payload

DATE_FIELD = os.environ['DATE_FIELD']
DELTA_TIME_FIELD = os.environ['DELTA_TIME_FIELD']


class TestMain(TestCase):
    def test_payload_shouldnt_contain_delta_after_transform(self):
        input_payload = {"date": "2022-03-01", "delta_time": 1}
        output_payload = transform_payload(input_payload)
        self.assertNotIn(DELTA_TIME_FIELD, output_payload)

    def test_payload_should_contain_date_after_transform(self):
        input_payload = {"date": "2022-03-01", "delta_time": 1}
        output_payload = transform_payload(input_payload)
        self.assertIn(DATE_FIELD, output_payload)
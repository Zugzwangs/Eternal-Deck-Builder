from datetime import datetime, timedelta


class DateShifter:
    __accepted_format = "%Y-%m-%d"

    def shift_date(self, input_date: str, delta: int) -> str:
        input_date = self.format_date(input_date)
        input_date = datetime.strptime(input_date, self.__accepted_format)
        output_date = input_date - timedelta(delta)
        return output_date.strftime(self.__accepted_format)

    def format_date(self, date: str):
        try:
            datetime.strptime(date[:10], self.__accepted_format)
            return date[:10]
        except ValueError:
            raise DateFormatError(date)


class DateFormatError(ValueError):
    def __int__(self, date):
        ValueError.__init__(self)
        self.date = date

    def __str__(self):
        return f"Date {self.date} should start with format '%Y-%m-%d'."

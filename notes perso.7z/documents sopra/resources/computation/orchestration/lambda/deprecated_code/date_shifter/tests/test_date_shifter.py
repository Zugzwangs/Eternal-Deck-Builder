from unittest import TestCase
from date_shifter import DateShifter, DateFormatError


class TestDateShifter(TestCase):
    def setUp(self) -> None:
        self.date_shifter: DateShifter = DateShifter()

    def test_it_should_raise_exception_when_incorrect_date(self):
        self.format_date_raises_exception("2019", DateFormatError)
        self.format_date_raises_exception("10-01-2019", DateFormatError)
        self.format_date_raises_exception("2019-30-30", DateFormatError)

    def format_date_raises_exception(self, date: str, exception):
        with self.assertRaises(exception):
            self.date_shifter.format_date(date)

    def test_it_should_return_formated_when_correct_date(self):
        input_date: str = "2019-04-05T01:22:33Z"
        expected_output_date: str = "2019-04-05"

        output_date: str = self.date_shifter.format_date(input_date)

        self.assertEqual(expected_output_date, output_date)

    def test_returns_date_minus_shifted_date(self):
        self.shift_date_returns_date_shifted("2019-11-21T01:22:33Z", "2019-11-11", 10)
        self.shift_date_returns_date_shifted("2019-11-21T01:22:33Z", "2019-11-20", 1)
        self.shift_date_returns_date_shifted("2019-11-21", "2019-11-19", 2)

    def shift_date_returns_date_shifted(self, input_date: str, expected_output_date: str, delta: int):
        output_date: str = self.date_shifter.shift_date(input_date, delta)

        self.assertEqual(expected_output_date, output_date)










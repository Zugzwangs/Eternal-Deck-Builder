from custom_logging_2s33.insider_protection_logging \
    import InsiderProtectionLogging
import os

LOGGING_LEVEL = os.environ['LOGGING_LEVEL']

logger = InsiderProtectionLogging(__name__, LOGGING_LEVEL).logger
## Date shifter function

Receives an event with at least this input

    {
      "Records": [
        {
          "body": "{\"date\": \"2019-11-21T01:22:33Z\",  \"delta\"[OPTIONAL]: 3}"
        }
      ]
    }

Invokes lambda with output

    {"date": "2019-11-18"}

#### Run unit test
Make sure you mark **dateshifter folder as source root** (in Pycharm)

    set AWS_DEFAULT_REGION=eu-west-1
    set DATE_FIELD=date
    set DELTA_TIME_FIELD=delta_time
    set DEPLOY_ALGORITHM_LAMBDA=dummy
    set LOGGING_LEVEL=DEBUG
    
    python -m unittest discover -s .\tests\

#### Sample for integration test with deploy-algorithm-computation

    {
      "Records": [
        {
          "body": "{ \"algorithm\": \"kti_2s33\", \"mode\": \"predict\", \"date\": \"2019-11-21T01:22:33Z\" }"
        }
      ]
    }











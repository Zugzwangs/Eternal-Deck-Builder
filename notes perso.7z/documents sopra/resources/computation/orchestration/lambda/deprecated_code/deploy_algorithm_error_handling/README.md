This lambda handles the mapping output of the deploy anomy mapping step in step function job configuration.
If any algorithm was not deployed, it raises an exception. (Can't be done natively in step function).

## Main steps
    If an algorithm failed to start during cloudformation stack creation, raise an error.

## Inputs
    Step function payload with key AlgorithmResponses (output of mapper)
    
## Output
    Message if all algorithms were launched succesfully. Raises exception un runtime is killed if mapper received silent errors.

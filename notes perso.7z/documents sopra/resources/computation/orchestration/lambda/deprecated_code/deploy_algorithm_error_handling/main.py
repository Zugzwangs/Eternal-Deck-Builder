import json
import traceback
import os

def lambda_handler(event, context):
    algorithm_deploy_response = event.get('AlgorithmResponse')
    
    # When deploy algorithm computation executed successfully, response is an array of Nones
    # In all other cases, it is an exception
    # TODO : assert that the response is an exception

    failed_asserts=list()
    
    for x, alg_response in enumerate(algorithm_deploy_response):
        if alg_response is not None:
            ingested_alg_payload = event.get('FullyIngestedAlgorithm').get('Payload')

            # The order of the ACs is respected between AcResponse and FullyIngestedAC
            failed_asserts.append(
                f'Algorithm `{ingested_alg_payload[x].get("algorithm")}` failed to start with `{ingested_alg_payload[x].get("mode")}` mode.')

    if len(failed_asserts) > 0:
        raise Exception(f'Assert failed, some algorithms failed. {failed_asserts}')

    return { "message": "all algorithm cloud formation stacks deployed correctly" }

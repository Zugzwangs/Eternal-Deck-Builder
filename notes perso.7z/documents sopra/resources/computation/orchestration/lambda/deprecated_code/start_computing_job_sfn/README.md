*********************************************************************************************************************************************************************************
                                     MANAGE COMPUTING FLEET CONFIGURATION FOR USE CASES
*********************************************************************************************************************************************************************************



**Functional tests:**

*********
* INPUT *
*********
At the end of local indexes ingestion into S3, a message is sent by Nifi through SNS to this lambda

    {
      "Records": [
        {
          "EventSource": "aws:sns",
          "EventVersion": "1.0",
          "EventSubscriptionArn": "arn:aws:sns:eu-west-1:309711267128:computing-configuration:d761a3a8-5939-4714-a376-eb1905602ba9",
          "Sns": {
            "Type": "Notification",
            "MessageId": "7fbf5475-d7fc-53fe-86c6-0c580791e838",
            "TopicArn": "arn:aws:sns:eu-west-1:309711267128:computing-configuration",
            "Subject": "None",
            "Message": "{ \"date\": \"2021-06-23\", \"location\": \"aws\"}"
            "Timestamp": "2020-11-17T13:20:45.009Z",
            "SignatureVersion": "1",
            "Signature": "L1X/kAbKE/uoIO3S5s+KNdptWFcGoi5VkQiLjNwK9l7Mp0PDMG2yf6P1OhYqVnNACDBfEleP4NRLuBXH9/BFsTd/CZx+oPz/z1nqmxcgV28Rbp5iK7JCbKJC04DzpQSFx/2ZSkGAPBgKODTenMYO1nAOEOmWD1vAfTGaAU7hdK1InnCkULb0z8lU37ao+81IixQVWarWnN9Qxnf2JDxOrIlXC0ygm6Rio+KkDwAD7EVoGOsqHpD0DIc5Ic7DnTWEoqX8H9LXPk2jjlw+OiiK1L1J+5Usr+NmmguL6YhZc3KK2ZBvWLyX68pe5sYO9bA+O26J1DpBalZzBBw20sRXIw==",
            "SigningCertUrl": "https://sns.eu-west-1.amazonaws.com/SimpleNotificationService-a86cb10b4e1f29c941702d737128f7b6.pem",
            "UnsubscribeUrl": "https://sns.eu-west-1.amazonaws.com/?Action=Unsubscribe&SubscriptionArn=arn:aws:sns:eu-west-1:309711267128:computing-configuration:d761a3a8-5939-4714-a376-eb1905602ba9",
            "MessageAttributes": {}
          }
        }
      ]
    }
    
**********
* OUTPUT *
**********

Output sample for successfull sfn starting

    {
        'statusCode': 200,
        'body': json.dumps(f'sfn {sfn_name} started running!')
    }



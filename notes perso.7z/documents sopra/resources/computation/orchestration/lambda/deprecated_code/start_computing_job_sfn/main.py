import json
import boto3
import os
import time
from custom_logging_2s33.insider_protection_logging import InsiderProtectionLogging
from datetime import datetime, timedelta

client = boto3.client('stepfunctions')
SFN_ARN = os.environ['SFN_ARN']
LOGGING_LEVEL = os.environ['LOGGING_LEVEL']

logger = InsiderProtectionLogging(__name__, LOGGING_LEVEL).logger


def lambda_handler(event, context):
    logger.info(f"Get the following event {event}")
    sfn_name = SFN_ARN.split(':')[-1]


    # define date
    yesterday = datetime.now() - timedelta(1)
    date = datetime.strftime(yesterday, '%Y-%m-%d')

    # define location
    # cron scheduled at 5:0:0 UTC for LAN
    # cron scheduled at 7:0:0 UTC for AWS

    trigger_event_names = event['resources'][0].split("/")[-1]

    if "lan" in trigger_event_names.lower():
        location = "LAN"

    elif "aws" in trigger_event_names.lower():
        location = "AWS"

    else:
        return {
            'statusCode': 403,
            'body': f'location {location} unknown!'
        }

    exclude_default_value = True

    message = {
        "date": date,
        "location": location,
        "exclude-already-executed-alg": exclude_default_value
    }

    ts = round(time.time())
    response = client.start_execution(
        stateMachineArn=SFN_ARN,
        name=f'{sfn_name}_{ts}',
        input=json.dumps(message)
    )
    return {
        'statusCode': 200,
        'body': json.dumps(f'sfn {sfn_name} started running!')
    }
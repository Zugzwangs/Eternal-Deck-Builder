# MANAGE ALGORITHM CALCULATION

## Input
The lambda is expecting a payload structured as:

    event = {"algorithm":"ac_XXX_2s33", "date":"2020-10-10", "mode":"fit"}

## Output
response structured as :

    {'statusCode': 200, 'body': 'Algorithm ac_XXX_2s33 launched successfully in fit mode'}


## Main steps
    1) input payload validation
    2) cloudFormation stack preparation
    3) cloudFormation stack creation
    4) API call to the web service wrapper and algorithm code run

#!/usr/bin/env python
# -*- coding: utf-8 -*-
import datetime
import json
import os
import traceback
from custom_logging_2s33.insider_protection_logging import InsiderProtectionLogging

LOGGING_LEVEL = os.environ['LOGGING_LEVEL']
logger = InsiderProtectionLogging(__name__, LOGGING_LEVEL).logger


class Payload_validator:
    """
    Class with specific methods to validate the arguments of a received payload
    input: expected_input as set of string
    """
    def __init__(self, expected_input: set):
        self.expected_input = expected_input

        self.validation_dict = {
            # Dictionnary of validation functions
            'algorithm': self.validate_algorithm,
            'date': self.validate_date,
            'mode': self.validate_mode
        }

    def validate_payload(self, payload: dict) -> dict:
        """
        input: payload as dictionnary
        output: response= {'validation': false, 'statusCode': 400, 'body': 'sdfsdfsd'}
        """
        try:
            # initialization
            response = {}

            # validation of the presence of expected input
            response = self.validate_presence_expected_input(payload)
            if response['validation'] == False:
                return response

            for k, v in payload.items():
                if k in self.validation_dict.keys():
                    response = self.validation_dict[k](v)
                    if response['validation'] == False:
                        return response

            response['validation'] = True
            response['statusCode'] = 200
            message = 'Complete event payload validation: SUCCESS.'
            response['body']= message
            logger.info(message)
            return response

        except Exception:
            error = traceback.format_exc()
            response['validation'] = False
            response['statusCode'] = 500
            message = f'Unexpected error occured during the event payload validation: {error}'
            response['body'] = message
            logger.error(message)
            return response


    def validate_presence_expected_input(self, payload: dict) -> dict:
        """
        Validation of the mandatory expected inputs
        input: payload as dictionnary
        output: response= {'validation': false, 'statusCode': 400, 'body': 'sdfsdfsd'}
        """
        try:
            # initialization
            error = None
            response= {}

            for item in self.expected_input:
                if item not in payload:
                    error = item + ', '
                elif payload[item] == None:
                    error = item + ' is None, '

            if error:
                response['validation'] = False
                response['statusCode'] = 400
                message = 'Validation of the presence of the mandatory input: INVALID REQUEST - missing mandatory arguments: {error}'
                response['body'] = message
                logger.error(message)
                return response

            else:
                response['validation'] = True
                response['statusCode'] = 400
                message = 'Validation of the presence of the mandatory input: SUCCESS.'
                response['body'] = message
                logger.info(message)
                return response

        except Exception:
            error = traceback.format_exc()
            response['validation'] = False
            response['statusCode'] = 500
            message = f'Unexpected error occured during the validation of the presence of mandatory input: {error}'
            response['body'] = message
            logger.error(message)
            return response


    def validate_algorithm(self,alg: str) -> dict:
        """
        Validation of the algorithm name
        :param alg: algorithm name as string
        :return response= {'validation': false, 'statusCode': 400, 'body': 'sdfsdfsd'}
        """

        try:
            # initialization
            response = {}
            valid_alg_set = {'kti_2s33',
                            'uc_01_new',
                            'ac_01_2s33',
                            'ac_03_2s33',
                            'ac_05_2s33',
                            'ac_07_2s33',
                            'ac_09_2s33',
                            'ac_10_2s33',
                            'ac_24_2s33',
                            'ac_30_2s33',
                            'ac_33_2s33',
                            'ac_39_2s33',
                            'ac_40_2s33',
                            'ac_42_2s33',
                            'ac_45_2s33',
                            'ac_46_2s33',
                            'ac_47_2s33'}


            if alg not in valid_alg_set:
                response['validation'] = False
                response['statusCode'] = 400
                message = 'Validation of the algorithm name: INVALID REQUEST - Unknown uc: {alg}'
                response['body'] = message
                logger.error(message)
                return response

            else:
                response['validation'] = True
                response['statusCode'] = 400
                message = f'Validation of the algorithm name {alg}: SUCCESS.'
                response['body'] = message
                logger.info(message)
                return response

        except Exception:
            error = traceback.format_exc()
            response['validation'] = False
            response['statusCode'] = 500
            message = f'Unexpected error occured during the validation of the algorithm name: {error}'
            response['body'] = message
            logger.error(message)
            return response


    def validate_mode(self,mode: str) -> dict:
        """
        Validation of the mode
        :param mode: calculation mode as string
        :return response= {'validation': false,'statusCode' : 400, 'body': 'sdfsdfsd'}
        """

        try:
            # initialization
            response = {}
            valid_mode_set = {'fit','predict'}

            if mode not in valid_mode_set:
                response['validation'] = False
                response['statusCode'] = 400
                message = 'Validation of the calculation mode: INVALID REQUEST - Unknown mode: {mode}'
                response['body'] = message
                logger.error(message)
                return response

            else:
                response['validation'] = True
                response['statusCode'] = 400
                message = f'Validation of the calculation mode {mode}: SUCCESS.'
                response['body'] = message
                logger.info(message)
                return response

        except Exception:
            error = traceback.format_exc()
            response['validation'] = False
            response['statusCode'] = 500
            message = f'Unexpected error occured during the validation of calculation mode: {error}'
            response['body'] = message
            logger.error(message)
            return response


    def validate_date(self,date_string) -> dict:
        """
        Validation of the date format and check of consistency of value passed
        :param date: input date as string for the day of the prediction or the final day for the fit mode calculation
        :return response= {'validation': false, 'statusCode': 400, 'body': 'sdfsdfsd'}
        """

        try:
            # initialization
            response = {}

            # step 1: format validation
            try:
                date_parse = datetime.datetime.strptime(date_string[0:10], '%Y-%m-%d').date()
            except Exception:
                response['validation'] = False
                response['statusCode'] = 400
                message = f'Validation of the date format: INVALID DATE FORMAT - date should be in format YYYY-MM-DD, value passed: {date_string}.'
                response['body'] = message
                logger.error(message)
                return response

            # step 2: date value consistency
            today = datetime.date.today()
            if date_parse > today:
                response['validation'] = False
                response['statusCode'] = 400
                message = f'Validation of date consistency: INVALID DATE - Date must < today, value passed: {date_string}.'
                response['body'] = message
                logger.error(message)
                return response

            else:
                response['validation'] = True
                response['statusCode'] = 200
                message =  f'Validation of the date {date_string}: SUCCESS.'
                response['body'] = message
                logger.info(message)
                return response


        except Exception:
            error = traceback.format_exc()
            response['validation'] = False
            response['statusCode'] = 500
            message = f'Unexpected error occured during the validation of date: {error}'
            response['body'] = message
            logger.error(message)
            return response

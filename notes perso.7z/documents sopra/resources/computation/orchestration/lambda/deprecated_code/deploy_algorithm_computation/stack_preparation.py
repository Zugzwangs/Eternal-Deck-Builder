#!/usr/bin/env python
# -*- coding: utf-8 -*-
import os
import json
import traceback
import datetime
import re
import boto3
from custom_logging_2s33.insider_protection_logging import InsiderProtectionLogging

REGION = os.environ['REGION']
LOGGING_LEVEL = os.environ['LOGGING_LEVEL']

logger = InsiderProtectionLogging(__name__, LOGGING_LEVEL).logger

ssm_client = boto3.client('ssm')
s3_client = boto3.client('s3')
elb_client = boto3.client('elbv2')
ec2_client = boto3.client('ec2')
ec2_resource = boto3.resource('ec2')
lambda_client = boto3.client('lambda')


class Braincell_stack_preparator:
    """
    Class with specific methods to collect all required data to create a braincell stack from a lambda
    """

    def __init__(self, mode, algorithm_name, computation_date, lambda_name):
        """
        :param mode: calculation mode fit, predict, fit_predict as str
        :param algorithm_name: algorithm name as str
        :param computation_date: algorithm case date of processing as str
        :param lambda_name: lambda function name as str
        """
        self.computation_date = computation_date
        self.algorithm_name = algorithm_name
        self.mode = mode
        self.lambda_name = lambda_name

    def define_stack_parameters(self):
        """
        :return: a complete cloudformation_settings,stack_parameters as a tuple of dict,[dict]
        """

        try:
            # settings based on dynamodb static table
            cloudformation_settings = self.fetch_recipe()

            # settings based on lambda configuration
            lambda_conf = self.extract_lambda_conf()
            cloudformation_settings['VpcId'] = self.determine_vpc_id(lambda_conf)
            cloudformation_settings['InstanceSubNet'] = self.determine_prefered_subnet(lambda_conf)

            # settings based on algorithm_name and mode
            cloudformation_settings['InstanceAvailabilityZone'] = "eu-west-1b"
            cloudformation_settings['latestRhel7Ami'] = "/airbus/platform/ssm/2s33/ami-" + self.algorithm_name + "-latest"
            cloudformation_settings['latestAmiSnapshot'] = "/airbus/platform/ssm/2s33/snap-" + self.algorithm_name + "-latest"
            algorithm_name_alphanum = self.algorithm_name.replace("_",
                                                    "")  # template need use case in alphanumeric due to naming limitations
            cloudformation_settings['Algorithm'] = self.algorithm_name
            cloudformation_settings['ComputationDate'] = self.computation_date
            cloudformation_settings['AlgorithmAlphanumeric'] = algorithm_name_alphanum
            cloudformation_settings['Mode'] = self.mode

            # determination of the execution_id based on ami jenkins build number
            cloudformation_settings['ExecutionID'] = self.determine_execution_id()

            # settings from template
            template_parameters = self.fetch_cloudformation_template_parameters(cloudformation_settings['template'])

            # overwriting the template parameters set-up dynamically
            stack_parameters = []  # will hold all parameters values used to create the stack
            for parameter_name, parameter_settings in template_parameters.items():
                current_stack_parameter = {}
                logger.info('processing parameter ' + parameter_name)
                # logger.info(json.dumps(parameter_settings))

                # prepare the current parameter for the stack creation
                current_stack_parameter['ParameterKey'] = parameter_name
                current_stack_parameter['UsePreviousValue'] = False

                if parameter_name in cloudformation_settings:
                    # use value from dynamoDB settings
                    logger.info('value found in recipe')
                    current_stack_parameter['ParameterValue'] = cloudformation_settings[parameter_name]
                elif 'Default' in parameter_settings:
                    # fallback with the template default value if no settings define in dynamoDB
                    logger.info('using default template value')
                    current_stack_parameter['ParameterValue'] = parameter_settings['Default']
                else:
                    logger.error("can't generate a value for the template parameter " + parameter_name)
                    logger.error("deployment failed")
                    raise Exception
                stack_parameters.append(current_stack_parameter)
            logger.info(str(stack_parameters))

        except Exception:
            error = traceback.format_exc()
            logger.error(f'Unexpected error occurs during stack parameters definition: {error}')
            raise Exception(error)

        else:
            return cloudformation_settings, stack_parameters

    def fetch_recipe(self):
        """
        :return: cloudformation_settings as a dict
        """
        try:
            # Call the execution-recipe-service API
            logger.info('Fetching recipe from execution-recipe-service ...')
            recipe_hardware_request = {
                "algorithm": self.algorithm_name,
                "mode": self.mode
            }
            response_streaming_obj = lambda_client.invoke(
                FunctionName='execution-recipe-hardware-get-route',
                InvocationType='RequestResponse',
                Payload=json.dumps(recipe_hardware_request, indent=2).encode('utf-8')
            )
            response_payload = response_streaming_obj['Payload'].read().decode("utf-8")
            logger.info(f"recipe_hardware_response: {response_payload}")
            recipe_hardware_response = json.loads(response_payload)

        except Exception:
            error = traceback.format_exc()
            logger.error(f'Unexpected error occurs when fetching recipe settings: {error}')
            raise error
        else:
            return recipe_hardware_response

    def extract_lambda_conf(self):
        """
        :return: lambda_conf as dict
        """
        try:
            logger.info('Lambda introspection to get VPC/Subnet settings ...')
            lambda_conf = lambda_client.get_function(FunctionName=self.lambda_name)
        except Exception:
            error = traceback.format_exc()
            message = f'Unexpected error during extraction of Lambda configuration: {error}'
            logger.error(message)
            raise Exception(message)
        else:
            return lambda_conf

    def determine_vpc_id(self, lambda_conf):
        """
        :return: vpc_id as string
        """
        try:
            vpc_id = lambda_conf['Configuration']['VpcConfig']['VpcId']

        except Exception:
            error = traceback.format_exc()
            logger.error(f'Unexpected error during extraction of VpcID: {error}')
            raise error

        else:
            logger.info('VPC ID found: ' + vpc_id)
            return vpc_id

    def determine_prefered_subnet(self, lambda_conf):
        """
        :return: prefered_subnet as string
        """
        try:
            logger.info(f"Determination of the subnet for deployment...")
            subnet_list = lambda_conf['Configuration']['VpcConfig']['SubnetIds']
            logger.info(f"Authorized subnets for deployment: {subnet_list}")
        except KeyError:
            message = 'No subnet found in the lambda VPC configuration. Lambda function aborted.'
            logger.error(message)
            raise Exception(message)

        try:
            best_pool_count = 0
            for current_subnet in subnet_list:
                subnet_client = ec2_resource.Subnet(current_subnet)
                ip_left = subnet_client.available_ip_address_count
                logger.info("IP lest in " + current_subnet + ": " + str(ip_left))
                if ip_left > best_pool_count:
                    best_pool_count = ip_left
                    prefered_subnet = current_subnet
            # check if have at least one IP available
            if best_pool_count < 1:
                message = 'No IP available, deployment failed.'
                logger.error(message)
                raise Exception(message)
            else:
                logger.info('Deployment will be done using ' + prefered_subnet + ' subnet')
                return prefered_subnet

        except Exception:
            error = traceback.format_exc()
            message = f"Unexpected error occured during determination of the subnet: {error}"
            logger.error(message)
            raise Exception(message)

    def determine_execution_id(self):
        """
        output: execution_id as string

        execution_id param is used to name the stack, the instance and the webServiceTargetGroup
        execution_id param is made of a timestamp and of the Jenkins ami build number
        The expected format is: DDMMYYYY-HHMMSS-XX
        By default the execution_id is set to 1 as per template computing_instance_with_alb.json
        """

        logger.info('Determination of the execution_id ...')

        # determination of the timestamp
        timestamp = datetime.datetime.now().strftime('%d%m%Y-%H%M%S')

        logger.info('ssm instrospection to get the id of the ami used')
        try:
            ssm_param_name = "/airbus/platform/ssm/2s33/ami-" + self.algorithm_name + "-latest"
            ami_id = ssm_client.get_parameter(Name=ssm_param_name)['Parameter']['Value']
        except Exception:
            error = traceback.format_exc()
            message = f"Error when trying to extract the ami_id: {error}"
            logger.error(message)
            raise Exception(message)

        else:
            logger.info('ec2 instrospection to get the name of the id of the ami used')
            try:
                # print(ec2_client.describe_images(ImageIds=[ami_id]))
                ami_name = ec2_client.describe_images(ImageIds=[ami_id])['Images'][0]['Name']
            except Exception:
                error = traceback.format_exc()
                message = f"Error when trying to extract the ami name : {error}"
                logger.error(message)
                raise Exception(message)

            else:
                logger.info('Extraction of the jenkins build number from the ami name.')
                try:
                    clean_1 = ami_name[:-17]
                    clean_2 = re.findall(r'\-\d+\-', clean_1)[-1]
                    build_number = clean_2.replace('-', '')
                    execution_id = timestamp + '-' + build_number
                    logger.info(f'The execution_id is {execution_id}')
                except Exception:
                    error = traceback.format_exc()
                    message = f"Error during jenkins build number extraction from ami name : {error}"
                    logger.error(message)
                    raise Exception(message)

        return execution_id

    def fetch_cloudformation_template_parameters(self, template_s3_url):
        """
        :param template_s3_url as string
        :return: template_parameters as dict
        """
        try:
            logger.info("Fetching cloudformation template parameters ...")

            logger.info('Downloading the cloudformation template')
            bucket_fqdn, template_key = template_s3_url.replace("https://", "").split("/", 1)
            bucket_name = bucket_fqdn.split('.')[0]
            template_name = template_key.split('/')[-1]
            local_template_file = '/tmp/' + template_name
            logger.info('Extracted bucket name: ' + bucket_name)
            logger.info('Extracted cf template s3 key: ' + template_key)
            logger.info('Template will be downloaded to the local file: ' + local_template_file)
            s3_client.download_file(bucket_name, template_key, local_template_file)

            logger.info('Scanning the template template for parameters list')
            with open(local_template_file) as json_template:
                template_parameters = json.load(json_template)['Parameters']
                # logger.debug(json.dumps(template_parameters))

        except Exception:
            error = traceback.format_exc()
            message = f"Unexpected error occured during cloudformation template parameters fetch: {error}"
            logger.error(message)
            raise Exception(message)

        else:
            return template_parameters

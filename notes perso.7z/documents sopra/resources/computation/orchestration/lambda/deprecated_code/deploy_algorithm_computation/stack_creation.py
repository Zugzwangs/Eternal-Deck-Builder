#!/usr/bin/env python
# -*- coding: utf-8 -*-

import boto3
from botocore.exceptions import ClientError
import os
from custom_logging_2s33.insider_protection_logging import InsiderProtectionLogging

LOGGING_LEVEL = os.environ['LOGGING_LEVEL']
logger = InsiderProtectionLogging(__name__, LOGGING_LEVEL).logger

cf_client = boto3.client('cloudformation')
elb_client = boto3.client('elbv2')


class Braincell_stack_creator:
    """
    Class with specific methods to create a braincell stack
    """

    def __init__(self, computed_stack_name, template_url, stack_parameters):
        """
        :param computed_stack_name as string
        :param template_url as string
        :param stack_parameters as [dict]
        """
        self.computed_stack_name = computed_stack_name
        self.template_url = template_url
        self.stack_parameters = stack_parameters

    def create_stack(self):
        """
        :return: stack_creation as dict
        """

        try:
            logger.info("Creation of the braincell stack")

            stack_creation = cf_client.create_stack(
                StackName= self.computed_stack_name,
                TemplateURL= self.template_url,
                Parameters= self.stack_parameters,
                OnFailure='DELETE',
                EnableTerminationProtection=False)

        except ClientError as ex:
            logger.error('An error occured during braincell stack creation')
            error_message = ex.response['Error']['Message']
            logger.error(error_message)
            raise Exception(error_message)

        else:
            return stack_creation


    def get_stack_identity(self, stack_creation):
        """
        :param stack_creation as dict (result of create_stack function)
        :return: instance_id, instance_ip as a tuple of string
        """
        try:
            logger.info("Get ip and id of the instance created by the stack ...")
            stack_desciption = cf_client.describe_stacks(StackName=stack_creation['StackId'])
            # logger.debug(json.dumps(stack_desciption, indent=2, default=str))
            outputs_list = stack_desciption['Stacks'][0]['Outputs']
            # logger.debug(json.dumps(outputs_list, indent=2, default=str))
            # list of outputs are in the form: [{"OutputKey": "name","OutputValue": "value","Description": "lorem upsum"}, ...]
            instance_id_output = next(filter(lambda output: output['OutputKey'] == 'SingleInstanceID', outputs_list), None)
            instance_id = instance_id_output['OutputValue']
            logger.info('instance ID is ' + instance_id)
            instance_ip_output = next(filter(lambda output: output['OutputKey'] == 'SingleInstanceIP', outputs_list), None)
            instance_ip = instance_ip_output['OutputValue']
            logger.info('instance IP is ' + instance_ip)

        except ClientError as ex:
            logger.error('An error occured during retrieval of stack instance id and ip')
            error_message = ex.response['Error']['Message']
            logger.error(error_message)
            raise Exception(error_message)

        else:
            return instance_id, instance_ip

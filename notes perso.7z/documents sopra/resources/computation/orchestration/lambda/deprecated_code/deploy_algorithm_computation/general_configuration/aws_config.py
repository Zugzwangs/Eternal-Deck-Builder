ELB = 'alb-computing'
ALGORITHM_FIELD = 'algorithm'
DATE_FIELD = 'date'
MODE_FIELD = 'mode'

CHECK_PREREQUISITES_FIELD = 'check_prerequisites'
CHECK_IS_ALREADY_RUN_FIELD = 'check_already_run'

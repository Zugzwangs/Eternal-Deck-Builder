import json
import traceback
import os
import boto3
from param_validation import Payload_validator
from stack_preparation import Braincell_stack_preparator
from stack_creation import Braincell_stack_creator
from general_configuration.aws_config import *

from custom_logging_2s33.insider_protection_logging import InsiderProtectionLogging

LOGGING_LEVEL = os.environ['LOGGING_LEVEL']
logger = InsiderProtectionLogging(__name__, LOGGING_LEVEL).logger
get_runnable_lambda = os.environ['EXECUTION_RECIPE_RUNNABLE_GET_LAMBDA']


def lambda_handler(event, context):
    """
    input: event = {"algorithm":"ac_XXX_2s33", "date":"2020-10-10", "mode":"fit"}
    output: stack created

    This Lambda is triggered by the previous Lambda called get_computable_algorithms.
    It will deploy the relevant braincell instance in a cloud fromation stack.

    Main steps:
        0) Check if it is a queue
        1) input payload validation
        2) cloudFormation stack preparation
        3) cloudFormation stack creation

    note: VpcId is not required to be set in dynamoDB recipe as the lambda will perform introspection to retrieve the value at run time
    """

    ######################
    ### initialization ###
    ######################

    message = "failed"  # temporary output to be replaced by the response
    response = {}

    ################################
    ### input Payload validation ###
    ################################

    try:
        
        if is_a_queue(event):
            event = read_queue(event)
        
        logger.info(f"Step 1 - Event payload validation ...")
        logger.info(f"Received event: {json.dumps(event)}")

        # Instantiation of a ¨Payload_validator
        expected_input = {'algorithm', 'date', 'mode'}
        validator = Payload_validator(expected_input)
        
        validation = validator.validate_payload(event)
        if validation['validation'] == False:
            message = 'Error during validation of parameters: ' + json.dumps(validation.pop('validation', None))
            raise Exception(message)

    except Exception:
        error = traceback.format_exc()
        message = f'Unexpected error occured during the event payload validation at lambda handler main level: {error}'
        logger.error(message)
        raise Exception(message)

    ########################################
    ## Check algorithm runnability        ##
    ########################################
    try:
        lambda_client = boto3.client('lambda')
        # Get relevent value from incoming event
        current_mode = event.get(MODE_FIELD)
        computation_date = event.get(DATE_FIELD)
        algorithm = event.get('algorithm')

        check_prerequisites = bool_string_to_boolean(event.get(CHECK_PREREQUISITES_FIELD,
                                                               "True"))
        check_already_run = bool_string_to_boolean(event.get(CHECK_IS_ALREADY_RUN_FIELD, "True"))

        is_runnable_payload = {
            ALGORITHM_FIELD: algorithm,
            DATE_FIELD: computation_date,
            MODE_FIELD: current_mode, 
            CHECK_PREREQUISITES_FIELD: check_prerequisites,
            CHECK_IS_ALREADY_RUN_FIELD: check_already_run
        }

        #logger.info(f"Checking if the algorithm {algorithm} is runnable")
        response_streaming_obj = lambda_client.invoke(
            FunctionName=get_runnable_lambda,
            InvocationType='RequestResponse',
            Payload=json.dumps(is_runnable_payload, indent=0).encode('utf-8')
        )

        response_payload = response_streaming_obj['Payload'].read().decode("utf-8")
        #logger.info(f"is_runnable response: {response_payload}")

        # Convert string response to boolean
        is_runnable = eval(response_payload.title())

        if not is_runnable:
            not_runnable_error = f"Algorithm {algorithm} is not runnable"
            logger.error(not_runnable_error)
            raise Exception(not_runnable_error)
        else:
            logger.info(f"Algorithm {algorithm} is runnable")

    except:
        error = traceback.format_exc()
        response['statusCode'] = 500
        message = f'{error}'
        response['body'] = message
        return response

    ########################################
    ### cloudFormation Stack Preparation ###
    ########################################
    try:
        
        logger.info(f'Step 2 - CloudFormation stack preparation ...')

        # Get relevent value from incoming event
        current_mode = event['mode']
        computation_date = event["date"]
        algorithm_name = event["algorithm"]
        # Instantiation of a Braincell_stack_preparator
        stack_preparator = Braincell_stack_preparator(current_mode, algorithm_name, computation_date,
                                                      'deploy-algorithm-computation')
        cloudformation_settings, stack_parameters = stack_preparator.define_stack_parameters()


    except:
        error = traceback.format_exc()
        message = f'Unexpected error occured during stack preparation at lambda handler main level: {error}'
        logger.error(message)
        raise Exception(message)

    ######################################################################
    ### CREATE THE STACK
    ######################################################################
    try:
        logger.info('Step 3: CloudFormation Stack creation ...')
        # Instantiation of a Braincell stack creator
        execution_id = cloudformation_settings['ExecutionID']
        algorithm_name_alphanum = cloudformation_settings['AlgorithmAlphanumeric']
        template_url = cloudformation_settings['template']
        computed_stack_name = f"braincell-{algorithm_name_alphanum}-{current_mode}-{execution_id}"
        stack_creator = Braincell_stack_creator(computed_stack_name, template_url, stack_parameters)
        stack_creation = stack_creator.create_stack()


    except Exception:
        error = traceback.format_exc()
        message = f"Unexpected error during stack creation: {error}"
        logger.error(message)
        raise Exception(message)


def bool_string_to_boolean(value):
    if value == "False":
        return False
    elif value == "True":
        return True
    else:
        raise Exception(f"Expected boolean value and received {value}")

def is_a_queue(event):
    logger.info(f"Step 0 - Check if it is a sqs call {bool(event.get('Records'))}")
    return bool(event.get('Records'))


def read_queue(event):
    records = []
    for record in event.get('Records', []):
        records.append(json.loads(record.get('body')))
    return records[0]
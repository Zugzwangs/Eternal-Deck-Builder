import json
import boto3
import os

from storage.datasource.athena import client as athena_client

from storage.configuration_db.dynamodb import adapter as dynamodb_adapter

from custom_logging_2s33.insider_protection_logging import InsiderProtectionLogging

LOGGING_LEVEL = os.environ['LOGGING_LEVEL']
CATALOG = os.environ['CATALOG']
SPLUNK_RAW_INDEXES_DATABASE = os.environ['SPLUNK_RAW_INDEXES_DATABASE']
logger = InsiderProtectionLogging(__name__, LOGGING_LEVEL).logger



def lambda_handler(event, context):
    date = event["date"]
    location = event["location"]

    logger.info(f"Getting the list of indexes ingested from {location} for the date of {date}")

    index_summary = athena_client.get_indexes_summary_by_location(date, location)

    return index_summary

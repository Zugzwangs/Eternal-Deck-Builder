INDEX_FIELD = 'idx'
CANONICAL_NAME_FIELD = 'canonical_name'

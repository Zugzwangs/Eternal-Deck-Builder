import os
from athena_2s33.athena import Athena
from custom_logging_2s33.insider_protection_logging import InsiderProtectionLogging


LOGGING_LEVEL =                     os.environ['LOGGING_LEVEL']
TMP_RESULTS_BUCKET =                os.environ['TMP_RESULTS_BUCKET']
TMP_RESULTS_FOLDER =                os.environ['TMP_RESULTS_FOLDER']
CATALOG =                           os.environ['CATALOG']
STATISTICS_DATABASE =               os.environ['STATISTICS_DATABASE']
SPLUNK_INGESTION_SUMMARY_TABLE =    os.environ['SPLUNK_INGESTION_SUMMARY_TABLE']


logger = InsiderProtectionLogging(__name__, LOGGING_LEVEL).logger

athena = Athena(TMP_RESULTS_BUCKET, TMP_RESULTS_FOLDER)


def get_indexes_summary_by_location(date, location):
    logger.info(f"Getting the {location} indexes ingestion summary")
    query = (f"SELECT 'ai-2s33-wineventlog' AS idx, date, sum(cast(counter AS bigint))AS count "
             f"        FROM {SPLUNK_INGESTION_SUMMARY_TABLE}  "
             f"        WHERE date = '{date}' "
             f"        AND day = '{date}' "
             f"        AND location = '{location}'"
             f"        AND   summary_idx like '%wineventlog%' group by location, date "
             f"        UNION "
             f"        SELECT regexp_replace(summary_idx, '-summary', '') "
             f"        as idx, date, cast(counter as bigint) AS count "
             f"        FROM  {SPLUNK_INGESTION_SUMMARY_TABLE}  "
             f"        WHERE date = '{date}' "
             f"        AND day = '{date}' "
             f"        AND location ='{location}'"
             f"        AND  summary_idx  not like '%wineventlog%' ")

    indexes_summary = athena.select_data_as_json(CATALOG, STATISTICS_DATABASE, query)
    logger.info(f"Index summary for day {date}: {indexes_summary}")
    return indexes_summary

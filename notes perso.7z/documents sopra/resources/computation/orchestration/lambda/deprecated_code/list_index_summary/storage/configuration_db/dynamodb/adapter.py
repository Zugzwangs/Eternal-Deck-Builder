import boto3
import os
from custom_logging_2s33.insider_protection_logging import InsiderProtectionLogging

from storage.configuration_db.dynamodb import client as dynamodb_client
from storage.configuration_db.dynamodb.asserts import parsing_error

from general_configuration.record_fields import INDEX_FIELD

LOGGING_LEVEL = os.environ['LOGGING_LEVEL']
logger = InsiderProtectionLogging(__name__, LOGGING_LEVEL).logger



def get_index_by_canonical_name(canonical_index):
    try:
        r = dynamodb_client.get_index_by_canonical_name(canonical_index)
        cn = r.pop()[INDEX_FIELD]
        return cn
    except Exception as e:
        logger.error(parsing_error(e))
        raise e


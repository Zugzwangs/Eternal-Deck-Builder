import boto3
import os
from boto3.dynamodb.conditions import Key
from custom_logging_2s33.insider_protection_logging import InsiderProtectionLogging

from storage.configuration_db.dynamodb.asserts import request_error
from general_configuration.record_fields import CANONICAL_NAME_FIELD, INDEX_FIELD


LOGGING_LEVEL = os.environ['LOGGING_LEVEL']
INDEX_CONFIGURATION_TABLE = os.environ['INDEX_CONFIGURATION_TABLE']


logger = InsiderProtectionLogging(__name__, LOGGING_LEVEL).logger

dynamodb_url = 'https://dynamodb.eu-west-1.amazonaws.com'
client = boto3.resource('dynamodb', endpoint_url=dynamodb_url)



def get_index_by_canonical_name(canonical_index):
    try:
        table = client.Table(INDEX_CONFIGURATION_TABLE)
        response = table.scan(
            ProjectionExpression='#idx',
            ExpressionAttributeNames={
                "#cn_idx": CANONICAL_NAME_FIELD,
                "#idx": INDEX_FIELD
            },
            ExpressionAttributeValues={
                ':cn_idx': canonical_index
            },
            FilterExpression='#cn_idx=:cn_idx'
        )
        item = response['Items']
    except Exception as e:
        logger.error(request_error(e))
        raise e
    else:
        return item


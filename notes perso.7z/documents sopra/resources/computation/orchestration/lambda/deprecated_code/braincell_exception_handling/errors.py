from enum import Enum
import re

from configuration import *
from custom_logging_2s33.insider_protection_logging import InsiderProtectionLogging

class ErrorActions (Enum):
    """
    Enumeration of currently implemented mitigation actions
    """
    CONTINUE = 1
    RETRY = 2
    INCREASE_MEMORY = 3
    
class ErrorParsor:
    """
    Class to access the Dynamo DB used for the orchestration of algorithm execution.
    """


    def __init__(self):
        
        # Associated exit code and action
        # Detail of each exit code is describe in confluence : https://confluence.airbus.corp/display/Z2S33INPR/Logging
        self.action_by_exit_codes = {
            2: ErrorActions.CONTINUE,
            
            50: ErrorActions.CONTINUE,
            51: ErrorActions.CONTINUE,
            52: ErrorActions.CONTINUE,
            53: ErrorActions.CONTINUE,
            
            60: ErrorActions.CONTINUE,
            61: ErrorActions.CONTINUE,
            62: ErrorActions.CONTINUE,
            
            70: ErrorActions.CONTINUE,
            71: ErrorActions.CONTINUE,
            72: ErrorActions.CONTINUE,
            73: ErrorActions.CONTINUE,
            
            70: ErrorActions.CONTINUE,
            70: ErrorActions.CONTINUE,
            70: ErrorActions.CONTINUE,
        }
        
        # For the exit code 1, an extra step of string parsing in necessary to elect the error
        self.action_by_string_code1 = {
            "numpy.core._exceptions._ArrayMemoryError": ErrorActions.INCREASE_MEMORY,
            "MemoryError": ErrorActions.INCREASE_MEMORY,
            "ConnectionClosedError": ErrorActions.RETRY,
            "ConnectionError": ErrorActions.RETRY
        }
        
    def get_mitigation_action(self, logs):
        logger.info('Identification of error in declaredmitigation list')
            
        # Search by exit code
        code = None
        for line in logs:
            if "Process finished with exit code" in line:
                code = int(re.findall(r'\d+', line)[-1])
                logger.info(f'Exit code found : {code}')
                if code == 1:
                    # Code 1 is "All Other errors", a string based search is performed
                    logger.info(f'For code 1, parsing text for a string based search.')
                    break
                elif code in self.action_by_exit_codes.keys():
                    action = self.action_by_exit_codes[code]
                    logger.info(f'Action for this code is : {action}')
                    return action
                else:
                    raise Exception(f'Action to take for the exit code {code} is undefined in the handling strategy, please add an action.')
                    
        # Search by string: 
        for line in logs:
            for err_name in self.action_by_string_code1.keys():
                if err_name in line:
                    action = self.action_by_string_code1[err_name]
                    logger.info(f'Action for this code is : {action}')
                    return action
        
        # No handling defined in neither strategies :(
        if code == 1:
            raise Exception(f'Action to take for the exit code {code} is undefined in the by string handling strategy ')
        else:
            raise Exception(f'No action defined in the by string nor the by code handling strategy')

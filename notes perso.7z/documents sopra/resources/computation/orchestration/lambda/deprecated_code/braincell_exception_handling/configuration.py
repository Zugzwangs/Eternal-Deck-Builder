from custom_logging_2s33.insider_protection_logging import InsiderProtectionLogging

# Global
logger = InsiderProtectionLogging(__name__, 'DEBUG').logger
KTI_LABEL = 'kti_2s33'



# DynamoDB Fields
ALGORITHM_MODE_DB = "algorithm_mode"
ALGORITHM_DB = "algorithm"
DATE_DB = "date"
STATUS_DB = "status"
DURATION_DB = "duration"
FIT_PREDICT_MODE_DB = "fit_predict_mode"
EXECUTION_PARAMETERS_DB = "execution_parameters"
EXECUTION_DATE_DB = "executed_on"

SETTINGS_DB = "settings"


# DynamoDB Values
SUCCESS_LABEL = "success"
FAILED_LABEL = "fail"
FIT_LABEL = "fit"
PREDICT_LABEL = "predict"

# Input SNS message Fields
ALGORITHM_FIELD = 'algorithm'
INSTANCE_ID = 'ec2_id'
DATE_FIELD = 'date'
STATUS_FIELD = 'status'
FIT_OR_PREDICT_FIELD = 'fit_or_predict'
STACK_NAME = 'stack_name'
DURATION_FIELD = 'duration'
EXECUTION_PARAMETERS_FIELD = 'execution_parameters'

# Message sent to execution-recipe-service
ALGORITHM1_FIELD = 'algorithm1'
ALGORITHM2_FIELD = 'algorithm2'
MODE_FIELD = "mode"
MODE1_FIELD = "mode1"
MODE2_FIELD = "mode2"

# Message send to trigger KTI lambda computation
DATE_OUTPUT = "date"
MODE_OUTPUT = "mode"

# Lambda OUTPUT messages
JOB_SUCCESS = 'Job succeded'
JOB_FAIL = 'Job failed'

import json
import time
from storage import StorageHandler
import boto3
import sys, os
import linecache
from configuration import *
import time
from data_validation import InputMessageParser
from errors import ErrorParsor, ErrorActions

lambda_client = boto3.client('lambda')
logs_client = boto3.client('logs')
REGION = os.environ['REGION']
EXCEPTION_STATUS_TABLE = os.environ['EXCEPTION_STATUS_TABLE']
LAMBDA_DEPLOY_ALGORITHM_NAME = os.environ['LAMBDA_DEPLOY_ALGORITHM_NAME']

class LambdaHandler:

    def __init__(self):
        try:
            self.storage_handler = StorageHandler()
            self.input_parser = InputMessageParser()
            self.error_parser = ErrorParsor()
        except Exception as e:
            exc_type, exc_obj, exc_tb = sys.exc_info()
            logger.error("Executing error: {} at line {}".format(e, exc_tb.tb_lineno))
            raise Exception(e)

    def main(self, event, context):
        try:
            # Parsing SNS message
            message = self.input_parser.parse_and_validate(event)
            
            # Update db with sensor status
            item = {
                DATE_DB: message[DATE_FIELD],  # Hash key of the table, Date of data used for execution
                ALGORITHM_MODE_DB: message[ALGORITHM_FIELD] + '_' + message[FIT_OR_PREDICT_FIELD], # Sort key of the table Name of the algortihm executed concatenated with the mode
            }

            log_group = "/2s33/computing/algorithm/" + message[ALGORITHM_FIELD]
            
            log_stream = self.find_log_stream(log_group)
            logger.info(f'log stream is : {log_stream["arn"]}')
            
            log_lines = self.fetch_latest_log_lines(log_group, log_stream)

            logger.debug(f'latest log entries are')
            logger.debug(log_lines)
            
            action = self.error_parser.get_mitigation_action(log_lines)
            logger.info(f'action to take : {action}')
            
            last_record = self.storage_handler.get_last_alg_exception_status(item)
            
            static_recipe = self.storage_handler.fetch_recipe(message[ALGORITHM_FIELD], message[FIT_OR_PREDICT_FIELD])
            #['InstanceTypeParameter']

            self.handle_action(action, last_record, item, static_recipe )

            return {'response': json.dumps(f'Exception handling over.')}

        except Exception as e:
            exc_type, exc_obj, exc_tb = sys.exc_info()
            logger.error("Executing error: {} at line {}".format(e, exc_tb.tb_lineno))
            return JOB_FAIL

    def find_log_stream(self, log_group):
        # Currently, the latest streams are searched only
        # The lambda doesn't handle "previous" executions
        # TODO: write output stream from braincell when sending sns notification to job completion
        # TODO: pagination for log stream seach

        logger.info(f"Looking for latest stream in {log_group}")
        
        log_streams = logs_client.describe_log_streams(
            logGroupName=log_group,
            orderBy="LogStreamName",
            descending=True,
            limit=50)['logStreams']
            
        # desc order
        elected_stream = None
        for stream in log_streams:
            if 'algorithm' in stream['logStreamName']:
                elected_stream = stream
                break
            
        if elected_stream is None:
            raise Exception(f'Could not find a log stream like {log_group}/*-algorithm.')

        return elected_stream
        
    def fetch_latest_log_lines(self, log_group, log_stream):
        logs = logs_client.get_log_events(
            logGroupName=log_group,
            logStreamName=log_stream['logStreamName'],
            limit=10,
            startFromHead=False
        )['events']
        
        # Post processing to refine, make sure the correct instance is kept
        log_messages = []
        for line in logs:
            log_messages.append(line['message'])

        log_messages.reverse()
        return log_messages
    
    def handle_action (self, action, last_record, item, static_recipe):
        if action == ErrorActions.CONTINUE:
            item['last_action']= ErrorActions(action.value).name
            self.storage_handler.set_alg_exception_status(item)

        elif action == ErrorActions.RETRY:
            item['last_action'] = ErrorActions(action.value).name
            if 'retry_count' not in last_record :
                item['retry_count'] = 1
                self.storage_handler.set_alg_exception_status(item)
            elif last_record['retry_count'] >= 3:
                logger.info('Maximum number of retries reached. Action ignored')
            else:
                item['retry_count']=last_record['retry_count']+1
                self.storage_handler.set_alg_exception_status(item)
        elif action == ErrorActions.INCREASE_MEMORY:
            item['last_action'] = ErrorActions(action.value).name
            if 'retry_count' not in last_record :
                static_size = static_recipe['InstanceTypeParameter']
                item['retry_count'] = 1
                item['retry_size'] = self.get_next_instance_size(static_size)
                self.storage_handler.set_alg_exception_status(item)
            elif last_record['retry_count'] >= 3:
                logger.info('Maximum number of retries reached. Action ignored')
            else:
                item['retry_count']=last_record['retry_count']+1
                item['retry_size'] = self.get_next_instance_size(last_record['retry_size'])
                self.storage_handler.set_alg_exception_status(item)
    def get_next_instance_size(self, current_size):
        # TODO: Validate this list
        try:
            allowed = ["m4.large","m4.xlarge","m4.2xlarge","m4.4xlarge","m4.10xlarge","m4.16xlarge"]
            return allowed[allowed.index(current_size)+1]
        except ValueError:
            logger.info('Not an m4 instance, searching in m5 instances')
        
        allowed = ["m5.large","m5.xlarge","m5.2xlarge","m5.4xlarge","m5.8xlarge","m5.12xlarge", "m5.126large", "m5.24xlarge"]
        return allowed[allowed.index(current_size)+1]
        

def lambda_handler(event, context):
    lambda_ = LambdaHandler()
    return lambda_.main(event, context)

import boto3
import os
import json
import traceback
import datetime
import re
import time

from configuration import *
from boto3.dynamodb.conditions import Key, Attr
from custom_logging_2s33.insider_protection_logging import InsiderProtectionLogging
import traceback

lambda_client = boto3.client('lambda')

REGION = os.environ['REGION']
EXCEPTION_STATUS_TABLE = os.environ['EXCEPTION_STATUS_TABLE']

class StorageHandler:
    """
    Class to access the Dynamo DB used for the orchestration of algorithm execution.
    """

    def __init__(self):
        self.url = 'https://dynamodb.eu-west-1.amazonaws.com'
        self.db = boto3.resource('dynamodb', endpoint_url=self.url, region_name=REGION)

    def set_alg_exception_status(self, item):
        """
        Upload the status of the exception try / retry to dynamo table
        :param message:
        :return:
        """

        table = self.db.Table(EXCEPTION_STATUS_TABLE)
        response = table.put_item(
            Item=item
        )
              
    def fetch_recipe(self, ac_name, ac_mode):
        """
        :return: cloudformation_settings as a dict
        """
        try:
            # Call the execution-recipe-service API
            logger.info('Fetching recipe from execution-recipe-service ...')
            recipe_hardware_request = {
                "algorithm": ac_name,
                "mode": ac_mode
            }
            response_streaming_obj = lambda_client.invoke(
                FunctionName='execution-recipe-hardware-get-route',
                InvocationType='RequestResponse',
                Payload=json.dumps(recipe_hardware_request, indent=2).encode('utf-8')
            )
            response_payload = response_streaming_obj['Payload'].read().decode("utf-8")
            logger.info(f"recipe_hardware_response: {response_payload}")
            recipe_hardware_response = json.loads(response_payload)
    
        except Exception:
            error = traceback.format_exc()
            logger.error(f'Unexpected error occurs when fetching recipe settings: {error}')
        else:
            return recipe_hardware_response
            

    def get_last_alg_exception_status(self, item):
        """
        Upload the status of the execution to DynanoDB table
        :param message:
        :return:
        """
        table = self.db.Table(EXCEPTION_STATUS_TABLE)
        response = table.get_item(
            Key = {
            'date': item['date'],
            'algorithm_mode': item['algorithm_mode']
            }
        )
        
        if 'Item' not in response.keys():
            return {}
        else:
            return response['Item']
import json
import time
from storage import StorageHandler
from instance_handler import InstanceHandler
import boto3
import sys, os
import linecache
from configuration import *
import time
from data_validation import InputMessageParser, OutputMessageParser

EXECUTION_STATUS_TABLE = os.environ['EXECUTION_STATUS_TABLE']
MY_SNS_TOPIC_ARN = os.environ['MY_SNS_TOPIC_ARN']
EXCEPTION_HANDLING_SNS = os.environ['EXCEPTION_HANDLING_SNS']
REGION = os.environ['REGION']


class LambdaHandler:

    def __init__(self, sns_client, lambda_client):
        try:
            self.storage_handler = StorageHandler()
            self.instance_handler = InstanceHandler()
            self.sns_topic_arn = MY_SNS_TOPIC_ARN
            self.input_parser = InputMessageParser()
            self.output_parser = OutputMessageParser()
            self.sns_client = sns_client
            self.lambda_client = lambda_client
        except Exception as e:
            exc_type, exc_obj, exc_tb = sys.exc_info()
            logger.error("Executing error: {} at line {}".format(e, exc_tb.tb_lineno))

    def main(self, event, context):
        try:
            # Parsing SNS message
            message = self.input_parser.parse_and_validate(event)

            # Update db with sensor status
            item = {
                DATE_DB: message[DATE_FIELD],  # Hash key of the table, Date of data used for execution
                ALGORITHM_MODE_DB: message[ALGORITHM_FIELD] + '_' + message[FIT_OR_PREDICT_FIELD],
                # Sort key of the table Name of the algortihm executed concatenated with the mode
                ALGORITHM_DB: message[ALGORITHM_FIELD],  # Name of the algorithm executed
                FIT_PREDICT_MODE_DB: message[FIT_OR_PREDICT_FIELD],
                STATUS_DB: message[STATUS_FIELD],
                DURATION_DB: message[DURATION_FIELD],
                EXECUTION_DATE_DB: str(get_current_time()),
                EXECUTION_PARAMETERS_DB: message[EXECUTION_PARAMETERS_FIELD]
            }
            self.storage_handler.set_alg_execution_status(item)
            logger.info(f"{item} upload to {EXECUTION_STATUS_TABLE} table.")

            # Shut down the instance
            instance_status = self.instance_handler.stop_instance(message[INSTANCE_ID])
            logger.info("Instance {} status {}".format(message[INSTANCE_ID], instance_status))

            # Delete the stack
            stack_status = self.instance_handler.delete_cfn(message[STACK_NAME])
            logger.info("STACK {} status {}.".format(message[STACK_NAME], stack_status))

            # Send SNS message to confirm end computation fleet
            self.send_email(message)

            # Are any other algorithms post-requisites of this one?
            postreqs = self.get_postrequisite_algorithms(message[ALGORITHM_FIELD], message[FIT_OR_PREDICT_FIELD])

            # Check the list of post-requisites to see if they are runnable
            for postreq in postreqs:
                postreq_alg, postreq_mode = postreq['postreq_algorithm_mode'].rsplit('_', 1)
                if self.is_algorithm_runnable(postreq_alg, postreq_mode, message[DATE_FIELD]):
                    # If runnable, then launch it...
                    self.launch_algorithm_computation(postreq_alg, postreq_mode, message[DATE_FIELD])

            return JOB_SUCCESS

        except Exception as e:
            exc_type, exc_obj, exc_tb = sys.exc_info()
            logger.error("Executing error: {} at line {}".format(e, exc_tb.tb_lineno))
            return JOB_FAIL

    def get_postrequisite_algorithms(self, algorithm, mode):
        """
        Get the list of algorithm/mode that are post-requisites for a specific algorithm
        :param algorithm: the name of the algorithm e.g. ac_01_2s33, kti_2s33
        :param mode: fit or predict mode
        :return: list of algorithm/mode keys of post-requisite execution recipes
        """

        # Call the execution-recipe-service API
        postrequisites_request = {
            ALGORITHM_FIELD: algorithm,
            MODE_FIELD: mode
        }
        logger.info(f"execution-recipe-postrequisites-get request: {postrequisites_request}")
        response_streaming_obj = self.lambda_client.invoke(
            FunctionName='execution-recipe-postrequisites-get-route',
            InvocationType='RequestResponse',
            Payload=json.dumps(postrequisites_request, indent=2).encode('utf-8')
        )
        response_payload = response_streaming_obj['Payload'].read().decode("utf-8")

        # Convert string response to list
        response_list = json.loads(response_payload)

        logger.info(f"post-requisites list for {algorithm}_{mode}: {response_list}")
        return response_list

    def is_algorithm_runnable(self, algorithm, mode, date):
        """
        Return True if the algorithm is ready to run, else return False.
        :return: Bool
        """

        # Call the execution-recipe-service API
        runnable_request = {
            ALGORITHM_FIELD: algorithm,
            MODE_FIELD: mode,
            DATE_OUTPUT: date,
            CHECK_PREREQUISITES_KEY: True,
            CHECK_ALREADY_RUN_KEY: True
        }
        logger.info(f"execution-recipe-runnable-get request: {runnable_request}")
        response_streaming_obj = self.lambda_client.invoke(
            FunctionName='execution-recipe-runnable-get-route',
            InvocationType='RequestResponse',
            Payload=json.dumps(runnable_request, indent=2).encode('utf-8')
        )
        response_payload = response_streaming_obj['Payload'].read().decode("utf-8")

        if REQUEST_FAIL.casefold() == response_payload.title().casefold():
            raise Exception(f"execution-recipe-runnable-get endpoint returned failure - check "
                            f"execution-recipe-runnable-get logstream for the reason")

        # Convert string response to boolean
        _is_algorithm_runnable = eval(response_payload.title())

        logger.info(f"{algorithm}_{mode} is runnable: {_is_algorithm_runnable}")
        return _is_algorithm_runnable

    def launch_algorithm_computation(self, algorithm, mode, date):
        """
        Launch algorithm computation for the specified date
        :param mode:
        :param algorithm:
        :param date:
        :return:
        """
        logger.info(f"{algorithm}_{mode} is ready to be computed. Lambda will be invoked.")
        message_to_send = {
            ALGORITHM_OUTPUT: algorithm,
            DATE_OUTPUT: date,
            MODE_OUTPUT: mode
        }
        # Check message is correct
        self.output_parser.validate_message(message_to_send)
        # Send message to the lambda
        # Encore message
        encoded_data = json.dumps(message_to_send, indent=2).encode('utf-8')
        logger.info(f"Message to send to the lambda deploy-algorithm-computation: {encoded_data}")
        logger.info(f"Message to send to the lambda deploy-algorithm-computation: {message_to_send}")
        logger.info(f"Message encoded: {encoded_data}")
        response = self.lambda_client.invoke(
            FunctionName='deploy-algorithm-computation',
            InvocationType='Event',
            Payload=encoded_data
        )
        logger.info(f"Message send to the lambda deploy-algorithm-computation: {message_to_send}")
        logger.info(str(response))

    def send_email(self, message):
        # Send message to SNS
        self.sns_client.publish(
            TopicArn=self.sns_topic_arn,
            Message=json.dumps(message, indent=2),
            Subject="Algorithm {} on {} Finished with {} status for {}.".format(
                message[ALGORITHM_FIELD],
                message[DATE_FIELD],
                message[STATUS_FIELD],
                message[FIT_OR_PREDICT_FIELD]
            )
        )

    def start_exception_handling_async(self, event):
        self.sns_client.publish(
            TopicArn=EXCEPTION_HANDLING_SNS,
            Message=json.dumps(event),
        )


def get_current_time():
    t = time.localtime()
    return time.strftime("%Y-%m-%dT%H:%M:%S:%z", t)


def lambda_handler(event, context):
    time.sleep(20)
    sns_client = boto3.client('sns', region_name=REGION)
    lambda_client = boto3.client('lambda', region_name=REGION)
    lambda_ = LambdaHandler(sns_client, lambda_client)
    return lambda_.main(event, context)

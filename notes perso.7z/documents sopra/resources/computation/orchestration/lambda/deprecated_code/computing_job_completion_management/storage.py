import boto3
from boto3.dynamodb.conditions import Key, Attr
import os
from configuration import *
from custom_logging_2s33.insider_protection_logging import InsiderProtectionLogging

REGION = os.environ['REGION']
EXECUTION_STATUS_TABLE = os.environ['EXECUTION_STATUS_TABLE']

class StorageHandler:
    """
    Class to access the Dynamo DB used for the orchestration of algorithm execution.
    """

    def __init__(self):
        self.url = 'https://dynamodb.eu-west-1.amazonaws.com'
        self.db = boto3.resource('dynamodb', endpoint_url=self.url, region_name=REGION)

    def set_alg_execution_status(self, message):
        """
        Upload the status of the execution to DynanoDB table
        :param message:
        :return:
        """
        try:
            table = self.db.Table(EXECUTION_STATUS_TABLE)
            response = table.put_item(
                Item=message
            )
        except Exception as e:
            logger.error("[ERROR] Failed dynamodb operation. Reason: {}. Method: {}"
                  .format(e, 'storage.set_ac_step_status'))


### Example of test event 

    {
      "Records": [
        {
          "EventSource": "aws:snsg",
          "EventVersion": "1.0",
          "EventSubscriptionArn": "arn:aws:sns:eu-west-1:309711267128:computing-job-completion:8932e4a8-e204-449f-8d48-2166b65660ed",
          "Sns": {
            "Type": "Notification",
            "MessageId": "4f8a0cbd-d42f-5c8a-8303-56d5519373fb",
            "TopicArn": "arn:aws:sns:eu-west-1:309711267128:computing-job-completion",
            "Subject": "None",
            "Message": "{\"algorithm\": \"ac_46_2s33\", \"date\": \"2022-01-20\", \"fit_or_predict\": \"fit\", \"status\": \"fail\", \"duration\": \"0:01:43\", \"status_detail\": \"\", \"stack_name\": \"arn:aws:cloudformation:eu-west-1:309711267128:stack/braincell-ac462s33-fit-24012022-103902-60/d9816d20-7d01-11ec-9315-066e87af92a1\", \"ec2_id\": \"i-0fa4c6a6094d5ac2c\", \"execution_parameters\": {\"date_0\": \"2022-01-15\", \"date_f\": \"2022-01-20\", \"fit_predict_mode\": \"fit\", \"staging_bucket\": \"s3-2s33-dev-scheduled-staging-data-eu-west-1\", \"results_bucket\": \"s3-2s33-dev-scheduled-output-data-eu-west-1\", \"athena_buffer_bucket\": \"s3-2s33-dev-athena-query-results-eu-west-1\", \"model_bucket\": \"s3-2s33-dev-scheduled-output-data-eu-west-1\", \"log_level\": \"INFO\", \"run_sensors\": \"True\", \"athena_database\": \"splunk_raw_indexes\", \"staging\": \"False\"}}",
            "Timestamp": "2022-01-24T10:46:20.553Z",
            "SignatureVersion": "1",
            "Signature": "lQ/4nE8PKdtWQbGjOs6X6TnGhbSaJhtVgQU5/y0ES6FA0MX8fcuoMmgz3ghf0Lbj/HOgXY3VSt2ffuNr+ggrxDwonD4GShW3qMOqgoMbDmPvl0Ubve7vXbg57gRYI5jn+9vyJosbOSPd2nQwURuvW7tBsHrtQmuU9TkQDJRlNMbcsZuuiWxoInXPMavSGDqqxSUQeXhs578PoNztQ2uoNIQKhrnIy2xeCx6cwGVCQOrjojsKsnzSGHMA2IusKZS7EaG9ZHSqVdOapdwzoKz1oxEyCKze6M1JlKUwvyeaJFc/gj4ZDQCT9wHrjxafNYLRDk2HrOF9c+maHSzVB9wj2g==",
            "SigningCertUrl": "https://sns.eu-west-1.amazonaws.com/SimpleNotificationService-7ff5318490ec183fbaddaa2a969abfda.pem",
            "UnsubscribeUrl": "https://sns.eu-west-1.amazonaws.com/?Action=Unsubscribe&SubscriptionArn=arn:aws:sns:eu-west-1:309711267128:computing-job-completion:8932e4a8-e204-449f-8d48-2166b65660ed",
            "MessageAttributes": {}
          }
        }
      ]
    }


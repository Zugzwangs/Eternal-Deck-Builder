import unittest
from unittest.mock import patch, call
from main import LambdaHandler
from configuration import *
from data_validation import InputMessageParser, OutputMessageParser
from storage import StorageHandler
from instance_handler import InstanceHandler
import boto3
from botocore.response import StreamingBody
import json
from io import BytesIO

FAIL_STATUS = 'fail'
SUCCESS_STATUS = 'success'
MODE_FIT = 'fit'
MODE_PREDICT = 'predict'


def lambda_context_generator():
    """
    Build a sample lambda context object to use as input to the computing_job_completion_management lambda code under test.
    :return:
    """
    # TODO Not sure what should be in context, but nothing seems to be reading it currently
    return json.dumps({}, indent=1)


def lambda_input_event_generator(algorithm, mode, status):
    """
    Build a sample SNS event to use as input to the computing_job_completion_management lambda code under test.
    :param algorithm:
    :param mode:
    :param status:
    :return:
    """
    sample_msg_dict = {
        'algorithm': algorithm,
        'fit_or_predict': mode,
        'date': '2022-08-02',
        'status': status,
        'duration': '0:45:07',
        'execution_parameters': {
            "date_0": "2022-08-02",
            "date_f": "2022-08-02",
            "fit_predict_mode": mode,
            "staging_bucket": "s3-2s33-dev-scheduled-staging-data-eu-west-1",
            "athena_buffer_bucket": "s3-2s33-dev-athena-query-results-eu-west-1",
            "model_bucket": "s3-2s33-dev-scheduled-output-data-eu-west-1",
            "log_level": "INFO",
            "athena_database": "splunk_raw_indexes",
            "staging": "False",
            "output_results_bucket": "s3-2s33-dev-scheduled-output-data-eu-west-1"
        },
        'ec2_id': 'i-08feb6ca1cf2d145c',
        'stack_name': 'arn:aws:cloudformation:eu-west-1:309711267128:stack/braincell-ac302s33-predict-03082022-061554-31/bcb5d720-12f3-11ed-864e-02b3e3d8701f'
    }
    sample_msg_json = json.dumps(sample_msg_dict, indent=1)

    sample_sns_event = {
        'Records': [
            {
                'EventSource': 'aws:sns',
                'EventVersion': '1.0',
                'EventSubscriptionArn': 'arn:aws:sns:eu-west-1:309711267128:computing-job-completion:8932e4a8-e204-449f-8d48-2166b65660ed',
                'Sns': {
                    'Type': 'Notification',
                    'MessageId': '6e258f92-c4d0-5c38-95a0-d4f6e402c14a',
                    'TopicArn': 'arn:aws:sns:eu-west-1:309711267128:computing-job-completion',
                    'Subject': 'SNS from Wrapper: ' + algorithm + ' for 2022-08-02 and predict mode finished with status fail',
                    'Message': sample_msg_json,
                    'Timestamp': '2022-08-03T07:06:58.312Z',
                    'SignatureVersion': '1',
                    'Signature': 'a7JNk7CWox0ydA0hDPKj8c9+jWzUN7e8B4DdUhFwqKXxzIJOcWxvDqSsgqjX3ZqtA1E7WXpTfRIVwu3mYU9vUVBNTLcnsbvmWGdLKwQsoueXLbWcsVV98cxJfhpBu1hvCPEOZFDCT8XsOm9ykBxmcTtoyHEgSBQ6kURWCCC9ZjHhwMUAvKhx2WPhW66CiSNSaR9O7FK34s5DWFZqYs3zh+xX4jlqQXgZzFzmaaJoUSVjQK3eJmmygrgbYLcrSK/uzJtMiXhsKpVZt/wHL8VFkyTNt040bRGaKCjEGpF2Bchl54DhZ4iW+hjJWijTSi22ID/h2DzD+ofIYBOH08+ZAw==',
                    'SigningCertUrl': 'https://sns.eu-west-1.amazonaws.com/SimpleNotificationService-56e67fcb41f6fec09b0196692625d385.pem',
                    'UnsubscribeUrl': 'https://sns.eu-west-1.amazonaws.com/?Action=Unsubscribe&SubscriptionArn=arn:aws:sns:eu-west-1:309711267128:computing-job-completion:8932e4a8-e204-449f-8d48-2166b65660ed',
                    'MessageAttributes': {}
                }
            }
        ]
    }
    return sample_sns_event


def mock_lambda_args_based_return(**kwargs):
    """
    Dynamically determine which return value to provide from the same lambda_client mock, depending on which lambda
    function was called.
    :param kwargs: keyword args should always include "FunctionName"
    :return: the appropriate return value for the lambda function
    """
    if kwargs['FunctionName'] == 'deploy-algorithm-computation':
        response = 'True'
    elif kwargs['FunctionName'] == 'execution-recipe-prerequisites-get-route':
        response = [
            {
                'postreq_algorithm_mode': 'kti_2s33_predict',
                'prereq_algorithm_mode': 'ac_01_2s33_predict',
                'scaler': 'gamma',
                'weight': '5'
            },
            {
                'postreq_algorithm_mode': 'kti_2s33_predict',
                'prereq_algorithm_mode': 'ac_07_2s33_predict',
                'scaler': 'gamma',
                'weight': '5'
            },
            {
                'postreq_algorithm_mode': 'kti_2s33_predict',
                'prereq_algorithm_mode': 'ac_10_2s33_predict',
                'scaler': 'gamma',
                'weight': '4'
            },
            {
                'postreq_algorithm_mode': 'kti_2s33_predict',
                'prereq_algorithm_mode': 'ac_24_2s33_predict',
                'scaler': 'gamma',
                'weight': '4'
            },
            {
                'postreq_algorithm_mode': 'kti_2s33_predict',
                'prereq_algorithm_mode': 'ac_30_2s33_predict',
                'scaler': 'gamma',
                'weight': '5'
            },
            {
                'postreq_algorithm_mode': 'kti_2s33_predict',
                'prereq_algorithm_mode': 'ac_33_2s33_predict',
                'scaler': 'gamma',
                'weight': '4'
            },
            {
                'postreq_algorithm_mode': 'kti_2s33_predict',
                'prereq_algorithm_mode': 'ac_42_2s33_predict',
                'scaler': 'gamma',
                'weight': '5'
            },
            {
                'postreq_algorithm_mode': 'kti_2s33_predict',
                'prereq_algorithm_mode': 'ac_45_2s33_predict',
                'scaler': 'gamma',
                'weight': '3'
            },
            {
                'postreq_algorithm_mode': 'kti_2s33_predict',
                'prereq_algorithm_mode': 'ac_46_2s33_predict',
                'scaler': 'gamma',
                'weight': '3'
            },
            {
                'postreq_algorithm_mode': 'kti_2s33_predict',
                'prereq_algorithm_mode': 'ac_47_2s33_predict',
                'scaler': 'gamma',
                'weight': '5'
            }
        ]
    elif kwargs['FunctionName'] == 'execution-recipe-postrequisites-get-route':
        response = [
            {
                'postreq_algorithm_mode': 'kti_2s33_predict',
                'prereq_algorithm_mode': 'ac_01_2s33_predict'
            },
            {
                'postreq_algorithm_mode': 'ts_01_2s33_predict',
                'prereq_algorithm_mode': 'ac_01_2s33_predict'
            }
        ]
    elif kwargs['FunctionName'] == 'execution-recipe-runnable-get-route':
        response = 'True'
    else:
        return Exception("exception occurred")

    response_encoded = json.dumps(response).encode("utf-8")

    response_payload = StreamingBody(
        BytesIO(response_encoded),
        len(response_encoded)
    )

    mocked_response = {
        'Payload': response_payload
    }
    return mocked_response


class TestComputingJobCompletionManagementHandler(unittest.TestCase):

    def setUp(self) -> None:
        self.maxDiff = None
        self.lambda_handler = LambdaHandler(None, None)
        self.input_parser = InputMessageParser()
        self.output_parser = OutputMessageParser()

    @patch('storage.StorageHandler')
    @patch('instance_handler.InstanceHandler')
    @patch('boto3.client')  # mock_sns_client
    @patch('boto3.client')  # mock_lambda_client
    def test_main(self,
                  mock_storage_handler,
                  mock_instance_handler,
                  mock_sns_client,
                  mock_lambda_client):
        storage_handler = mock_storage_handler.return_value
        storage_handler.set_alg_execution_status.return_value = None
        self.lambda_handler.storage_handler = storage_handler

        instance_handler = mock_instance_handler.return_value
        instance_handler.delete_cfn.return_value = INSTANCE_DELETE_SUCCESS
        instance_handler.stop_instance.return_value = INSTANCE_STOP_SUCCESS
        self.lambda_handler.instance_handler = instance_handler

        sns_client = mock_sns_client.return_value
        sns_client.publish.return_value = None
        self.lambda_handler.sns_client = sns_client

        lambda_client = mock_lambda_client.return_value
        lambda_client.invoke.side_effect = mock_lambda_args_based_return
        self.lambda_handler.lambda_client = lambda_client

        expected_response = JOB_SUCCESS

        input_event = lambda_input_event_generator('ac_01_2s33', MODE_PREDICT ,SUCCESS_STATUS)
        context = lambda_context_generator()

        response = self.lambda_handler.main(input_event, context)
        self.assertEqual(response, expected_response)

        # TODO figure out how to assert that the lambda_client mock has been called twice with
        #  kwargs['FunctionName'] == 'deploy-algorithm-computation'
        #  once to deploy kti_2s33_predict and once to deploy ts_001_2s33_predict

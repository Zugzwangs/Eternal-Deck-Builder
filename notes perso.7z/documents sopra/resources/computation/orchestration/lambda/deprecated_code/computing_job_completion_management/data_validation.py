from configuration import *
from abc import ABC, abstractmethod
import json
import sys


def field(name):
    def field_generic(func):
        def wrapper(*arg):
            logger.info(f'Field validation: {name}')
            try:
                func(*arg)
            except Exception as e:
                logger.error(f"Executing error on function {func.__name__} with error: {e}")

        return wrapper

    return field_generic


class MessageParser(ABC):
    """
    Abstract class to implement for parsing and validating input/output messages.
    Overwrite _validate_message and _parse_event.
    Call validate_message for validation only.
    Call parse_message for paring only.
    Call parse_and_validate for both.
    """

    def parse_and_validate(self, message):
        try:
            logger.info(f"Message to parse and validate: {message}")
            message = self.parse_message(message)
            self.validate_message(message)
            logger.info(f"Parsed and validated message {message}")
            return message
        except Exception as e:
            exc_type, exc_obj, exc_tb = sys.exc_info()
            logger.error("Executing error: {} at line {}".format(e, exc_tb.tb_lineno))

    def validate_message(self, message):
        """
        Function to use to check and validate all the fields of the message.
        Should log errors and set default value if needed.
        :param message: Message to check
        """
        try:
            logger.info(f"Validation of the parameters start.")
            self._validate_message(message)
            logger.info(f"Validation of the parameters end.")
        except Exception as e:
            exc_type, exc_obj, exc_tb = sys.exc_info()
            logger.error("Executing error: {} at line {}".format(e, exc_tb.tb_lineno))

    def parse_message(self, message):
        try:
            logger.info(f"Parsing message start.")
            logger.info(f"Message before parsing: {message}")
            message = self._parse_message(message)
            logger.info(f"Message after parsing: {message}")
            logger.info(f"Parsing message end.")
            return message
        except Exception as e:
            exc_type, exc_obj, exc_tb = sys.exc_info()
            logger.error("Executing error: {} at line {}".format(e, exc_tb.tb_lineno))

    @abstractmethod
    def _parse_message(self, message):
        """
        Use this function to parse the message.
        :param event: Event to parse
        :return: parsed event as python Dict
        """
        return message

    @abstractmethod
    def _validate_message(self):
        """
        Overwrite this function to check all parameters.
        """
        pass

    def _check_key_exists(self, key, message):
        if key not in message.keys():
            logger.error(f"Key {key} is missing in SNS input message: {message}")
            return False
        return True

    def raise_key_error(self, key):
        raise KeyError(f"{key} is missing in the message to check.")


class InputMessageParser(MessageParser):
    """
    Class to handle the SNS message the trigger the lambda. Parse and check the consistency of the message.
    """

    algorithm_field = ALGORITHM_FIELD
    fit_or_predict_field = FIT_OR_PREDICT_FIELD
    date_field = DATE_FIELD
    status_field = STATUS_FIELD
    duration_field = DURATION_FIELD
    execution_parameters = EXECUTION_PARAMETERS_FIELD
    ec2_id_field = INSTANCE_ID
    stack_id_field = STACK_NAME

    def _parse_message(self, event):
        # if isinstance(event, dict):
        #     message = event
        # else:
        #     message = json.loads(event)
        message = json.loads(event['Records'][0]['Sns']['Message'])

        return message

    def _validate_message(self, message):
        self._check_algorithm_field(message)
        self._check_date_field(message)
        self._check_status_field(message)
        self._check_duration_field(message)
        self._check_execution_parameters_field(message)
        self._check_fit_or_predict_field(message)
        self._check_ec2_id_field(message)
        self._check_stack_name_field(message)

    @field(fit_or_predict_field)
    def _check_fit_or_predict_field(self, message):
        if not self._check_key_exists(self.fit_or_predict_field, message):
            self.raise_key_error(self.fit_or_predict_field)
        authorized_values = [FIT_LABEL, PREDICT_LABEL]
        if message[self.fit_or_predict_field] not in authorized_values:
            logger.error(
                f"{self.fit_or_predict_field} not authorized: {message[self.status_field]}. \
                Should be in {authorized_values}")

    @field(algorithm_field)
    def _check_algorithm_field(self, message):
        logger.info(f"wtff {message}")
        logger.info(f"wtfff {type(message)}")
        if not self._check_key_exists(self.algorithm_field, message):
            self.raise_key_error(self.algorithm_field)

    @field(date_field)
    def _check_date_field(self, message):
        if not self._check_key_exists(self.date_field, message):
            self.raise_key_error(self.date_field)

    @field(status_field)
    def _check_status_field(self, message, default_value=FAILED_LABEL):
        if not self._check_key_exists(self.status_field, message):
            message[self.status_field] = FAILED_LABEL
        authorized_values = [FAILED_LABEL, SUCCESS_LABEL]
        if message[self.status_field] not in authorized_values:
            message[self.status_field] = default_value
            logger.error(
                f"{self.status_field} not authorized: {message[self.status_field]}. Should be in {authorized_values}")
            logger.info(f"{self.status_field} replaced with default status: {default_value}")

    @field(duration_field)
    def _check_duration_field(self, message, default_value="0"):
        if not self._check_key_exists(self.duration_field, message):
            message[self.duration_field] = default_value
            logger.info(f"{self.duration_field} replaced with default status: {default_value}")

    @field(execution_parameters)
    def _check_execution_parameters_field(self, message):
        if self.execution_parameters not in message.keys():
            message[self.execution_parameters] = {}

    @field(stack_id_field)
    def _check_stack_name_field(self, message):
        if not self._check_key_exists(self.stack_id_field, message):
            self.raise_key_error(self.stack_id_field)

    @field(ec2_id_field)
    def _check_ec2_id_field(self, message):
        if not self._check_key_exists(self.ec2_id_field, message):
            self.raise_key_error(self.ec2_id_field)


class OutputMessageParser(MessageParser):
    algorithm_field = ALGORITHM_OUTPUT
    date_field = DATE_OUTPUT
    mode_field = MODE_OUTPUT

    def _parse_message(self, event):
        return event

    def _validate_message(self, message):
        self._check_algorithm_field(message)
        self._check_date_field(message)
        self._check_mode_field(message)

    @field(algorithm_field)
    def _check_algorithm_field(self, message):
        if not self._check_key_exists(self.algorithm_field, message):
            logger.error(f"Payload to send the deploy_algorithm_computation is wrong. Key {self.algorithm_field} is not existing.")
            self.raise_key_error(self.algorithm_field)

    @field(date_field)
    def _check_date_field(self, message):
        if not self._check_key_exists(self.date_field, message):
            logger.error(f"Payload to send the deploy_algorithm_computation is wrong. Key {self.date_field} is not existing.")
            self.raise_key_error(self.date_field)

    @field(mode_field)
    def _check_mode_field(self, message):
        if not self._check_key_exists(self.mode_field, message):
            logger.error(f"Payload to send the deploy_algorithm_computation is wrong. Key {self.mode_field} is not existing.")
            self.raise_key_error(self.mode_field)
import boto3
import time
import os
from configuration import *
from custom_logging_2s33.insider_protection_logging import InsiderProtectionLogging

REGION = os.environ['REGION']

class InstanceHandler:

    def __init__(self):
        self.ec2 = boto3.client('ec2', region_name=REGION)
        self.cloud_formation = boto3.resource('cloudformation', region_name=REGION)

    def stop_instance(self, instance):
        if isinstance(instance, str):
            instance = [instance]
        try:
            self.ec2.stop_instances(InstanceIds=instance)
            logger.info("waiting for the instance to stop")
            time.sleep(10)

            # ec2.terminate_instances(InstanceIds=instance)
            return INSTANCE_STOP_SUCCESS

        except Exception as e:
            logger.error("Executing error: {}".format(e))
            return "Executing error: {}".format(e)

    def delete_cfn(self, stack_name):
        try:
            stack = self.cloud_formation.Stack(stack_name)
            stack.delete()
            return INSTANCE_DELETE_SUCCESS
        except Exception as e:
            logger.error("Executing error: {}".format(e))
            return "Executing error: {}".format(e)

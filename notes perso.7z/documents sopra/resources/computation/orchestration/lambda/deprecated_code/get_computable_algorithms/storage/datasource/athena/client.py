from athena_2s33.athena import Athena
from custom_logging_2s33.insider_protection_logging import InsiderProtectionLogging
import os
from general_configuration.record_fields import NB_EVENTS_FIELD
from general_configuration.config import LOGGING_LEVEL

TMP_RESULTS_BUCKET = os.environ['TMP_RESULTS_BUCKET']
TMP_RESULTS_FOLDER = os.environ['TMP_RESULTS_FOLDER']
CATALOG = os.environ['CATALOG']
SPLUNK_INGESTION_SUMMARY_TABLE = os.environ['SPLUNK_INGESTION_SUMMARY_TABLE']
S3_INGESTION_COUNT_TABLE = os.environ['S3_INGESTION_COUNT_TABLE']
STATISTICS_DATABASE = os.environ['STATISTICS_DATABASE']

logger = InsiderProtectionLogging(__name__, LOGGING_LEVEL).logger

athena = Athena(TMP_RESULTS_BUCKET, TMP_RESULTS_FOLDER)


def get_indexes_summary_by_location(date, location):
    logger.info(f"Getting the {location} indexes ingestion summary")
    query = (f"SELECT 'ai-2s33-wineventlog' AS idx, date, sum(cast(counter AS bigint))AS count "
             f"        FROM {SPLUNK_INGESTION_SUMMARY_TABLE}  "
             f"        WHERE date = '{date}' "
             f"        AND day = '{date}' "
             f"        AND location = '{location}'"
             f"        AND   summary_idx like '%wineventlog%' group by location, date "
             f"        UNION "
             f"        SELECT regexp_replace(summary_idx, '-summary', '') "
             f"        as idx, date, cast(counter as bigint) AS count "
             f"        FROM  {SPLUNK_INGESTION_SUMMARY_TABLE}  "
             f"        WHERE date = '{date}' "
             f"        AND day = '{date}' "
             f"        AND location ='{location}'"
             f"        AND  summary_idx  not like '%wineventlog%' ")

    indexes_summary = athena.select_data_as_json(CATALOG, STATISTICS_DATABASE, query)
    logger.info(f"Index summary for day {date}: {indexes_summary}")
    return indexes_summary


def get_index_nb_events_by_date(index, date):
    NO_RECORDS = 0
    query = (f"SELECT sum(cast(\"counter\" as int)) as count "
             f"FROM {S3_INGESTION_COUNT_TABLE} "
             f"WHERE idx = '{index}' "
             f"AND date = '{date}';")
    results = athena.select_data_as_json(CATALOG, STATISTICS_DATABASE, query)
    try:
        nb_events = results.pop()
    except AttributeError as ae:
        logger.error(f"No results for query {query}")
        return NO_RECORDS
    else:
        return nb_events[NB_EVENTS_FIELD]


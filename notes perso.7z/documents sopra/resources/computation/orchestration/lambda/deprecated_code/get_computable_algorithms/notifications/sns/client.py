import json
import boto3
import os
from custom_logging_2s33.insider_protection_logging import InsiderProtectionLogging
from general_configuration.config import LOGGING_LEVEL

THRESHOLD_ERROR_TOPIC_ARN =  os.environ['THRESHOLD_ERROR_TOPIC_ARN']

logger = InsiderProtectionLogging(__name__, LOGGING_LEVEL).logger
client = boto3.client('sns')


def notify_threshold_not_reached(index, date, rate,
                                 threshold, actual_index_nb_events,
                                 expected_index_nb_events):
    message = (f"Ingestion rate for index {index} the day {date} "
               f"is {rate} < {threshold}. "
               f"Expected {expected_index_nb_events} events, "
               f"ingested {actual_index_nb_events} events.")
    logger.warning(message)
    response = client.publish(
        TopicArn=THRESHOLD_ERROR_TOPIC_ARN,
        Message=json.dumps(message),
    )
    return response

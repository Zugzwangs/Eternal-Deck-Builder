from setuptools.namespaces import flatten
import boto3
from storage.datasource.athena import client as athena_client
from storage.configuration_db.dynamodb import adapter as dynamodb_adapter
from storage.configuration_db.dynamodb import client as dynamodb_client
from notifications.sns import client as sns_client
import json

from general_configuration.record_fields import DATE_FIELD, SPLUNK_LOCATION_FIELD, \
    INDEX_FIELD, NB_EVENTS_FIELD, IS_INGESTION_THRESHOLD_REACHED_FIELD, \
    ACTUAL_NB_EVENTS_S3_FIELD, EXPECTED_NB_EVENTS_S3_FIELD, INGESTION_RATE_FIELD, \
    MODE_FIELD, ALGORITHM_FIELD, EXCLUDE_ALREADY_EXECUTED_ALG, PREDICT_MODE
from general_configuration.config import LOGGING_LEVEL, INGESTION_THRESHOLD, \
    ALGORITHM_RUNNABLE_GET_LAMBDA
from custom_logging_2s33.insider_protection_logging import InsiderProtectionLogging

logger = InsiderProtectionLogging(__name__, LOGGING_LEVEL).logger


def lambda_handler(event, context):
    logger.info(f"Received the event {event}")
    sns_payload = event['Sns']
    location = sns_payload[SPLUNK_LOCATION_FIELD]
    date = sns_payload[DATE_FIELD]
    indexes_summary_list = event['ListIndex']['Payload']
    logger.info(f"Processing the indexes from {location}")

    # Adding information about the ingestion consistency in each index_summary row
    for summary in indexes_summary_list:
        logger.info(f"Processing the summary {summary}")
        index_name = summary[INDEX_FIELD]
        logger.info(f"Ingestion threshold set to {INGESTION_THRESHOLD}")
        logger.info(f"Calculating ingestion rate for index {index_name}")
        expected_index_nb_events = summary[NB_EVENTS_FIELD]
        logger.info(f"The expected number of events sent by the source is {expected_index_nb_events}")
        actual_index_nb_events = get_actual_number_of_events(summary)
        logger.info(f"The actual number of events save in S3 is {actual_index_nb_events}")
        summary[ACTUAL_NB_EVENTS_S3_FIELD] = actual_index_nb_events
        summary[EXPECTED_NB_EVENTS_S3_FIELD] = expected_index_nb_events
        ingestion_rate = get_ingestion_rate(actual_index_nb_events, expected_index_nb_events)
        logger.info(f"The ingestion rate for {index_name} is {ingestion_rate}")
        summary[INGESTION_RATE_FIELD] = ingestion_rate
        summary[IS_INGESTION_THRESHOLD_REACHED_FIELD] = is_ingestion_threshold_reached(ingestion_rate,
                                                                                       INGESTION_THRESHOLD)
        logger.info(f"Saving {summary} in {dynamodb_client.INGESTION_TABLE}")
        dynamodb_client.insert_index_details(summary)

    # Separating indexes that were properly ingested from the ones that didn't
    not_fully_ingested_indexes = filter(lambda s: not s[IS_INGESTION_THRESHOLD_REACHED_FIELD],
                                        indexes_summary_list)
    not_fully_ingested_indexes = list(not_fully_ingested_indexes)

    fully_ingested_indexes = filter(lambda s: s[IS_INGESTION_THRESHOLD_REACHED_FIELD],
                                    indexes_summary_list)
    fully_ingested_indexes = list(fully_ingested_indexes)

    # Notifyng to sns the non consistent indexes
    for index in not_fully_ingested_indexes:
        logger.info(f"Index {index} didn't reach the threshold {INGESTION_THRESHOLD}")
        sns_client.notify_threshold_not_reached(index[INDEX_FIELD], index[DATE_FIELD], index[INGESTION_RATE_FIELD],
                                                INGESTION_THRESHOLD, index[ACTUAL_NB_EVENTS_S3_FIELD],
                                                index[EXPECTED_NB_EVENTS_S3_FIELD])

    # Update the algorithm table with the indexes that were ingested
    final_runnable_algorithms = set()
    for index in fully_ingested_indexes:
        dynamodb_adapter.update_algorithm_index_as_ingested(index)
        ready_algorithms_by_index = dynamodb_adapter.get_ready_algorithm_by_index_and_date(index[INDEX_FIELD],
                                                                                                 date)

        logger.info(f"Updated index {index} status in {dynamodb_client.ALGORITHM_TABLE} for date {date}.")
        logger.info(f"List of algorithms ready to be deployed: {ready_algorithms_by_index}")

        if EXCLUDE_ALREADY_EXECUTED_ALG in sns_payload:
            exclude_already_executed_algs = sns_payload[EXCLUDE_ALREADY_EXECUTED_ALG]
        else:
            exclude_already_executed_algss = True

        if exclude_already_executed_algs:
            logger.info(f"Excluding the algorithms that were already executed.")
            ready_algorithms_by_index = set(filter(lambda algorithm: is_algorithm_runnable(algorithm,
                                                                                              date,
                                                                                              PREDICT_MODE),
                                                      ready_algorithms_by_index))
        logger.info(f"Updated index {index} status in {dynamodb_client.ALGORITHM_TABLE} for date {date}.")
        logger.info(f"Filtered set of algorithms to be deployed: {ready_algorithms_by_index}")
        final_runnable_algorithms = final_runnable_algorithms.union(ready_algorithms_by_index)
    logger.info(f"Final set of algorithms to be deployed is {final_runnable_algorithms}")
    final_runnable_algorithms = map(lambda algo: {ALGORITHM_FIELD: algo, DATE_FIELD: date, MODE_FIELD: PREDICT_MODE},
                                    final_runnable_algorithms)
    return list(final_runnable_algorithms)


def get_actual_number_of_events(index_summary):
    canonical_idx, date = (index_summary[INDEX_FIELD], index_summary[DATE_FIELD])
    idx = dynamodb_adapter.get_index_by_canonical_name(canonical_idx)
    logger.info(f"Getting the actual number of ingested events for {canonical_idx}")
    actual_index_nb_events = athena_client.get_index_nb_events_by_date(idx, date)
    logger.info(f"The ACTUAL number of record ingested for index "
                f"{canonical_idx} is {actual_index_nb_events}")
    return actual_index_nb_events


def is_ingestion_threshold_reached(ingestion_rate, ingestion_threshold):
    return ingestion_rate > float(ingestion_threshold)


def get_ingestion_rate(actual_number, expected_number):
    return 1 - ((expected_number - actual_number) / expected_number)


def is_algorithm_runnable(algorithm, date, mode):
    lambda_client = boto3.client('lambda')
    is_runnable_payload = {
        ALGORITHM_FIELD: algorithm,
        DATE_FIELD: date,
        MODE_FIELD: mode
    }

    logger.info(f"Checking if the algorithm {algorithm} is runnable")
    response_streaming_obj = lambda_client.invoke(
        FunctionName=ALGORITHM_RUNNABLE_GET_LAMBDA,
        InvocationType='RequestResponse',
        Payload=json.dumps(is_runnable_payload, indent=2).encode('utf-8')
    )

    response_payload = response_streaming_obj['Payload'].read().decode("utf-8")
    logger.info(f"is_runnable response: {response_payload}")

    # Convert string response to boolean
    return eval(response_payload.title())

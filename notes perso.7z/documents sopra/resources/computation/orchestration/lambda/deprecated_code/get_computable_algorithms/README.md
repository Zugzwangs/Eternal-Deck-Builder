*********************************************************************************************************************************************************************************
                                     MANAGE COMPUTING FLEET CONFIGURATION FOR USE CASES
*********************************************************************************************************************************************************************************



**Functional tests:**

*********
* INPUT *
*********

The value of "exclude-already-executed-alg" is taken into account 
Expected Input:

    {
    "Sns": {
    "date": "2022-03-01",
    "location": "AWS",
    "exclude-already-executed-alg": true
    },
    "ListIndex": {
    "ExecutedVersion": "$LATEST",
    "Payload": [
      {
        "idx": "ai-2s33-wineventlog",
        "date": "2022-03-01",
        "count": 22522456
      },
      {
        "idx": "ai-2s33-gate-f5-apm",
        "date": "2022-03-01",
        "count": 10907
      },
      {
        "idx": "ai-2s33-netskope-events",
        "date": "2022-03-01",
        "count": 19645522
      }
    ],
    "SdkHttpMetadata": {
      "AllHttpHeaders": {
        "X-Amz-Executed-Version": [
          "$LATEST"
        ],
        "x-amzn-Remapped-Content-Length": [
          "0"
        ],
        "Connection": [
          "keep-alive"
        ],
        "x-amzn-RequestId": [
          "4afa3848-ba4c-4b40-acaa-34516b16e974"
        ],
        "Content-Length": [
          "220"
        ],
        "Date": [
          "Wed, 09 Mar 2022 08:21:32 GMT"
        ],
        "X-Amzn-Trace-Id": [
          "root=1-62286377-53bde01863f7a7d6032e0b4a;sampled=0"
        ],
        "Content-Type": [
          "application/json"
        ]
      },
      "HttpHeaders": {
        "Connection": "keep-alive",
        "Content-Length": "220",
        "Content-Type": "application/json",
        "Date": "Wed, 09 Mar 2022 08:21:32 GMT",
        "X-Amz-Executed-Version": "$LATEST",
        "x-amzn-Remapped-Content-Length": "0",
        "x-amzn-RequestId": "4afa3848-ba4c-4b40-acaa-34516b16e974",
        "X-Amzn-Trace-Id": "root=1-62286377-53bde01863f7a7d6032e0b4a;sampled=0"
      },
      "HttpStatusCode": 200
    },
    "SdkResponseMetadata": {
      "RequestId": "4afa3848-ba4c-4b40-acaa-34516b16e974"
    },
    "StatusCode": 200
    }
    }
    
**********
* OUTPUT *
**********

Output sample for successfull ingestion

    { 
      "date": "2022-03-01",
      "algorithm": "ac_30_2s33",
      "mode": "predict"
    }



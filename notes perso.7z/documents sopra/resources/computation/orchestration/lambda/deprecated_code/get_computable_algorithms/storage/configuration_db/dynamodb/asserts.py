def request_error(error):
    return f"Failed dynamodb operation. Error: {error}."


def parsing_error(error):
    return f"Failed when parsing data from dynamodb. Error: {error}"

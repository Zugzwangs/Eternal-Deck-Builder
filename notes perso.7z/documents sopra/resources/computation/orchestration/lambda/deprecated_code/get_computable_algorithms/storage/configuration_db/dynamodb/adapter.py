from custom_logging_2s33.insider_protection_logging import InsiderProtectionLogging
import os
from storage.configuration_db.dynamodb import client as dynamodb_client
from storage.configuration_db.dynamodb.asserts import parsing_error
from general_configuration.record_fields import CANONICAL_NAME_FIELD, \
    INDEX_FIELD, DATE_FIELD, ALGORITHM_FIELD, ANOMALY_CASE_FIELD
from general_configuration.config import LOGGING_LEVEL

INIT_DATE = os.environ['INIT_DATE']
logger = InsiderProtectionLogging(__name__, LOGGING_LEVEL).logger


def get_index_canonical_name(index):
    try:
        r = dynamodb_client.get_index_canonical_name(index)
        cn = r.pop()[CANONICAL_NAME_FIELD]
        return cn
    except Exception as e:
        logger.error(parsing_error(e))
        raise e


def get_index_by_canonical_name(canonical_index):
    try:
        r = dynamodb_client.get_index_by_canonical_name(canonical_index)
        cn = r.pop()[INDEX_FIELD]
        return cn
    except Exception as e:
        logger.error(parsing_error(e))
        raise e


def get_ready_algorithm_by_index_and_date(canonical_idx, date):
    algorithms = dynamodb_client.get_algorithm_by_index_and_date(canonical_idx,
                                                                       date)
    return set([alg[ANOMALY_CASE_FIELD] for alg in algorithms
                if is_algorithm_fully_ingested(alg)])


def is_algorithm_fully_ingested(algorithm_record):
    algorithm = algorithm_record[ANOMALY_CASE_FIELD]
    date = algorithm_record[DATE_FIELD]
    try:
        required_indexes = sorted(dynamodb_client.get_algorithm_indexes(algorithm,
                                                                           INIT_DATE))
        actual_indexes = sorted(dynamodb_client.get_algorithm_indexes(algorithm,
                                                                         date))
        return actual_indexes == required_indexes
    except Exception as e:
        logger.error(parsing_error(e))
        raise e


def update_algorithm_index_as_ingested(index_record):
    canonical_idx, date = (index_record[INDEX_FIELD], index_record[DATE_FIELD])
    algorithms = dynamodb_client.get_algorithm_by_index_and_date(canonical_idx,
                                                                       INIT_DATE)
    try:
        r = [dynamodb_client.update_index_status(algorithm[ANOMALY_CASE_FIELD],
                                                 canonical_idx,
                                                 str(True), date)
             for algorithm in algorithms]
        return r
    except Exception as e:
        logger.error(parsing_error(e))
        raise e

import boto3
import os
from boto3.dynamodb.conditions import Key
from custom_logging_2s33.insider_protection_logging import InsiderProtectionLogging
from decimal import Decimal
from storage.configuration_db.dynamodb.asserts import request_error
from general_configuration.record_fields import ALGORITHM_FIELD, ANOMALY_CASE_FIELD, DATE_FIELD, \
    CANONICAL_NAME_FIELD, INDEX_FIELD
from general_configuration.config import LOGGING_LEVEL

INDEX_CONFIGURATION_TABLE = os.environ['INDEX_CONFIGURATION_TABLE']
ALGORITHM_TABLE = os.environ['ALGORITHM_TABLE']
INGESTION_TABLE = os.environ['INGESTION_TABLE']
INGESTION_FAILED_TOPIC = os.environ['INGESTION_FAILED_TOPIC']

logger = InsiderProtectionLogging(__name__, LOGGING_LEVEL).logger
dynamodb_url = 'https://dynamodb.eu-west-1.amazonaws.com'
client = boto3.resource('dynamodb', endpoint_url=dynamodb_url)


def get_algorithm_indexes(algorithm, date):
    try:
        table = client.Table(ALGORITHM_TABLE)
        item = table.get_item(
            Key={
                ANOMALY_CASE_FIELD: algorithm,
                DATE_FIELD: date
            },
            ConsistentRead=True
        )['Item']
        idxes = list(item.keys())
        idxes.remove(ANOMALY_CASE_FIELD)
        idxes.remove(DATE_FIELD)
        response = idxes
    except Exception as e:
        logger.error(request_error(e))
        raise e
    else:
        return response


def get_algorithm(algorithm, date):
    try:
        table = client.Table(ALGORITHM_TABLE)
        response = table.get_item(Key={ANOMALY_CASE_FIELD: algorithm,
                                       DATE_FIELD: date})
        item = response['Item']
    except Exception as e:
        logger.error(request_error(e))
        raise e
    else:
        return item


def get_algorithm_by_index_and_date(canonical_index, date):
    try:
        table = client.Table(ALGORITHM_TABLE)
        response = table.scan(
            FilterExpression='attribute_exists(#idx) and #date=:init_date',
            ExpressionAttributeNames={
                "#date": DATE_FIELD,
                "#idx": canonical_index
            },
            ExpressionAttributeValues={
                ':init_date': date
            },
            ConsistentRead=True
        )
        items = response['Items']
        logger.info(items)
    except Exception as e:
        logger.error(request_error(e))
        raise e
    else:
        return items


def get_index_details(canonical_index, date):
    try:
        table = client.Table(INGESTION_TABLE)
        response = table.get_item(Key={INDEX_FIELD: canonical_index,
                                       DATE_FIELD: date})
        item = response['Item']
    except Exception as e:
        logger.error("Failed dynamodb operation. Error: {}."
                     .format(e))
        raise e
    else:
        return item


def get_index_by_canonical_name(canonical_index):
    try:
        table = client.Table(INDEX_CONFIGURATION_TABLE)
        response = table.scan(
            ProjectionExpression='#idx',
            ExpressionAttributeNames={
                "#cn_idx": CANONICAL_NAME_FIELD,
                "#idx": INDEX_FIELD
            },
            ExpressionAttributeValues={
                ':cn_idx': canonical_index
            },
            FilterExpression='#cn_idx=:cn_idx'
        )
        item = response['Items']
    except Exception as e:
        logger.error(request_error(e))
        raise e
    else:
        return item


def get_index_canonical_name(index):
    try:
        table = client.Table(INDEX_CONFIGURATION_TABLE)
        response = table.query(
            KeyConditionExpression=Key(INDEX_FIELD).eq(index),
            ProjectionExpression='canonical_name'
        )
        items = response['Items']
    except Exception as e:
        logger.error(request_error(e))
        raise e
    else:
        return items


def insert_index_details(index_record):
    canonical_idx, date = (index_record[INDEX_FIELD], index_record[DATE_FIELD])
    # index_record = {'idx': 'ai-2s33-netskope-events', 'date': '2021-11-10', 'count': 17616972, 'is_ingestion_threshold_reached': False, 's3_count': 3639242, 'splunk_ingested_events_count': 17616972, 'ingestion_rate': 0.2065759087316481}
    for key, value in index_record.items():
        if isinstance(index_record[key], float):
            index_record[key] = Decimal(str(value))
    try:
        table = client.Table(INGESTION_TABLE)
        response = table.put_item(
            Item=index_record
        )
    except Exception as e:
        logger.error(request_error(e))
        raise e
    return response


def update_index_status(algorithm, canonical_index, status, date):
    try:
        logger.info(f"Updating algorithm {algorithm}, index "
                    f"{canonical_index} status in {ALGORITHM_TABLE}")
        table = client.Table(ALGORITHM_TABLE)
        response = table.update_item(
            Key={
                ANOMALY_CASE_FIELD: algorithm,
                DATE_FIELD: date
            },
            UpdateExpression="set #idx=:s",
            ExpressionAttributeNames={
                "#idx": canonical_index
            },
            ExpressionAttributeValues={
                ':s': status
            },
            ReturnValues="UPDATED_NEW"
        )
    except Exception as e:
        logger.error(request_error(e))
        raise e
    else:
        return response

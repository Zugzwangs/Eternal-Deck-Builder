import time
from custom_logging_2s33.insider_protection_logging import InsiderProtectionLogging

from storage.datasource.athena import client as athena_client

logger = InsiderProtectionLogging(__name__, 'DEBUG').logger


def get_index_stable_nb_events_by_date(idx, date, previous_iteration_value=0):
    actual_value = athena_client.get_index_nb_events_by_date(idx, date)
    if not actual_value:
        logger.error(f"No record count found for day {date} in {idx} ")
        return None
    logger.info(f"Number of events in previous iteration was {previous_iteration_value}. "
                f"Number of events in the actual iteration is {actual_value}.")
    if previous_iteration_value == actual_value:
        logger.info(f"The stable number of records for {idx} is {actual_value}")
        return actual_value
    else:
        sleeping_time = 3
        logger.info(f"Wating {sleeping_time} seconds to query again until "
                    "number of records remains stable.")
        time.sleep(sleeping_time)
        return get_index_stable_nb_events_by_date(idx, date, actual_value)
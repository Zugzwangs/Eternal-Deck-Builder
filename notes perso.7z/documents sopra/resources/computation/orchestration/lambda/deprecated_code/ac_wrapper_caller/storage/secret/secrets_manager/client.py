#!/usr/bin/env python
# -*- coding: utf-8 -*-
import boto3
import json
import base64
import os
from botocore.exceptions import ClientError
from custom_logging_2s33.insider_protection_logging import InsiderProtectionLogging


REGION = os.environ['REGION']
LOGGING_LEVEL = os.environ['LOGGING_LEVEL']
logger = InsiderProtectionLogging(__name__, LOGGING_LEVEL).logger

# Create a Secrets Manager client
session = boto3.session.Session()
client = session.client(service_name='secretsmanager', region_name= REGION)

def get_secret(secret_name, secret_index):
    secret = ''
    try:
        logger.info('Fetching secret ...')
        get_secret_value_response = client.get_secret_value(SecretId=secret_name)

    except ClientError as e:
        logger.error('error when fetching AC web service secret token')
        if e.response['Error']['Code'] == 'DecryptionFailureException':
            logger.error("Secrets Manager can't decrypt the protected secret text using the provided KMS key.")
        elif e.response['Error']['Code'] == 'InternalServiceErrorException':
            logger.error("An error occurred on the server side.")
        elif e.response['Error']['Code'] == 'InvalidParameterException':
            logger.error("You provided an invalid value for a parameter.")
        elif e.response['Error']['Code'] == 'InvalidRequestException':
            logger.error("You provided a parameter value that is not valid for the current state of the resource.")
        elif e.response['Error']['Code'] == 'ResourceNotFoundException':
            logger.error("We can't find the resource that you asked for.")
        # throw back the error to the caller
        raise e
    else:
        # Depending on whether the secret is a string or binary, one of these fields will be populated.
        if 'SecretString' in get_secret_value_response:
            logger.info('Found that secret type is a string')
            secret = get_secret_value_response['SecretString']
        else:
            logger.info('Found that secret type is binary')
            secret = base64.b64decode(get_secret_value_response['SecretBinary'])

    # return secret ready to use
    webservice_token = json.loads(secret)  # this function return a dict into a string type variable
    # logger.debug('webservice_token: ' + json.dumps(webservice_token, indent=2))
    return (webservice_token[secret_index])
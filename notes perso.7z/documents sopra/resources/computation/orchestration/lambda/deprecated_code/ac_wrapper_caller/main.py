import json
import traceback
import os
import boto3
import cfnresponse
from storage.secret.secrets_manager import client as secrets_manager_client
from wrapper_call import Wrapper_caller


from custom_logging_2s33.insider_protection_logging import InsiderProtectionLogging

SECRET_NAME = os.environ['SECRET_NAME']
SECRET_INDEX = os.environ['SECRET_INDEX']
LOGGING_LEVEL = os.environ['LOGGING_LEVEL']
ALB_URL = os.environ['ALB_URL']
logger = InsiderProtectionLogging(__name__, LOGGING_LEVEL).logger

elb_client = boto3.client('elbv2')


def lambda_handler(event, context):
    logger.info(f'event : {event}')
    """
    input: event = {'RequestType': 'Create', 
                    'ResponseURL': 'https://cloudformation-custom-resource-response-euwest1.s3-eu-west-1.amazonaws.com/arn%3Aaws%3Acloudformation%3Aeu-west-1%3A309711267128%3Astack/braincell-ac242s33-predict-20122021-115203-6/40179b00-618b-11ec-913c-06e332f7e003%7CInvokeLambda%7C688026cf-2d40-4b5e-bcba-6320c03ebb00?X-Amz-Algorithm=AWS4-HMAC-SHA256&X-Amz-Date=20211220T115733Z&X-Amz-SignedHeaders=host&X-Amz-Expires=7200&X-Amz-Credential=AKIAU7SEXKRMWBMKQYHQ%2F20211220%2Feu-west-1%2Fs3%2Faws4_request&X-Amz-Signature=e524ab02bc0f8a07f5062e14eeccaf67fd5ec6f6ca945439ea811847b80f3f25', 
                    'StackId': 'arn:aws:cloudformation:eu-west-1:309711267128:stack/braincell-ac242s33-predict-20122021-115203-6/40179b00-618b-11ec-913c-06e332f7e003', 
                    'RequestId': '688026cf-2d40-4b5e-bcba-6320c03ebb00', 
                    'LogicalResourceId': 'InvokeLambda', 
                    'ResourceProperties': {'ServiceToken': 'arn:aws:lambda:eu-west-1:309711267128:function:ac_wrapper', 
                                            'ComputationDate': '2021-12-01', 
                                            'Mode': 'predict', 
                                            'Algorithm': 'ac_24_2s33', 
                                            'ExecutionID': '20122021-115203-6'}}
    output: {'statusCode': 200, 'Response Body': {}}

    This Lambda is triggered by the custom resource in cloud formation after the ec2 instance is created.
    It will run the ac wrapper for the algorithm calculation.

    Main steps:
        1) check if it's a creation event
        2) register instance to right alb target group
        3) API call to the web service wrapper and AC code run

    note: VpcId is not required to be set in dynamoDB recipe as the lambda will perform introspection to retrieve the value at run time
    """

    ######################
    ### initialization ###
    ######################

    message = "failed"  # temporary output to be replaced by the response
    response = {}
    current_mode = event['ResourceProperties']['Mode']
    uc_name = event['ResourceProperties']['Algorithm']
    computation_date = event['ResourceProperties']['ComputationDate'] #"2021-12-13"
    execution_id = event['ResourceProperties']['ExecutionID']
    loadbalancer_url = f"https://{ALB_URL}:443/run"
    instance_id = event['ResourceProperties']['InstanceID']
    instance_ip = event['ResourceProperties']['InstanceIP']


    try:
        logger.info('**************************')
        logger.info("Step 1: Initialization ...")
        logger.info('**************************')
        logger.info(f"Resource properties from the event are: {json.dumps(event['ResourceProperties'], indent=4)}")
        responseStatus = cfnresponse.SUCCESS
        responseData = {}
        if event['RequestType'] == 'Delete':
            return cfnresponse.send(event, context, responseStatus, responseData)


        logger.info('*************************************************')
        logger.info("Step 2: Instance registry to alb target group ...")
        logger.info('*************************************************')

        target_group_name = get_target_group_name(uc_name, current_mode)
        logger.info(f"target_group_name is: {target_group_name}")
        registry_instance_to_target_group(instance_id, target_group_name)
        logger.info(f"the instance {instance_id} has been registered to target group {target_group_name}")



        logger.info('***************************************')
        logger.info("Step 3: REST call to the wrapper ...")
        logger.info('***************************************')
        # Fetching the secret for the web service token used in the REST call to the wrapper
        logger.info('Determination of the web services token...')
        web_service_token = secrets_manager_client.get_secret(SECRET_NAME,SECRET_INDEX)
        # logger.debug('=> webServiceToken: ' + webServiceToken)

        logger.debug(f"The LoadBalancer URL is : {loadbalancer_url}")

        # Instantiation of a Wrapper_caller
        wrapper_caller = Wrapper_caller(current_mode,
                                        uc_name,
                                        computation_date,
                                        web_service_token,
                                        execution_id,
                                        loadbalancer_url)

        response = wrapper_caller.make_wrapper_call()
        return response
    except Exception:
        responseStatus = cfnresponse.FAILED
        error = traceback.format_exc()
        message = f"Unexpected error occured during web service wrapper API call: {error}"
        logger.error(message)
        raise Exception(message)

    finally:
        return cfnresponse.send(event, context, responseStatus, responseData)



def get_target_group_name(algorithm, mode):
    splited_algorithm = algorithm.split('_')
    alphanumeric_algorithm = ''.join(splited_algorithm)
    return alphanumeric_algorithm + mode



def get_target_group_arn_by_name(target_group_name: str):
    TARGET_GROUPS_LIST_KEY = 'TargetGroups'
    TARGET_GROUP_ARN_KEY = 'TargetGroupArn'
    target_groups = elb_client.describe_target_groups(
        Names=[
            target_group_name
        ]
    )[TARGET_GROUPS_LIST_KEY]
    target_group = target_groups.pop()
    return target_group[TARGET_GROUP_ARN_KEY]


def registry_instance_to_target_group(instance_id: str, target_group_name: str):
    target_group_arn = get_target_group_arn_by_name(target_group_name)
    elb_client.register_targets(
        TargetGroupArn=target_group_arn,
        Targets=[
            {
                'Id': instance_id,
                'Port': 80
            }
        ]
    )

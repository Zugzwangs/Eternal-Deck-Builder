#!/usr/bin/env python
# -*- coding: utf-8 -*-
import os
import json
import datetime
import traceback
import time
import boto3
import requests
from custom_logging_2s33.insider_protection_logging import InsiderProtectionLogging

LOGGING_LEVEL = os.environ['LOGGING_LEVEL']

logger = InsiderProtectionLogging(__name__, LOGGING_LEVEL).logger

cf_client = boto3.client('cloudformation')
lambda_client = boto3.client('lambda')


class Wrapper_caller:
    """
    Class with specific methods to handle the braincell wrapper REST call
    """

    def __init__(self, mode, alg_name, computation_date, web_service_token, execution_id, loadbalancer_url):
        """
        :param mode: calculation mode fit, predict, fit_predict as str
        :param alg_name: algorithm name as str
        :param computation_date: date as str, format YYYY-MM-DD
        :param web_service_token: token as str used in the REST call to the wrapper
        :param execution_id: execution_id as str used in the REST call header to the wrapper
        """
        self.alg_name = alg_name
        self.mode = mode
        self.computation_date = computation_date
        self.web_service_token = web_service_token
        self.execution_id = execution_id
        self.loadbalancer_url = loadbalancer_url

    def make_wrapper_call(self):
        """
        :return: html response
        """
        payload = self.define_call_payload()
        headers = self.define_call_headers()

        # WAIT BEFORE SENDING REQUESTS TO BE SURE ALB REDIRECTION IS ONLINE
        logger.info("Waiting 20s before sending the request to be sure that the elb redirection is online ...")
        time.sleep(20)
        logger.info("Wait is over")

        try:
            # make POST call:
            logger.info(f'Call algorithm {self.alg_name} web service')
            response = requests.post(self.loadbalancer_url, headers=headers, json=payload, verify=False)
            # logger.debug('request headers ' + json.dumps(response.request.headers, separators=(',', ':')))
            logger.info(f'status code {response.status_code}')
            logger.debug(f'response body: {response.text}')
            if response.status_code == 200:
                logger.info('Success!')
            elif response.status_code == 400:
                logger.error('Bad Request - The supplied date are incorrect.')
            elif response.status_code == 401:
                logger.error('Unauthorized Access - The supplied secret token is invalid for the requested operation..')
            elif response.status_code == 404:
                logger.error('Not Found - The supplied Algorithm header value is not a recognised algorithm.')
            elif response.status_code == 500:
                logger.error('Internal Error - The algorithm computation terminated abnormally.')
            elif response.status_code == 503:
                logger.error('Service UNAVAILABLE - Algorithm already started.')
            else:
                logger.error('Unnexpected web service answer')

        except:
            error = traceback.format_exc()
            message = f"Unexpected error occured when calling computing end point API: {error}"
            logger.error(message)
            raise Exception(message)

        else:
            return response.json()

    def define_call_payload(self):
        """
        :return: payload as dict
        """
        try:
            # Call the execution-recipe-service API
            logger.info("Preparation of API call payload parameters ...")
            logger.info('Fetching recipe settings from execution-recipe-service ...')
            recipe_settings_request = {
                "algorithm": self.alg_name,
                "mode": self.mode,
                "date": self.computation_date  # Pass a date param - will get dynamically updated settings
            }
            response_streaming_obj = lambda_client.invoke(
                FunctionName='execution-recipe-settings-get-route',
                InvocationType='RequestResponse',
                Payload=json.dumps(recipe_settings_request, indent=2).encode('utf-8')
            )
            response_payload = response_streaming_obj['Payload'].read().decode("utf-8")
            logger.info(f"recipe_settings_response: {response_payload}")

            alg_execution_settings = json.loads(response_payload)

        except Exception:
            error = traceback.format_exc()
            message = f"Unexpected error during fetch of ac settings from execution-recipe-service"
            logger.error(message)
            raise Exception(message)

        try:
            
            logger.info("Determination of date_f and date_0 ...")
            date_format = "%Y-%m-%d"
            computation_date = datetime.datetime.strptime(self.computation_date[0:10], date_format)
        except Exception:
            error = traceback.format_exc()
            message = f"Unexpected error occured during computation date parsing. Format must be YYYY-MM-DD. Value passed is {self.computation_date}: {error}"
            logger.error(message)
            raise ValueError(message)

        ### PREDICT EXECUTION ###
        if self.mode == 'predict':
            d0 = df = computation_date
            
        ### FIT EXECUTION ###
        elif self.mode == 'fit':
            try:
                train_window = datetime.timedelta(days= int(alg_execution_settings["min_train_window"]))
                lag_days= datetime.timedelta(days=int(alg_execution_settings["lag"]))
            except KeyError:
                message = f"Parameter <<min_train_window>> is missing from execution-recipe-service response"
                logger.error(message)
                raise Exception(message)
            except ValueError:
                message = f"Incorrect parameter min_train_window. It must be an integer > 0. The value passed is : {alg_execution_settings['min_train_window']}"
                logger.error(message)
                raise Exception(message)

            if train_window > datetime.timedelta(days=0):
                pass
            else:
                message = f"Incorrect parameter train_window. It must be an integer > 0. The value passed is : {alg_execution_settings['min_train_window']}"
                logger.error(message)
                raise ValueError(message)

            #mergedelta = datetime.timedelta(days=-train_window)
            df = computation_date - lag_days
            d0 = df - train_window 
            
            # removed <<train_window>> and lag since dont have to be passed to the payload of the post request
            del alg_execution_settings["min_train_window"]  
            del alg_execution_settings["lag"]

        ### INCORRECT MODE EXECUTION ###
        else:
            message = f"Incorrect calculation mode passed {self.mode}. It must be in {'fit', 'predict'}. Lambda execution aborted"
            logger.error(message)
            raise ValueError(message)

        date_f, time_f = str(df).split(' ')
        date_0, time_0 = str(d0).split(' ')

        logger.info(f"date_f is {date_f}")
        logger.info(f"date_0 is {date_0}")

        # compose the POST with settings contains in 'ac_execution_settings' and date/mode parameters:
        payload = {"date_0": date_0, "date_f": date_f, "fit_predict_mode": self.mode}
                
        payload.update(alg_execution_settings)
        logger.debug('Payload is ' + json.dumps(payload, separators=(',', ':')))

        return payload

    def define_call_headers(self):
        """
        :return: headers as dict
        """
        logger.info("Preparation of API call headers parameters ...")
        headers = {'AnomalyCase': self.alg_name,
                   'executionID': self.execution_id,
                   'Mode': self.mode,
                   'Authorization': 'Bearer ' + self.web_service_token}
        logger.debug('Headers are ' + json.dumps(headers, separators=(',', ':')))

        return headers


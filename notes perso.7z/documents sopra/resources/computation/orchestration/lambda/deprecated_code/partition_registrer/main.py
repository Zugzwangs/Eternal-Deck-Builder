import json
import traceback
import os
import boto3
import urllib.parse
import logging as logger
from datetime import datetime
from custom_logging_2s33.insider_protection_logging import InsiderProtectionLogging
import io
import time

client = boto3.client('athena')
s3 = boto3.client('s3')
s3_resource = boto3.resource('s3')
LOGGING_LEVEL = os.environ['LOGGING_LEVEL']
ATHENA_OUTPUT_BUCKET = os.environ['ATHENA_OUTPUT_BUCKET']
logger = InsiderProtectionLogging(__name__, LOGGING_LEVEL).logger
CATALOG = os.environ['CATALOG']
log_filename = 'athena_queries'
prefix = 'update_athena_partition'

def prepare_partitions(unique_partitions, db_table):
    authorized_keys = db_table.keys()
    formated_partitions = dict()
    for partition in unique_partitions:
        prefix = partition.split('/')[0]
        if prefix in authorized_keys:
            database = db_table[prefix]['database_name']
            if prefix == 'parquetfiles':
                table = partition.split('/')[1]
            else:
                table = db_table[prefix]['table_name']
            database_table = database + "." + table

            ## get partitions from key ##
            path_elements = partition.split('/')
            s = "("
            for elem in path_elements:
                if "=" in elem:
                    partition_key = elem.split('=')[0]
                    partition_value = elem.split('=')[1]
                    s+= f"{partition_key} = '{partition_value}', "
            # remove the ', ' form the end of the string
            s = s[:-2]
            s+= ")"
            if database_table not in formated_partitions:
                formated_partitions[database_table] = [s]
            else:
                formated_partitions[database_table].append(s)

    return formated_partitions


def load_partitions(formated_partitions):
    query_list = []
    for key, value in formated_partitions.items():
        query_base = "ALTER TABLE " + key + " ADD IF NOT EXISTS "
        for elem in value:
         query_base += f"PARTITION {elem}"
        query_list.append(query_base)

    print(query_list)
    output = f's3://{ATHENA_OUTPUT_BUCKET}/alter_tables'
    try:
        for query in query_list:
            logger.info(f'query : {query}')
            database = query.split('.')[0][len('ALTER TABLE '):]
            response = client.start_query_execution(
                QueryString=query,
                QueryExecutionContext={
                    'Database': database,
                    'Catalog': CATALOG
                },
                ResultConfiguration={
                    'OutputLocation': output,
                },
                WorkGroup='primary'
            )
            logger.info(f'response : {response}')
    except Exception as e:
        logger.info(f'Error : {e}')
        return query_list
    return query_list

def update_log_file(query_list, error=False):
    date = datetime.today().strftime('%Y-%m-%d')
    try:
        if error:
            object = s3_resource.Object(ATHENA_OUTPUT_BUCKET, f'{prefix}/date={date}/error/{log_filename}')
        else:
            object = s3_resource.Object(ATHENA_OUTPUT_BUCKET, f'{prefix}/date={date}/{log_filename}')
        response = object.get()
        contents = response['Body'].read()
        logger.info(f'content : {contents.decode("utf-8")}')
        contents = contents.decode("utf-8")
        existing_queries = contents.split('\n')
        new_queries = existing_queries + query_list
        new_queries = set(new_queries)
        body = "\n".join([elem for elem in new_queries])
        result = object.put(Body=body)
    except Exception as e:
        # First time writing log file
        logger.info(f'message error : {e}')
        if error:
            object = s3_resource.Object(ATHENA_OUTPUT_BUCKET, f'{prefix}/date={date}/error/{log_filename}')
        else:
            object = s3_resource.Object(ATHENA_OUTPUT_BUCKET, f'{prefix}/date={date}/{log_filename}')
        body = "\n".join([elem for elem in query_list])
        logger.info(f'body : {body}')
        result = object.put(Body=body)
        pass

def lambda_handler(event, context):
    logger.info(f'event : {event}')
    # wait one second to prevent too many requests on athena
    time.sleep(1)
    ## SAVE NEW PARTITIONS #
    new_partitions = []
    for record in event['Records']:
        j_record = json.loads(record['body'])
        if j_record.get('Records'):
            body = j_record['Records'][0]
            key = urllib.parse.unquote_plus(body['s3']['object']['key'])
            logger.info(f'key : {key}')
            new_partitions.append("/".join(key.split('/')[:-1]))

    unique_partitions = set(new_partitions)


    ## UPDATE PARTITIONS ##
    db_table = {'s3_ingestion_count':
                    {'database_name' : 'consistency_statistics',
                     'table_name' : 's3_ingestion_count'},
                'splunk_ingestion_summary':
                    {'database_name' : 'consistency_statistics',
                     'table_name' : 'splunk_ingestion_summary'},
                'parquetfiles':
                    {'database_name': 'splunk_raw_indexes',
                     'table_name': 'idx_xx'}}

    # get partitions prefix
    formated_partitions = prepare_partitions(unique_partitions, db_table)
    print(formated_partitions)
    try:
        query_list = load_partitions(formated_partitions)
        update_log_file(query_list)
    except Exception as e:
        logger.info(f'Error : {e}')
        update_log_file(query_list, error=True)

    return 0


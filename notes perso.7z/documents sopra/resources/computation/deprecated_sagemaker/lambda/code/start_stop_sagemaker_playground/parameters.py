LOG_LEVEL = 'INFO'
EXECUTION_NIGHT_FUNCTION_NAME = 'stop_sm_notebook_instances_by_criterias'
EXECUTION_CRON_FUNCTION_NAME = 'stop_sm_notebook_instances_by_cron'

"""
Define here the regex pattern to target the instance to not stop.
If you don't know regex pattern, please refer to the W3C documentation:
https://www.w3schools.com/python/python_regex.asp
"""
PATTERN = r''

"""
Define here the instance names to not stop.
It must be a list of strings, for instance: ['name1', 'name2', 'name3']
"""
INSTANCES_EXCEPTION = []

TAGS = {
    'start': "2s33:sm:scheduling:autostartcron",
    'stop': "2s33:sm:scheduling:autostopcron"
}
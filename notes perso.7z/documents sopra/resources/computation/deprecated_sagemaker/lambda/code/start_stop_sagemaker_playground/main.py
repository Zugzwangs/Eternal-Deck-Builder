import json
import re
import datetime

import boto3
import croniter

from custom_logging_2s33.insider_protection_logging import InsiderProtectionLogging
from parameters import PATTERN, INSTANCES_EXCEPTION, LOG_LEVEL, EXECUTION_CRON_FUNCTION_NAME, \
    EXECUTION_NIGHT_FUNCTION_NAME, TAGS

logger = InsiderProtectionLogging(__name__, LOG_LEVEL).logger
lambda_client = boto3.client('lambda')
sm = boto3.client('sagemaker')
exceptions = [''] if INSTANCES_EXCEPTION and len(INSTANCES_EXCEPTION) > 0 else INSTANCES_EXCEPTION
regex = r'.*' if PATTERN == '' else PATTERN


def get_notebook_instances_in_service():
    return sm.list_notebook_instances(StatusEquals='InService')

def get_notebook_instances_stopped():
    return sm.list_notebook_instances(StatusEquals='Stopped')


"""
Stop a notebook instance with its name.
For instance, if 'notebook_instance_name' variable is equal to 'my-instance',
it will stop the notebook instance with the name 'notebook_instance_name'.
If no instance has for name 'my-instance', it will print an error
"""


def stop_sm_notebook_instance(notebook_instance_name):
    try:
        sm.stop_notebook_instance(NotebookInstanceName=notebook_instance_name)
        print(f"{notebook_instance_name} has been stopped")
    except Exception as e:
        print(f"error while trying to stop {notebook_instance_name}: {e.__class__} occured")
        logger.info(f"error while trying to stop {notebook_instance_name}: {e.__class__} occured")


"""
Start a notebook instance with its name.
For instance, if 'notebook_instance_name' variable is equal to 'my-instance',
it will stop the notebook instance with the name 'notebook_instance_name'.
If no instance has for name 'my-instance', it will print an error
"""


def start_sm_notebook_instance(notebook_instance_name):
    try:
        sm.start_notebook_instance(NotebookInstanceName=notebook_instance_name)
        print(f"{notebook_instance_name} has been started")
    except Exception as e:
        print(f"error while trying to start {notebook_instance_name}: {e.__class__} occured")
        logger.info(f"error while trying to start {notebook_instance_name}: {e.__class__} occured")


"""
Stop all the SageMaker notebook instance except those 
    - which match with the regex 
    - which are present in the array 'INSTANCES_EXCEPTION'
    - which have the tag for the autostop
array defined in the parameters.
"""


def stop_sm_notebook_instances_by_criterias():
    stopped_instances = []
    dict_sm = get_notebook_instances_in_service()

    for instance in dict_sm['NotebookInstances']:
        notebook_instance_name = instance['NotebookInstanceName']
        notebook_instance_arn = instance['NotebookInstanceArn']

        if re.match(regex,
                    notebook_instance_name) and notebook_instance_name not in exceptions and get_tag_value(
                notebook_instance_arn, TAGS['stop']) == "":
            stop_sm_notebook_instance(notebook_instance_name)
            stopped_instances.append(notebook_instance_name)

    return stopped_instances


"""
Stop all the SageMaker notebook instance by watching the tag '2s33:sm:scheduling:autostopcron' corresponding to a cron expression
with the following format : * * * * *
"""


def stop_sm_notebook_instances_by_cron():
    stopped_instances = []
    dict_sm = get_notebook_instances_in_service()

    for instance in dict_sm['NotebookInstances']:
        notebook_instance_name = instance['NotebookInstanceName']
        notebook_instance_arn = instance['NotebookInstanceArn']

        cron_expression = get_tag_value(notebook_instance_arn, TAGS['stop'])

        if cron_expression:
            try:
                has_to_be_stopped = is_cron_be_triggered_now(cron_expression)
                if has_to_be_stopped:
                    stop_sm_notebook_instance(notebook_instance_name)
                    stopped_instances.append(notebook_instance_name)
            except Exception as e:
                print(
                    f"error while trying to stop {notebook_instance_name} (cron method): {e.__class__} occured. Might be a not valid cron expression")
                logger.info(
                    f"error while trying to stop {notebook_instance_name} (cron method): {e.__class__} occured. Might be a not valid cron expression")

    return stopped_instances


def start_sm_notebook_instances_by_cron():
    started_instances = []
    dict_sm = get_notebook_instances_stopped()

    for instance in dict_sm['NotebookInstances']:
        notebook_instance_name = instance['NotebookInstanceName']
        notebook_instance_arn = instance['NotebookInstanceArn']

        cron_expression = get_tag_value(notebook_instance_arn, TAGS['start'])

        if cron_expression:
            try:
                has_to_be_started = is_cron_be_triggered_now(cron_expression)
                if has_to_be_started:
                    start_sm_notebook_instance(notebook_instance_name)
                    started_instances.append(notebook_instance_name)
            except Exception as e:
                print(
                    f"error while trying to start {notebook_instance_name} (cron method): {e.__class__} occured. Might be a not valid cron expression")
                logger.info(
                    f"error while trying to start {notebook_instance_name} (cron method): {e.__class__} occured. Might be a not valid cron expression")

    return started_instances


"""
 Check if an instance is tagged for auto starting or auto stopping:
    - check for autostopping if state = 'stop'
    - check for autostarting if state = 'start'
"""


def get_tag_value(arn, tag):
    tags = sm.list_tags(ResourceArn=arn)
    for dict_tag in tags['Tags']:
        if dict_tag['Key'] == tag:
            raw_cron_expression = dict_tag['Value'].strip()
            cron_expression = re.sub(r'\.', '*', raw_cron_expression)
            return cron_expression
    return ""


"""
 Check if a cron expression passed in parameter ('cron_expression') match to the current time
"""


def is_cron_be_triggered_now(cron_expression):
    return croniter.croniter("* * * * * *").match(cron_expression, datetime.datetime.now())


"""
Entry point of the lambda function
"""


def lambda_handler(event, context):
    task_definition = event.get('taskDefinition')
    stopped_instances = []
    started_instances = []

    if task_definition == "night":
        logger.info(
            f'Sending event: {"Night shutting down for SageMaker notebook instances had been triggered"} it activates {EXECUTION_NIGHT_FUNCTION_NAME}')
        stopped_instances = stop_sm_notebook_instances_by_criterias()
    elif task_definition == "cron":
        stopped_instances = stop_sm_notebook_instances_by_cron()
        started_instances = start_sm_notebook_instances_by_cron()

    if len(stopped_instances) > 0:
        logger.info(f"SageMaker notebook instances shutdowned: => {stopped_instances}")
        logger.info(f"SageMaker notebook instances started: => {started_instances}")
    return {
        'statusCode': 200,
        'body': json.dumps(f"SageMaker notebook instances shutdowned: => {stopped_instances}\n" +
                           f"SageMaker notebook instances started: => {started_instances}")
    }


### Deploy mlops playground instance

1. Edit **CreatorFullName**  and **InstanceName** parameters in file mlops_sagemaker_playground_parameters.json

2. Deploy template to Cloudformation a. With AWS cli command

        aws cloudformation create-stack --stack-name mlops-playground-<yourname> \
        --template-body file://<sagemaker-playground-json-path>/mlops_sagemaker_playground.json \
        --parameters file://<parameters-file-path>/mlops_sagemaker_playground_parameters.json \
        --profile <profile>


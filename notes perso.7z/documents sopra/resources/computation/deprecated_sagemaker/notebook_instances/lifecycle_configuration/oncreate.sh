#!/bin/bash
sudo -u ec2-user -i <<'EOF'
echo "\\\\\\\\\ Instance is in creation... Creation configuration in progress..." \\\\\\\\\"
echo "############################# env variables #############################"
aws s3 cp s3://${BACKEND_BUCKET}/lifecycle-configurations/mlops-notebook-instances/.env /home/ec2-user/
source /home/ec2-user/.env

echo "############################# certificates installation #############################"
aws s3 cp s3://${BACKEND_BUCKET}/lifecycle-configurations/mlops-notebook-instances/certificates.sh /home/ec2-user/
sh /home/ec2-user/certificates.sh

echo "############################# artifactory configuration #############################"
aws s3 cp s3://${BACKEND_BUCKET}/lifecycle-configurations/mlops-notebook-instances/artifactory.sh /home/ec2-user/
sh /home/ec2-user/artifactory.sh

echo "\\\\\\\\\ Instance is starting... Startup configuration in progress..." \\\\\\\\\"
echo "############################# python env initialization #############################"
aws s3 cp s3://${BACKEND_BUCKET}/lifecycle-configurations/mlops-notebook-instances/create-conda-envs.sh /home/ec2-user/
sh /home/ec2-user/create-conda-envs.sh

echo "\\\\\\\\\ Instance is created... Creation configuration finished..." \\\\\\\\\"
EOF
############################# certificates installation #############################

sudo -u ec2-user -i <<'EOF'

source /home/ec2-user/.env

# airbus bundle download
mkdir -p $CERT_PATH
echo Getting airbus ca from $REMOTE_AIRBUS_CERT
aws s3 cp s3://${BACKEND_BUCKET}/airbus-certs/airbus-ca/bundle/airbus-ca.crt $CERT_PATH
echo Airbus ca located at $CERT_PATH/airbus-ca.crt
echo Configuring git ssl ca for secured interaction with git
sudo git config --system http.sslCAInfo $CERT_PATH/airbus-ca.crt

EOF
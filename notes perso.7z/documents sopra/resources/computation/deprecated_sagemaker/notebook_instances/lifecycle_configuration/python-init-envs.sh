#!/bin/bash

sudo -u ec2-user -i <<'EOFF'
source /home/ec2-user/.env

# Activate env
conda activate $CUSTOM_ENVS/$ENV_NAME

echo Installing requirements

aws s3 cp s3://${BACKEND_BUCKET}/lifecycle-configurations/mlops-notebook-instances/requirements.txt $MYHOME/
python -m pip install --upgrade pip setuptools wheel
pip install -q -r $MYHOME/requirements.txt

EOFF

sudo -u ec2-user -i <<'EOFF'
source /home/ec2-user/.env
echo Make envs available as kernel
if [ -d "$CUSTOM_ENVS" ]
then
  echo Activating the env: $ENV_NAME
  source activate "$CUSTOM_ENVS/$ENV_NAME"
  python -m ipykernel install --user --name "$ENV_NAME" --display-name "Custom ($ENV_NAME)"
fi
EOFF

sudo -u ec2-user -i <<'EOFF'
source /home/ec2-user/.env

echo "source $MYHOME/.env" >>  $MYHOME/.bashrc
echo "alias activate_"$ENV_NAME"_env=\"source activate /home/ec2-user/SageMaker/envs/$ENV_NAME\"" >>  $MYHOME/.bashrc
EOFF




#!/bin/bash
sudo -u ec2-user -i <<'EOF'
source /home/ec2-user/.env

echo "############################# Directories creation #############################"
mkdir -p $MYHOME/SageMaker/data
mkdir -p $MYHOME/SageMaker/results

echo "############################# certificates installation #############################"
aws s3 cp s3://${BACKEND_BUCKET}/lifecycle-configurations/mlops-notebook-instances/certificates.sh .
sh certificates.sh

# echo "############################# jupyterlab configuration #############################"
aws s3 cp s3://${BACKEND_BUCKET}/lifecycle-configurations/mlops-notebook-instances/jupyterlab.sh .
sh jupyterlab.sh

echo "############################# Installation of non pip repo packages #############################"
aws s3 cp s3://${BACKEND_BUCKET}/lifecycle-configurations/mlops-notebook-instances/non-pip-repos.sh .
sh non-pip-repos.sh

echo "############################# Installing visrtual env as python kernel #############################"
aws s3 cp s3://${BACKEND_BUCKET}/lifecycle-configurations/mlops-notebook-instances/python-init-envs.sh .
sh python-init-envs.sh

echo "############################# artifactory configuration #############################"
aws s3 cp s3://${BACKEND_BUCKET}/lifecycle-configurations/mlops-notebook-instances/artifactory.sh .
sh artifactory.sh

echo "############################# cron job to save notebooks #############################"
aws s3 cp s3://${BACKEND_BUCKET}/lifecycle-configurations/mlops-notebook-instances/notebooks-saving-s3.py .
echo "*/5 * * * * python3 /home/ec2-user/notebooks-saving-s3.py" | crontab - # initialize cron
#(crontab -l && echo "1 1  * * *  test") | crontab - # if you want to add a line to cron

echo "################Configuring git store################"
git config --global credential.helper 'store --file=/tmp/my-git-credentials'


echo "\\\\\\\\\ Instance is started... Startup configuration finished..." \\\\\\\\\"

EOF
#!/bin/bash

sudo -u ec2-user -i <<'EOFF'
source /home/ec2-user/.env

echo Creating new conda environment $ENV_NAME
aws s3 cp s3://${BACKEND_BUCKET}/lifecycle-configurations/mlops-notebook-instances/conda-env.yml $MYHOME/.
conda env create -q -f $MYHOME/conda-env.yml --prefix $CUSTOM_ENVS/$ENV_NAME||conda env update -q -f $MYHOME/conda-env.yml

EOFF

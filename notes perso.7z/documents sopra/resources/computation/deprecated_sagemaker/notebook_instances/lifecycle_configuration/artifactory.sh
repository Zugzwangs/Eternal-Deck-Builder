#!/bin/bash
sudo -u ec2-user -i <<'EOFF'
source /home/ec2-user/.env

echo Artifactory configuration for pip

mkdir -p $MYHOME/.pip

export ARTIFACTORY_DOMAIN=artifactory.2b82.aws.cloud.airbus.corp
export ARTIFACTORY_LOGIN="sa-2s33-devtool, sa-2s33-devtool"
export ARTIFACTORY_DEVOPTOOL_SECRET_ID=/airbus/platform/secretsmanager/sa-2s33-devtool/artifactory/v1
export ARTIFACTORY_DEVOPTOOL_SECRET=$(aws secretsmanager get-secret-value --secret-id $ARTIFACTORY_DEVOPTOOL_SECRET_ID --region eu-west-1)
export APIKEY=$(echo $ARTIFACTORY_DEVOPTOOL_SECRET | jq '.SecretString | fromjson | ."api_key"' | tr -d \")
export APIKEY=$(sed -e 's/^"//' -e 's/"$//' <<< $APIKEY)

echo Setting artifactory configuration for pip
cat << EOF > $MYHOME/.pip/pip.conf
[global]
index-url = https://$ARTIFACTORY_LOGIN:$APIKEY@artifactory.2b82.aws.cloud.airbus.corp/artifactory/api/pypi/r-2s33-insider-pypi-virtual/simple
trusted-host = $ARTIFACTORY_DOMAIN
EOF

echo Setting artifactory configuration for conda
cat << EOF > $MYHOME/.condarc
# Needed only if Airbus root ca are not properly installed
ssl_verify: $CERT_PATH/airbus-ca.crt
channel_alias: https://artifactory.2b82.aws.cloud.airbus.corp/artifactory
channels:
  - defaults
# Redefining the defaults conda channel with artifactory mirrors
default_channels:
  - anaconda-main # alias of the main channel
  - anaconda-r # alias of the R channel
# Avoid conda to update itself if not explicetely requested through conda update conda
auto_update_conda: False

EOF
EOFF

#!/bin/bash
sudo -u ec2-user -i <<'EOFF'
source /home/ec2-user/.env

echo "############################# jupyterlab extensions #############################"
# source $MYHOME/anaconda3/bin/activate JupyterSystemEnv

# install version 2 of jupyterlab and restart jupyterlab server (/!\ don't change to 3, it will broke jupyterlab)
# conda install -c conda-forge jupyterlab=2 jupyterlab-git -y -q


# set bash instead of sh as default shell
echo 'c.NotebookApp.terminado_settings = { "shell_command": ["/bin/bash"] }' >> $MYHOME/.jupyter/jupyter_notebook_config.py
echo 'c.KernelManager.autorestart = True' >> $MYHOME/.jupyter/jupyter_notebook_config.py
echo "c.MultiKernelManager.default_kernel_name = '$CUSTOM_ENVS/$ENV_NAME'" >> $MYHOME/.jupyter/jupyter_notebook_config.py


# apply previous modifications (need a restart)
sudo restart jupyter-server

# nohup sh -c '
# Install nodejs 14
# conda install -c conda-forge nodejs=14.4.0
# conda install -c conda-forge jupyterlab=3.2.1

# update extensions
# jupyter labextension update --all --log-level=INFO

# extension installation
# jupyter labextension install @jupyterlab/git @jupyterlab/debugger @lckr/jupyterlab_variableinspector --log-level=INFO;

# jupyterlab topbar extension
# jupyter labextension install jupyterlab-topbar-extension \
                             jupyterlab-system-monitor \
                             jupyterlab-topbar-text \
                             jupyterlab-theme-toggle --log-level=INFO;

# jupyterlab installation widgets
# pip install ipywidgets
# jupyter nbextension enable $EXTENSION_NAME --py --sys-prefix

# build jupyterlab to apply changes (extension updated & installed)
# jupyter lab build --dev-build=False --minimize=True

# conda deactivate ' &

EOFF
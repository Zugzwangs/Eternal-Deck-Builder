import boto3
import os
import glob
import json

bucket_name = 's3-2s33-dev-mlops-playground-notebooks-backup-eu-west-1'

sm = boto3.client('sagemaker')
s3 = boto3.client('s3')

def get_notebook_name():
    log_path = '/opt/ml/metadata/resource-metadata.json'
    with open(log_path, 'r') as logs:
        _logs = json.load(logs)
    return _logs['ResourceName']

def save_notebooks(bucket, root_path='/home/ec2-user/SageMaker'):
    notebook_saved=[]
    notebook_ignored=[]
    for notebook_full_path in glob.glob(f'{root_path}/**/*.ipynb', recursive=True):
        notebook_relative_path = notebook_full_path.replace(f"{root_path}/", "")
        if "Untitled" not in notebook_relative_path and "development_notebooks/" not in notebook_relative_path and "envs/2s33_datafly" not in notebook_relative_path:
            boto3.Session().resource('s3').Bucket(bucket_name).Object(os.path.join(notebook_instance_name, notebook_relative_path)).upload_file(notebook_full_path)
            # print(f"{notebook_path} saved")
            notebook_saved.append(notebook_relative_path)
        else:
            notebook_ignored.append(notebook_relative_path)
    print(f"{notebook_saved} are saved")
    #print(f"{notebook_ignored} are ignored")
    return notebook_saved

notebook_instance_name = get_notebook_name()
save_notebooks(bucket=bucket_name)
#!/bin/bash
sudo -u ec2-user -i <<'EOFF'
source /home/ec2-user/.env

echo "############################# Clone repositories not presents in the artifactory #############################"

export GITHUB_DOMAIN=github.airbus.corp
export GITHUB_LOGIN="sa-2s33-devtool"
export GITHUB_DEVOPTOOL_SECRET_ID=/airbus/platform/secretsmanager/sa-2s33-devtool/github/v1
export GITHUB_DEVOPTOOL_SECRET=$(aws secretsmanager get-secret-value --secret-id $GITHUB_DEVOPTOOL_SECRET_ID --region eu-west-1)
export APIKEY=$(echo $GITHUB_DEVOPTOOL_SECRET | jq '.SecretString | fromjson | ."github_token"' | tr -d \")
export APIKEY=$(sed -e 's/^"//' -e 's/"$//' <<< $APIKEY)

if [ ! -d "$MYHOME/SageMaker/development_notebooks" ] ; then
    git clone https://$APIKEY@$GITHUB_DOMAIN/Airbus/development_notebooks.git $MYHOME/SageMaker/development_notebooks
    cd $MYHOME/SageMaker/development_notebooks
    # python setup setup.py install
fi

EOFF

#### AMI factory lambd function

Test building an image from an EC2 instance

    {
        "ResourceProperties":
            { "Command": "Build",
             "InstanceId": <running-instance-id>,
             "Algorithm": "uc_01_new",
             "JenkinsBuildNumber": "283" },
        "RequestType": "Create",
        "ResponseURL": "test"
    }

Test clean ami, snapshot and launch template

    {
      "ResourceProperties": {
        "Command": "Clean",
        "AMIid": <ami-id>,
        "SnapId": <snap-id>,
        "BrainCellLauchTemplate": <launchtemplate-id>,
        "Algorithm": "uc_01_new",
        "JenkinsBuildNumber": "283"
      },
      "RequestType": "Delete",
      "ResponseURL": "test"
    }
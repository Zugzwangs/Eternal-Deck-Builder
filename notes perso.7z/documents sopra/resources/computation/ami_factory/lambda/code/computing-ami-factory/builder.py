import time
import boto3
import datetime
import cfnresponse
from custom_logging_2s33.insider_protection_logging import InsiderProtectionLogging

logger = InsiderProtectionLogging(__name__, 'DEBUG').logger

""" Build AMI """


def build(event, context):
    # Initialisation
    responseStatus = cfnresponse.SUCCESS
    responseData = {}
    try:
        logger.info('Grab parameters')
        targetInstanceId = event['ResourceProperties']['InstanceId']
        algorithm = event['ResourceProperties']['Algorithm']
        JenkinsBuildNumber = event['ResourceProperties']['JenkinsBuildNumber']

        logger.info('Stop base instance first')
        client = boto3.client('ec2', 'eu-west-1')
        client.stop_instances(InstanceIds=[targetInstanceId])
        waiter = client.get_waiter('instance_stopped')
        waiter.wait(InstanceIds=[targetInstanceId])

        logger.info('Build #' + JenkinsBuildNumber +
                    ' of the AMI using instance ' +
                    targetInstanceId + ' for algorithm ' + algorithm)
        create_time = datetime.datetime.now()
        create_fmt = create_time.strftime('%d%m%Y.%H.%M.%S')
        AMIid = client.create_image(InstanceId=targetInstanceId,
                                    Name="ami-2s33-rh7-computing-" + algorithm + "-" + JenkinsBuildNumber + "-" + create_fmt,
                                    Description="Lambda created AMI from " + targetInstanceId + " for algorithm " + algorithm,
                                    NoReboot=True, DryRun=False)

        logger.info('Ami id: {}'.format(AMIid))
        new_ami_id = AMIid['ImageId']
        logger.info('Attributed AMI id is: ' + new_ami_id)
        logger.info('Wait a bit after starting the image creation')
        time.sleep(30)
        logger.info('Getting associated snapshot Id')
        response_image = client.describe_images(ImageIds=[new_ami_id])
        logger.info('DEGUG POINT')
        logger.info('Image description: {}'.format(response_image))

        # TODO: i add a fake value for snap id because when using NoReboot=False when creating image an issue occurs !!?
        # ami_snap_id = "snap-fake"
        ami_snap_id = response_image['Images'][0]['BlockDeviceMappings'][0]['Ebs']['SnapshotId']
        logger.info('Trace Snap Ids: {}'.format(ami_snap_id))

        logger.info('bundle AMI and Snap Ids in the response object')
        responseData['AMIid'] = new_ami_id
        responseData['SnapId'] = ami_snap_id

    except Exception as e:
        responseStatus = cfnresponse.FAILED
        logger.info("[ERROR] Failed during AMI creation operation. Reason: {}. Method: {}"
                    .format(e, 'builder.build'))

    finally:
        return cfnresponse.send(event, context, responseStatus, responseData)


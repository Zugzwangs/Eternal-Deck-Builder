import time
import json
import boto3
import cfnresponse
from custom_logging_2s33.insider_protection_logging import InsiderProtectionLogging

logger = InsiderProtectionLogging(__name__, 'DEBUG').logger

MAX_RETRIES = 50
TIMEOUT_REMAINING = 60000


# Creates a new AWS client and execute the same lambda function asynchronously
def relaunch_lambda(event, context):
    try:
        logger.info('Relaunch the lambda')
        lambda_cli = boto3.client('lambda', 'eu-west-1')
        lambda_cli.invoke_async(FunctionName=context.function_name, InvokeArgs=json.dumps(event))
        return True
    except:
        logger.error("When lambda call itself. Reason: {}. Method: {}"
                     .format(e, 'cleaner.relaunch_lambda'))
        return False


# Updates the number of iterations left that the lambda function.
def update_num_retries(event):
    if not event.get("NUM_RETRIES"):
        event["NUM_RETRIES"] = MAX_RETRIES
    elif event.get("NUM_RETRIES") > 0:
        event["NUM_RETRIES"] = event.get("NUM_RETRIES") - 1

    logger.info("Number of retries left: " + str(event["NUM_RETRIES"]))
    return event.get("NUM_RETRIES")


# Dummy function
def do_nothing(event, context):
    responseStatus = cfnresponse.SUCCESS
    responseData = {}
    return cfnresponse.send(event, context, responseStatus, responseData)


# Perform the deletion of AMI and snapshot when the stack is deleted
def clean_ami(event, context):
    responseStatus = cfnresponse.SUCCESS
    responseData = {}
    try:
        # when deleting the stack we want to clean up the custom AMI and snapshot
        AMIid = event['ResourceProperties']['AMIid']
        SnapId = event['ResourceProperties']['SnapId']
        BrainCellLauchTemplate = event['ResourceProperties']['BrainCellLauchTemplate']

        ec = boto3.client('ec2', 'eu-west-1')
        # deregister AMI
        logger.info('Deregistering AMI: {}'.format(AMIid))
        response = ec.deregister_image(ImageId=AMIid)
        # deleting snapshot
        logger.info('Deleting Snapshot: {}'.format(SnapId))
        response = ec.delete_snapshot(SnapshotId=SnapId)
        # deleting lauchtemplate
        logger.info('Deleting launch template: {}'.format(BrainCellLauchTemplate))
        response = ec.delete_launch_template(LaunchTemplateId=BrainCellLauchTemplate)
    except Exception as e:
        responseStatus = cfnresponse.FAILED
        logger.error("Exception raised damnit {}".format(e))

    finally:
        return cfnresponse.send(event, context, responseStatus, responseData)


# Delete the base instance used for creating AMI before the stack is create complete
def clean_instance(event, context):
    responseStatus = cfnresponse.SUCCESS
    responseData = {}
    try:
        # catch AMI ID
        AMIid = event['ResourceProperties']['AMIid']
        # need to wait the AMI has reach the 'finished' state (which state exactly) before deleting the base instance
        logger.info('Check AMI state')
        while (context.get_remaining_time_in_millis() > TIMEOUT_REMAINING):
            ami = boto3.resource('ec2').Image(AMIid)
            state = ami.state
            logger.info("AMI status: {}".format(state))
            if (state == 'pending'):
                time.sleep(30)
            else:
                break
        else:
            # relaunch lambda function if retries left
            logger.info('No much time remaining for the current lambda execution')
            retries_left = update_num_retries(event)
            if retries_left > 0:
                logger.info('Call again the lambda as we still have retries to spend.')
                relaunch_lambda(event, context)
                logger.info('Exiting current lambda without sending message to cloud formation')
                return True
            else:
                responseStatus = cfnresponse.FAILED
                responseData = {"error": "too many retries"}
                return cfnresponse.send(event, context, responseStatus, responseData)

        # terminate instance
        targetInstanceId = event['ResourceProperties']['InstanceId']
        logger.info('Terminating instance: {}'.format(targetInstanceId))
        ec = boto3.client('ec2', 'eu-west-1')
        response = ec.terminate_instances(InstanceIds=[targetInstanceId])

        logger.info('Reference AMI and snapshot IDs in SSM')
        algorithm = event['ResourceProperties']['Algorithm']
        SnapId = event['ResourceProperties']['SnapId']

        ssm = boto3.client('ssm', 'eu-west-1')
        logger.info('Prepare SSM parameters names')
        ami_entry = '/airbus/2s33/ssm/ami-' + algorithm + '-latest'
        snap_entry = '/airbus/2s33/ssm/snap-' + algorithm + '-latest'
        logger.info('Update parameters values in SSM')
        ssm.put_parameter(Name=ami_entry, Value=AMIid, Overwrite=True, Type='String')
        ssm.put_parameter(Name=snap_entry, Value=SnapId, Overwrite=True, Type='String')
        # Register Lauch template ID in SSM
        BrainCellLauchTemplate = event['ResourceProperties']['BrainCellLauchTemplate']
        BrainCellLauchTemplateVersion = str(event['ResourceProperties']['BrainCellLauchTemplateVersion'])
        lt_id_entry = '/airbus/2s33/ssm/braincell-launchtemplate-id-' + algorithm + '-latest'
        lt_version_entry = '/airbus/2s33/ssm/braincell-launchtemplate-version-' + algorithm + '-latest'
        ssm.put_parameter(Name=lt_id_entry, Value=BrainCellLauchTemplate, Overwrite=True, Type='String')
        ssm.put_parameter(Name=lt_version_entry, Value=BrainCellLauchTemplateVersion, Overwrite=True, Type='String')

    except Exception as e:
        responseStatus = cfnresponse.FAILED
        logger.error("Exception raised. Reason: {}. Method: {}"
                     .format(e, 'cleaner.clean_instance'))

    finally:
        logger.debug('Passing into finally block from builder.clean_instance')
        return cfnresponse.send(event, context, responseStatus, responseData)


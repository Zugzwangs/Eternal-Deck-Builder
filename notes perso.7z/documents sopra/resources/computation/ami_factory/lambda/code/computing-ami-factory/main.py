import cfnresponse
import builder
import cleaner
from custom_logging_2s33.insider_protection_logging import InsiderProtectionLogging


def lambda_handler(event, context):
    logger = InsiderProtectionLogging(__name__, 'DEBUG').logger
    # Initialisation
    responseStatus = cfnresponse.SUCCESS
    responseData = {}
    logger.debug('Event: {}'.format(event))

    try:

        command = event['ResourceProperties']['Command']

        if (command == 'Build'):
            if (event['RequestType'] == 'Delete'):
                response = cleaner.do_nothing(event, context)
            elif (event['RequestType'] == 'Update'):
                response = cleaner.do_nothing(event, context)
            else:
                response = builder.build(event, context)

        elif command == 'Clean':
            if (event['RequestType'] == 'Delete'):
                response = cleaner.clean_ami(event, context)
            elif (event['RequestType'] == 'Update'):
                response = cleaner.do_nothing(event, context)
            else:
                response = cleaner.clean_instance(event, context)

        return response

    except Exception as e:
        logger.error("[ERROR] Error when catching Command parameter or when \
                calling lambda methods. Reason: {}. Method: {}"
                .format(e, 'main.lambda_handler'))

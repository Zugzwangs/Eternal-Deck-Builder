#!/bin/bash -x
set -x

#Environment variable setup
echo 'Setting up environment variables (aws_profile)'
source /etc/profile.d/awsenv.sh

# Install redhat repos and packages
echo "activating required redhat repos"
yum-config-manager --enable rhel-7-server-rhui-extras-rpms
yum-config-manager --enable rhel-7-server-optional-rpms
yum-config-manager --enable rhel-server-rhui-rhscl-7-rpms
echo 'installing development tools and python'
sudo yum install -y scl-utils
sudo yum install -y scl-utils-build
sudo yum install -y rh-python38
sudo yum install -y @development

sudo yum remove -y git*
sudo yum install -y https://packages.endpointdev.com/rhel/7/os/x86_64/endpoint-repo.x86_64.rpm
sudo yum install -y git

## Edit pip to reach artifactory
echo 'fetching artifactory secret'
TRUSTED_HOST="artifactory.2b82.aws.cloud.airbus.corp download.pytorch.org"
ARTIFACTORY_SECRET_NAME="/airbus/platform/secretsmanager/sa-2s33-devtool/artifactory/idtoken/v1"
set +x
ARTIFACTORY_SECRET_VALUE=$(aws secretsmanager get-secret-value --secret-id ${ARTIFACTORY_SECRET_NAME} --region eu-west-1)
ARTIFACTORY_ID_TOKEN=$(echo $ARTIFACTORY_SECRET_VALUE | jq '.SecretString | fromjson | ."identity_token"' | tr -d \")
ARTIFACTORY_ID_TOKEN=$(sed -e 's/^"//' -e 's/"$//' <<< $ARTIFACTORY_ID_TOKEN)
set -x

echo 'Fetching airbus certif cacerts-airbus.pem'
CERTIF_PATH=/mnt/airbus_certif
mkdir $CERTIF_PATH
sudo chmod -R 777 $CERTIF_PATH
cd $CERTIF_PATH
wget 'https://confluence.airbus.corp/download/attachments/22052964/cacerts-airbus.pem?version=1&modificationDate=1555665496074&api=v2' -o $CERTIF_PATH/cacerts-airbus.pem

mkdir ~/.pip
set +x
cat << EOF > ~/.pip/pip.conf
[global]
trusted-host = ${TRUSTED_HOST}
index-url = https://sa-2s33-devtool, sa-2s33-devtool:$ARTIFACTORY_ID_TOKEN@artifactory.2b82.aws.cloud.airbus.corp\
/artifactory/api/pypi/r-2s33-insider-pypi-virtual/simple
cert = $CERTIF_PATH/cacerts-airbus.pem
EOF
set -x

echo 'Complete environment'
source scl_source enable rh-python38 &> /dev/null
python -V
pip install --upgrade pip==22.3.1
pip3 --version
pip3 install setuptools==58.0.0
pip3 install wheel==0.37.0

### Clone algorithm project
git version
echo 'fetching github secret'
GITHUB_ACCESS_TOKEN_SECRET_ID=/airbus/platform/secretsmanager/sa-2s33-devtool/github/v1
set +x
GITHUB_ACCESS_TOKEN_SECRET=$(aws secretsmanager get-secret-value --secret-id $GITHUB_ACCESS_TOKEN_SECRET_ID --region eu-west-1)
GITHUB_ACCESS_TOKEN=$(echo $GITHUB_ACCESS_TOKEN_SECRET | jq '.SecretString | fromjson | ."github_token"' | tr -d \")
set -x
echo 'Create working directory'
DATA_PATH=/mnt/data
mkdir $DATA_PATH
cd $DATA_PATH
echo "Cloning repo https://github.airbus.corp/Airbus/$ALG_NAME.git"
set +x
git clone --depth 1 --branch ${TARGET_TAG} https://${GITHUB_ACCESS_TOKEN}@github.airbus.corp/Airbus/$ALG_NAME.git
set -x
cd $PYTHONPATH
git tag -l --format='%(contents)' ${TARGET_TAG}

### Install algorithm dependencies
pip3 install -r $PYTHONPATH/requirements.txt

#Give user access to algorithm folder
sudo chmod -R 777 $DATA_PATH

### setup log collection
echo 'installing CloudWatch agent...'
cd /mnt
wget -q https://s3.amazonaws.com/amazoncloudwatch-agent/redhat/amd64/latest/amazon-cloudwatch-agent.rpm
rpm -U ./amazon-cloudwatch-agent.rpm

echo 'updating cloudwatch agent configuration to include all logs collection'

ALG_LOG_GROUP="/2s33/computing/algorithm/$ALG_NAME"
CFN_INIT_CMD="/var/log/ami-setup.log"
LOG_STREAM_SETUP="$JENKINS_BUILD_NUMBER-ami-setup"

aws s3 cp s3://s3-2s33-$ENV-platform-backend-eu-west-1/templates/braincell_metrics.json /mnt/braincell_metrics.json

jq --arg log_group_name $ALG_LOG_GROUP \
--arg setup_log_stream_name $LOG_STREAM_SETUP \
--arg cfn_init_cmd_logs_path $CFN_INIT_CMD \
'.logs.logs_collected.files.collect_list[1]["file_path"] = $cfn_init_cmd_logs_path
| .logs.logs_collected.files.collect_list[1]["log_group_name"] = $log_group_name
| .logs.logs_collected.files.collect_list[1]["log_stream_name"] = $setup_log_stream_name' \
/mnt/braincell_metrics.json > /mnt/braincell_metrics_modified.json

/opt/aws/amazon-cloudwatch-agent/bin/amazon-cloudwatch-agent-ctl -a fetch-config -m ec2 \
-c file:/mnt/braincell_metrics_modified.json -s
/opt/aws/amazon-cloudwatch-agent/bin/amazon-cloudwatch-agent-ctl -m ec2 -a start
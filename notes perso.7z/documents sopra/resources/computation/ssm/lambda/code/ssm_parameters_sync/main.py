import json
import traceback
import os
import boto3

REGION = os.environ['REGION']
SSM_DESTINATION_REDHAT = os.environ['SSM_DESTINATION_REDHAT']
SSM_SOURCE_REDHAT = os.environ['SSM_SOURCE_REDHAT']

ssm_client = boto3.client('ssm')
ec2_client = boto3.client('ec2')

def get_parameter_value(name):
    parameter = ssm_client.get_parameter(Name=name)
    return parameter['Parameter']['Value']

def update_parameter_value(name, value):
    ssm_client.put_parameter(
        Name=name,
        Overwrite=True,
        Value=value
    )

def describe_associated_snap(ami_id):
    image = ec2_client.describe_images(ImageIds=[ami_id]).get('Images')[0]
    if len(image['BlockDeviceMappings']) != 1:
        raise Exception(f'Unexpected number of devices found {len(image["BlockDeviceMappings"])}. Expecting one mounted on /dev/sda1')
    else:
        return image['BlockDeviceMappings'][0]['Ebs']['SnapshotId']


def lambda_handler(event, context):
    golden_ami_id = get_parameter_value(SSM_SOURCE_REDHAT)
    print(f'Fetching associated  snap id for ami {golden_ami_id}')

    golden_snap = describe_associated_snap(golden_ami_id)

    print(f'Golden ami {golden_ami_id} snap is to {golden_snap}')

    update_parameter_value(SSM_DESTINATION_REDHAT, golden_snap)

    return {
        'response': json.dumps(f'parameter {SSM_DESTINATION_REDHAT} id updated with value {golden_snap}.')
    }

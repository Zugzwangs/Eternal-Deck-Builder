****
SSM parameters sync
***

This is a simple lambda functiont that is triggered when the ssm paarmeter
/airbus/golden-ami/redhat7/latest was updated by PCP in order to update the new snapshot id associated in the parameter
/airbus/golden-snap/redhat7/latest used internally.

****
Event workflow:
***

SSM -> Event Bridge -> Lambda

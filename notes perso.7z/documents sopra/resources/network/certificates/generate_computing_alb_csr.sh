#!/bin/bash
# ####################################################
# Usage: generate a CSR for alb certificate
# run the script and get the CSR output in /tmp/csr
# NOTE: if you edit this file in windows it may include \r at the end
# of each line. To remove this and make it work in linux, you should apply
# the command: sed -i 's/\r//g' generate_computing_alb_csr.sh
# ####################################################

# specify server caracteristics
touch "/tmp/req.txt"
# NOTE: environment variable should be set to dev or prod in global config
buckets='{"dev": "s3-2s33-dev-platform-backend-eu-west-1", "prod": "s3-2s33-prod-platform-backend-eu-west-1"}'

private_bucket={$BACKEND_BUCKET}
my_domain=${APPLICATION_LOADBALANCER_DNS_COMPUTING_FLEET}

echo "[req]
default_bits = 2048
distinguished_name = req_distinguished_name
prompt = no
[req_distinguished_name]
C = FR
O = Airbus
OU = DSO
CN = ${my_domain}
" > "/tmp/req.txt"

# generate private key and CSR
openssl genrsa -out "/tmp/myserver.key" 2048
openssl req -new -config "/tmp/req.txt" -key "/tmp/myserver.key" -out "/tmp/myserver.csr"

# backup the key
aws s3 cp "/tmp/myserver.key" "s3://${private_bucket}/airbus-certs/${my_domain}/${my_domain}.key"
aws s3 cp "/tmp/myserver.csr" "s3://${private_bucket}/airbus-certs/${my_domain}/${my_domain}.csr"
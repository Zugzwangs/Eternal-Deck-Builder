cf_jenkins_slave_ec2.yml is based on the example template.yml in the DevOps GitHub repository:
https://github.airbus.corp/Airbus/deploy-redhat-jenkins-slave-jnlp

The code dependencies are downloaded from Artifactory here: 
https://artifactory.2b82.aws.cloud.airbus.corp/artifactory/r-airbus-generic-local/2b82-jenkins-slave/$PACK_VERSION/jenkins-slave-install.tgz

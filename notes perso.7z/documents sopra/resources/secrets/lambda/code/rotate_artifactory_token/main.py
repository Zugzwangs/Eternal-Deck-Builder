import os
import base64
import boto3
import json
from botocore.exceptions import ClientError
import logging
import requests
from datetime import datetime

from custom_logging_2s33.insider_protection_logging import InsiderProtectionLogging
LOGGING_LEVEL = os.environ['LOGGING_LEVEL']
# TODO use custom logger
logger = logging.getLogger()
logger.setLevel(logging.INFO)

""" Lambda Rotate Artifactory Secret
Usage:
    This lambda automate the Artifactory 'Identity Token' regeneration process.

Args:
    event (dict): the following keys are provide by the AWS Secret rotation event call
        - ClientRequestToken: The ClientRequestToken of the secret version
        - SecretId: The secret ARN or identifier
        - Step: The rotation step [one of createSecret, setSecret, testSecret, or finishSecret]

    context (LambdaContext): The Lambda runtime information

Raises:
    - ResourceNotFoundException: If the secret with the specified arn and stage does not exist
    - ValueError: If the secret is not properly configured for rotation
    - KeyError: If the event parameters do not contain the expected keys
    
Todos:
    - send email or notification through an relevant SNS topic to acknowledge the secret update_secret_version_stage
    - use custom logger ?
    - 
"""
    
def lambda_handler(event, context):

    # DEBUG
    logger.info(f'event : {event}')
    
    # Get events keys
    token = event['ClientRequestToken']
    arn = event['SecretId']
    step = event['Step']

    # Secret service Client
    service_client = boto3.client('secretsmanager')

    # Make sure the version is staged correctly
    metadata = service_client.describe_secret(SecretId=arn)
    logger.info("show secret metadata;")
    logger.info(f'metadata : {metadata}')
    
    if not metadata['RotationEnabled']:
        logger.error("Secret %s is not enabled for rotation" % arn)
        raise ValueError("Secret %s is not enabled for rotation" % arn)
        
    versions = metadata['VersionIdsToStages']
    if token not in versions:
        logger.error("Secret version %s has no stage for rotation of secret %s." % (token, arn))
        raise ValueError("Secret version %s has no stage for rotation of secret %s." % (token, arn))
    if "AWSCURRENT" in versions[token]:
        logger.info("Secret version %s already set as AWSCURRENT for secret %s." % (token, arn))
        return
    elif "AWSPENDING" not in versions[token]:
        logger.error("Secret version %s not set as AWSPENDING for rotation of secret %s." % (token, arn))
        raise ValueError("Secret version %s not set as AWSPENDING for rotation of secret %s." % (token, arn))


    # CONDITIONAL STEP SWITCH
    if step == "createSecret":
        logger.info("lambda_handler: step createSecret")
        create_secret(service_client, arn, token)

    elif step == "setSecret":
        logger.info("lambda_handler: step setSecret")
        logger.info("this step is empty because the secret is set during previous createSecret stage.")

    elif step == "testSecret":
        logger.info("lambda_handler: step testSecret")        
        if test_secret(service_client, arn, token):
            logger.info("step succesfull")
        else:
            raise StepTestSecretFail

    elif step == "finishSecret":
        logger.info("lambda_handler: step finishSecret")        
        finish_secret(service_client, arn, token)

    else:
        logger.error("lambda_handler: invalid step")        
        raise ValueError("Invalid step parameter")


def create_secret(service_client, arn, token):
    """
    Checks for the existence of a secret for the given ID in token. If one does not exist, it will generate a
    new secret and put it with as the version passed in token.

    Args:
        - service_client (client): The secrets manager service client
        - arn (string): The secret ARN or other identifier
        - token (string): The ClientRequestToken associated with the secret version

    Raises:
        ResourceNotFoundException: If the secret with the specified arn and stage does not exist
    """
    logger.info('create_secret: entering function')
    # Make sure the current secret exists
    service_client.get_secret_value(SecretId=arn, VersionStage="AWSCURRENT")

    # Now try to get the secret version, if that fails, put a new secret
    try:
        service_client.get_secret_value(SecretId=arn, VersionId=token, VersionStage="AWSPENDING")
        logger.info("create_secret: Successfully retrieved secret for %s." % arn)
        
    except service_client.exceptions.ResourceNotFoundException:

        # Generate a new Artifactory Token
        SECRET_KEY = os.environ['SECRET_KEY']
        NEW_TOKEN_VALUE = create_token(service_client, arn)
        NewSecretString = json.dumps({ SECRET_KEY : NEW_TOKEN_VALUE })
        
        # Store the token as pending version of the secret
        service_client.put_secret_value(SecretId=arn, ClientRequestToken=token, SecretString=NewSecretString, VersionStages=['AWSPENDING'])
        logger.info("create_secret: Successfully put secret for ARN %s and version %s." % (arn, token))

def create_token(service_client, arn):
    """
    This method request/create the new secret (ID token) in Artifactory.

    Args:
        - service_client (client): The secrets manager service client
        - arn (string): The secret ARN or other identifier
        - token (string): The ClientRequestToken associated with the secret version
    """
    logger.info('create_token: entering function')
    
    # Retrieve current secret value to be able to authenticate against Artifactory
    SECRET_KEY = os.environ['SECRET_KEY']        
    current_secret_string = json.loads(get_secret_string(service_client, arn, version_stage='AWSCURRENT'))
    if SECRET_KEY in current_secret_string:
        logger.info("create_token: current secret string format match")
        CURRENT_SECRET_TOKEN=current_secret_string[SECRET_KEY]
    else:
        logger.error("create_token: current secret string bad format")
        raise SecretStringBadFormat
    
    # Request a new ID token to Artifactory
    ARTIFACTORY_AWS = os.environ['ARTIFACTORY_AWS']
    CREATE_TOKEN_URL = 'https://' + ARTIFACTORY_AWS + '/access/api/v1/tokens'
    HEADERS = { 'Authorization' : 'Bearer '+ CURRENT_SECRET_TOKEN }
    now = datetime.now()
    DESCRIPTION = 'devops token ' + now.strftime("%Y/%m/%d")
    PAYLOAD = { 'description' : DESCRIPTION }
    
    try:
        response = requests.post(CREATE_TOKEN_URL, headers=HEADERS, json=PAYLOAD, verify=False)
        response.raise_for_status()
    except requests.exceptions.HTTPError as errh:
        logger.error(f'create_token: Http Error: {errh}')
        return False
    except requests.exceptions.ConnectionError as errc:
        logger.error(f'create_token: Error Connecting: {errc}')
        return False
    except requests.exceptions.Timeout as errt:
        logger.error(f'create_token: Timeout Error: {errt}')
        return False
    except requests.exceptions.RequestException as err:
        logger.error(f'create_token: Oops: Something Else {err}')
        return False
    
    api_response = response.json()
    new_token_id = api_response['token_id']
    logger.info(f'create_token: new token ID is {new_token_id}')
    NEW_TOKEN_VALUE = api_response['access_token']
    # TODO parse Artifactory response json document.
    return NEW_TOKEN_VALUE
        
def test_secret(service_client, arn, token):
    """
    This method validate that the AWSPENDING secret works in the service that the secret belongs to (AKA Artifactory).

    Args:
        - service_client (client): The secrets manager service client
        - arn (string): The secret ARN or other identifier
        - token (string): The ClientRequestToken associated with the secret version
    """
    logger.info('test_secret: entering function')
    
    # get PENDING secret value
    SECRET_KEY = os.environ['SECRET_KEY']
    pending_secret_string = json.loads(get_secret_string(service_client, arn, version_stage='AWSPENDING'))
    if SECRET_KEY in pending_secret_string:
        logger.info("test_secret: pending secret string format match")
        PENDING_SECRET_TOKEN=pending_secret_string[SECRET_KEY]
    else:
        logger.error("test_secret: pending secret string bad format")
        raise SecretStringBadFormat

    # test candidat ID token against Artifactory
    ARTIFACTORY_AWS = os.environ['ARTIFACTORY_AWS']
    TEST_TOKEN_URL = 'https://' + ARTIFACTORY_AWS + '/access/api/v1/tokens'
    HEADERS = HEADERS = { 'Authorization' : 'Bearer '+ PENDING_SECRET_TOKEN } 

    try:
        response = requests.get(url=TEST_TOKEN_URL, headers=HEADERS, verify=False)
        response.raise_for_status()
    except requests.exceptions.HTTPError as errh:
        logger.error(f'test_secret: Http Error: {errh}')
        return False
    except requests.exceptions.ConnectionError as errc:
        logger.error(f'test_secret: Error Connecting: {errc}')
        return False
    except requests.exceptions.Timeout as errt:
        logger.error(f'test_secret: Timeout Error: {errt}')
        return False
    except requests.exceptions.RequestException as err:
        logger.error(f'test_secret: Oops: Something Else {err}')
        return False
    except:
        return False
    
    logger.info("test_secret: test sucessfull." ) 
    logger.info(response)
    return True
    
def finish_secret(service_client, arn, token):
    """
    This method finalizes the rotation process by marking the secret version passed in as the AWSCURRENT secret.

    Args:
        - service_client (client): The secrets manager service client
        - arn (string): The secret ARN or other identifier
        - token (string): The ClientRequestToken associated with the secret version

    Raises:
        ResourceNotFoundException: If the secret with the specified arn does not exist
    """
    logger.info('finish_secret: entering function')
    
    # First describe the secret to get the current version
    metadata = service_client.describe_secret(SecretId=arn)
    current_version = None
    for version in metadata["VersionIdsToStages"]:
        if "AWSCURRENT" in metadata["VersionIdsToStages"][version]:
            if version == token:
                # The correct version is already marked as current, return
                logger.info("finish_secret: Version %s already marked as AWSCURRENT for %s" % (version, arn))
                return True
            else:
                current_version = version
                break

    # Finalize by staging the secret version current
    service_client.update_secret_version_stage(SecretId=arn, VersionStage="AWSCURRENT", MoveToVersionId=token, RemoveFromVersionId=current_version)
    logger.info("finish_secret: Successfully set AWSCURRENT stage to version %s for secret %s." % (token, arn))
    
def get_secret_string(service_client, arn, version_stage='AWSCURRENT'):

    try:
        get_secret_value_response = service_client.get_secret_value(
            SecretId=arn,
            VersionStage=version_stage
        )
    except ClientError as e:
        if e.response['Error']['Code'] == 'DecryptionFailureException':
            # Secrets Manager can't decrypt the protected secret text using the provided KMS key.
            # Deal with the exception here, and/or rethrow at your discretion.
            raise e
        elif e.response['Error']['Code'] == 'InternalServiceErrorException':
            # An error occurred on the server side.
            # Deal with the exception here, and/or rethrow at your discretion.
            raise e
        elif e.response['Error']['Code'] == 'InvalidParameterException':
            # You provided an invalid value for a parameter.
            # Deal with the exception here, and/or rethrow at your discretion.
            raise e
        elif e.response['Error']['Code'] == 'InvalidRequestException':
            # You provided a parameter value that is not valid for the current state of the resource.
            # Deal with the exception here, and/or rethrow at your discretion.
            raise e
        elif e.response['Error']['Code'] == 'ResourceNotFoundException':
            # We can't find the resource that you asked for.
            # Deal with the exception here, and/or rethrow at your discretion.
            raise e
    else:
        # Decrypts secret using the associated KMS key.
        # Depending on whether the secret is a string or binary, one of these fields will be populated.
        if 'SecretString' in get_secret_value_response:
            secret = get_secret_value_response['SecretString']
            return(secret)
        else:
            decoded_binary_secret = base64.b64decode(get_secret_value_response['SecretBinary'])
            return(decoded_binary_secret)


## Rotate Artifactory token

Receives an event with at least this input

event:
   {
...
    }


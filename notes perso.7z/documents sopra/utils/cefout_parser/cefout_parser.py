#!/usr/bin/env python
# -*- coding: utf-8 -*-

import logging
import re
import json

logging.basicConfig(format='%(levelname)s: %(message)s', level=logging.DEBUG)


def main():
    """
    :return:
        - an avro schema written in file "avro_schema_idx_xx.json" to fulfill Nifi Avro registry
        - a SQL query written in fild "athena_query_idx_xx.txt" to create the table for idx_xx
    """
    file = "cefout_query.txt"
    bucket_name = "s3-2s33-dev-scheduled-raw-data-eu-west-1"
    db_name = "splunk_raw_indexes"

    idx, fields = parsing_cefout_query(file)
    fields_renamed = field_renaming(idx,fields)
    avro_schema = avro_schema_writer(idx, fields_renamed)
    athena_creation_table_query_writer(idx, fields_renamed, bucket_name, db_name)


def parsing_cefout_query(query_file):
    """
    :param query_file: file.txt with the cefout query written on a unique line
    :return: tuple(idx as str, fields as dict)
    """

    logging.info('Loading the cefout query')

    with open(query_file,'r') as f:
        cefout_query = f.readline()


    logging.info('Parsing the cefout query to extract the idx and the field names')

    cefout_query_clean_1 = re.sub('[^0-9a-zA-Z|_]+',' ',cefout_query) # replacing non alphanumeric character by " " except for "|" and "_"
    cefout_query_split = cefout_query_clean_1.split("|")

    stop_words = {"fields","cefout"} # used to remove the strings containing these words form the list of fields.
    cefout_query_clean_2 = [item for item in cefout_query_split if not [word for word in stop_words if word in item]]
    del cefout_query_clean_2[0] # the first element of the list is always the index canonical name concerned by the cefout query, not a field then we remove it

    # extracting field names
    fields = []

    for item in cefout_query_clean_2:

        if "eval" in item and "_raw" in item and "idx" in item:
            fields.append({"name": "idx"})
            idx = item.split()[-1]

        elif "_time" in item:
            fields.append({"name": "time"})

        else:
            fields.append({"name": item.split()[-1]})

    for index, field in enumerate(fields):
        field["type"] = "string"

    logging.info(f"idx is: {idx}")

    return(idx, fields)

def field_renaming(idx, fields):
    """
    Renaming fields name
    :param idx: name of the index as string
    :param fields: dict of fields name and type
    :return: fields_renamed as dict of string
    """

    data_renaming = {
        "idx_08": {
            "index": "local_index",
            "EventID": "event_id",
            "AuthenticationPackageName": "authentication_package_name",
            "LogonType": "logon_type",
            "SubStatus": "sub_status",
            "RecordID": "record_id",
            "LogonId": "logon_id",
            "ProcessName": "process_name",
            "cmdline": "cmd_line",
            "ProcessId": "process_id",
            "ParentCommandLine": "parent_commandline"
        },
        "idx_06": {
            "user": "hashed_user"
        },
        "idx_09": {
            "eventtype": "event_type"
        }
    }

    fields_renamed = fields.copy()

    if idx in data_renaming.keys():
        logging.info('Renaming the fields name')
        for i, field in enumerate(fields_renamed ):
            if field["name"] in data_renaming[idx]:
                field["name"] = data_renaming[idx][field["name"]]

    else:
        logging.info('No field renaming needed')

    logging.info(f"fields names are:")
    for i, field in enumerate(fields_renamed):
        field["name"] = field["name"].lower()
        logging.info(f"{field['name']}")

    return fields_renamed

def avro_schema_writer(idx,fields):
    """
    Write a avro_schema in a json file

    :param idx: idx number as str
    :param fields: dict of fields name
    :return: 0 if ok, 1 if issue
    """

    schema = {}
    schema["type"] = "record"
    schema["namespace"] = "splunk_data"
    schema["name"] = idx
    schema["fields"] = fields

    outfile = f"avro_schema_{schema['name']}.json"
    logging.info(f"Writing Avro schema to {outfile}")
    with open(outfile, "w+") as f:
        json.dump(schema, f, indent=2)

    return 0

def athena_creation_table_query_writer(idx,fields,bucket_name,db_name):
    """
    Write the SQL query to create an Athena table for the input idx and corresponding fields names

    :param idx: idx number as str
    :param fields: dict of fields name
    :param bucket_name: name of the s3 bucket as string where parquet files are stored
    :param db_name: name of the db as string for which the Athena table will belong
    :return: 0 if ok, 1 if issue
    """

    query = f"CREATE EXTERNAL TABLE IF NOT EXISTS {db_name}.{idx}( \n"

    for i, field in enumerate(fields):
        txt = f"`{field['name']}` {field['type']}"

        if i < len(fields)-1:
            query = query + txt + ', \n'
        else :
            query = query + txt + ') \n'

    location = f"s3://{bucket_name}/parquetfiles/{idx}"

    end_of_query = f"""PARTITIONED BY ( date string ) ROW FORMAT SERDE 'org.apache.hadoop.hive.ql.io.parquet.serde.ParquetHiveSerDe'
    WITH SERDEPROPERTIES ( 'serialization.format' = '1' )
    LOCATION '{location}'
    TBLPROPERTIES ('has_encrypted_data'='false');"""

    query = query + end_of_query

    outfile = f"athena_query_{idx}.txt"

    logging.info(f"Writing SQL Athena query {outfile}")
    with open(outfile,"w+") as f:
        f.write(query)

    return 0



if __name__ == "__main__":
    main()
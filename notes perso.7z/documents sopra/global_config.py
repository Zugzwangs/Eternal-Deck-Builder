import os.path

ROOT_DIR = os.path.dirname(os.path.abspath(__file__))
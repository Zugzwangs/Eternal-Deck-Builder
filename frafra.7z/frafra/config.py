import os
from cdk_2s33_method.colors import Colors

# Deployment Environment
try:
    ENV = os.environ["ENV"]
    if ENV not in ["dev", "int", "prod"]:
        raise ValueError(f"Environment variable ENV value must be in [dev,int,prod]")

    if ENV == "dev":
        color = Colors.GREEN
    # TODO (INT DEPLOYMENT) TO BE VALIDATED
    elif ENV == "int":
        color = Colors.CYAN
    elif ENV == "prod":
        color = Colors.WARNING
    else:
        color = Colors.BLUE
    print("")
    print(f"The environment context is: {color}{ENV}{Colors.ENDC}")
    print("")
except KeyError as e:
    raise ValueError(
        f"Environment variable ENV is missing."
        f"Please create it to setup dev or prod environment before deploying the app"
    )

# Customized Bootstrapped Env according to Airbus bootstrap template
DEPLOY_ROLE_ARN = 'arn:aws:iam::${AWS::AccountId}:role/role-${Qualifier}-deploy-role-${AWS::AccountId}-${AWS::Region}'
FILE_ASSET_PUBLISHING_ROLE_ARN = 'arn:aws:iam::${AWS::AccountId}:role/role-${Qualifier}-file-publishing-role-${AWS::AccountId}-${AWS::Region}'
IMAGE_ASSET_PUBLISHING_ROLE_ARN = 'arn:aws:iam::${AWS::AccountId}:role/role-${Qualifier}-image-publishing-role-${AWS::AccountId}-${AWS::Region}'
CLOUD_FORMATION_EXECUTION_ROLE = 'arn:${AWS::Partition}:iam::${AWS::AccountId}:role/role-${Qualifier}-cfn-exec-role-${AWS::AccountId}-${AWS::Region}'
BOOTSTRAP_STACK_VERSION_SSM_PARAMETER = '/cdk-bootstrap/${Qualifier}/version'

import json
from cdk_2s33_method.cdk_2s33_dashboard import Cdk2s33Dashboard

class LogShippingMonitoringDashboard(Cdk2s33Dashboard):
    def __init__(self, scope, cdk_id: str, cdk_name: str, logs2splunk_bucket_name: str, queue_name: str, region: str):
        super().__init__(scope, cdk_id, cdk_name)
        self.logs2splunk_bucket_name = logs2splunk_bucket_name
        self.queue_name = queue_name
        self.region = region
        self.bucket_markdown="# S3 Bucket logs \n\n" + self.logs2splunk_bucket_name

    def _build_body(self):
        body = {
            "start": "-PT12H",
            "widgets": [
                {
                    "height": 2,
                    "width": 24,
                    "y": 0,
                    "x": 0,
                    "type": "text",
                    "properties": {
                        "markdown": "## FireHose stream\n\n\n\n",
                        "background": "solid"
                    }
                },
                {
                    "height": 6,
                    "width": 8,
                    "y": 2,
                    "x": 0,
                    "type": "metric",
                    "properties": {
                        "metrics": [
                            [ "AWS/Firehose", "ThrottledRecords", "DeliveryStreamName", "2s33-cloudwatch2s3" ]
                        ],
                        "region": self.region,
                        "view": "timeSeries",
                        "stacked": False,
                        "stat": "Sum",
                        "title": "Throttled records (Count)"
                    }
                },
                {
                    "height": 6,
                    "width": 8,
                    "y": 2,
                    "x": 8,
                    "type": "metric",
                    "properties": {
                        "metrics": [
                            [ "AWS/Firehose", "ExecuteProcessing.Duration", "DeliveryStreamName", "2s33-cloudwatch2s3" ]
                        ],
                        "region": self.region,
                        "view": "timeSeries",
                        "stacked": False,
                        "stat": "Average",
                        "title": "Lambda function processing duration (Average)"
                    }
                },
                {
                    "height": 6,
                    "width": 8,
                    "y": 2,
                    "x": 16,
                    "type": "metric",
                    "properties": {
                        "metrics": [
                            [ { "expression": "METRICS(\"m1\") * 100", "id": "e1" } ],
                            [ "AWS/Firehose", "ExecuteProcessing.Success", "DeliveryStreamName", "2s33-cloudwatch2s3", { "id": "m1", "visible": False } ]
                        ],
                        "region": self.region,
                        "view": "timeSeries",
                        "stacked": False,
                        "stat": "Average",
                        "title": "Lambda function processing success",
                        "period": 300,
                        "yAxis": {
                            "left": {
                                "showUnits": False,
                                "label": "Percentage",
                                "min": 0,
                                "max": 100
                            }
                        }
                    }
                },
                {
                    "height": 6,
                    "width": 8,
                    "y": 8,
                    "x": 0,
                    "type": "metric",
                    "properties": {
                        "metrics": [
                            [ "AWS/Firehose", "SucceedProcessing.Records", "DeliveryStreamName", "2s33-cloudwatch2s3" ]
                        ],
                        "region": self.region,
                        "view": "timeSeries",
                        "stacked": False,
                        "stat": "Sum",
                        "title": "Records successfully processed by Lambda function (Sum)"
                    }
                },
                {
                    "height": 6,
                    "width": 8,
                    "y": 8,
                    "x": 8,
                    "type": "metric",
                    "properties": {
                        "metrics": [
                            [ "AWS/Firehose", "SucceedProcessing.Bytes", "DeliveryStreamName", "2s33-cloudwatch2s3" ]
                        ],
                        "region": self.region,
                        "view": "timeSeries",
                        "stacked": False,
                        "stat": "Sum",
                        "title": "Bytes successfully processed by Lambda function (Sum)"
                    }
                },
                {
                    "height": 6,
                    "width": 8,
                    "y": 8,
                    "x": 16,
                    "type": "metric",
                    "properties": {
                        "metrics": [
                            [ "AWS/Firehose", "PartitionCount", "DeliveryStreamName", "2s33-cloudwatch2s3" ]
                        ],
                        "region": self.region,
                        "view": "timeSeries",
                        "stacked": False,
                        "stat": "Maximum",
                        "title": "Partition Count"
                    }
                },
                {
                    "height": 6,
                    "width": 8,
                    "y": 14,
                    "x": 8,
                    "type": "metric",
                    "properties": {
                        "metrics": [
                            [ "AWS/Firehose", "PerPartitionThroughput", "DeliveryStreamName", "2s33-cloudwatch2s3" ]
                        ],
                        "region": self.region,
                        "view": "timeSeries",
                        "stacked": False,
                        "stat": "Maximum",
                        "title": "Per Partition Throughput"
                    }
                },
                {
                    "height": 6,
                    "width": 8,
                    "y": 14,
                    "x": 16,
                    "type": "metric",
                    "properties": {
                        "metrics": [
                            [ "AWS/Firehose", "DeliveryToS3.ObjectCount", "DeliveryStreamName", "2s33-cloudwatch2s3" ]
                        ],
                        "region": self.region,
                        "view": "timeSeries",
                        "stacked": False,
                        "stat": "Sum",
                        "title": "Delivery To S3 Object Count"
                    }
                },
                {
                    "height": 6,
                    "width": 8,
                    "y": 14,
                    "x": 0,
                    "type": "metric",
                    "properties": {
                        "metrics": [
                            [ { "expression": "METRICS(\"m1\") * 100", "id": "e1" } ],
                            [ "AWS/Firehose", "DeliveryToS3.Success", "DeliveryStreamName", "2s33-cloudwatch2s3", { "id": "m1", "visible": False } ]
                        ],
                        "region": self.region,
                        "view": "timeSeries",
                        "stacked": False,
                        "stat": "Average",
                        "title": "Delivery to Amazon S3 success",
                        "period": 300,
                        "yAxis": {
                            "left": {
                                "showUnits": False,
                                "label": "Percentage",
                                "min": 0,
                                "max": 100
                            }
                        }
                    }
                },
                {
                    "height": 6,
                    "width": 8,
                    "y": 20,
                    "x": 8,
                    "type": "metric",
                    "properties": {
                        "metrics": [
                            [ "AWS/Firehose", "DeliveryToS3.DataFreshness", "DeliveryStreamName", "2s33-cloudwatch2s3" ]
                        ],
                        "region": self.region,
                        "view": "timeSeries",
                        "stacked": False,
                        "stat": "Maximum",
                        "title": "Delivery to Amazon S3 data freshness (Maximum)"
                    }
                },
                {
                    "height": 6,
                    "width": 8,
                    "y": 20,
                    "x": 16,
                    "type": "metric",
                    "properties": {
                        "metrics": [
                            [ "AWS/Firehose", "DeliveryToS3.Records", "DeliveryStreamName", "2s33-cloudwatch2s3" ]
                        ],
                        "region": self.region,
                        "view": "timeSeries",
                        "stacked": False,
                        "stat": "Sum",
                        "title": "Records delivered to Amazon S3 (Sum)"
                    }
                },
                {
                    "height": 6,
                    "width": 8,
                    "y": 20,
                    "x": 0,
                    "type": "metric",
                    "properties": {
                        "metrics": [
                            [ "AWS/Firehose", "DeliveryToS3.Bytes", "DeliveryStreamName", "2s33-cloudwatch2s3" ]
                        ],
                        "region": self.region,
                        "view": "timeSeries",
                        "stacked": False,
                        "stat": "Sum",
                        "title": "Bytes delivered to Amazon S3 (Sum)"
                    }
                },
                {
                    "height": 2,
                    "width": 24,
                    "y": 26,
                    "x": 0,
                    "type": "text",
                    "properties": {
                        "markdown": "# Lambda log-processing"
                    }
                },
                {
                    "height": 6,
                    "width": 8,
                    "y": 28,
                    "x": 0,
                    "type": "metric",
                    "properties": {
                        "metrics": [
                            [ "AWS/Lambda", "Duration", "FunctionName", "logs-processing", { "label": "Duration minimum", "stat": "Minimum" } ],
                            [ "...", { "label": "Duration Average" } ],
                            [ "...", { "label": "Duration Maximum", "stat": "Maximum" } ]
                        ],
                        "view": "timeSeries",
                        "stacked": False,
                        "region": self.region,
                        "stat": "Average",
                        "period": 300
                    }
                },
                {
                    "height": 6,
                    "width": 8,
                    "y": 28,
                    "x": 8,
                    "type": "metric",
                    "properties": {
                        "metrics": [
                            [ "AWS/Lambda", "Invocations", "FunctionName", "logs-processing", { "label": "Invocations on 5 minutes span" } ]
                        ],
                        "view": "timeSeries",
                        "stacked": False,
                        "region": self.region,
                        "stat": "Sum",
                        "period": 300
                    }
                },
                {
                    "height": 6,
                    "width": 8,
                    "y": 28,
                    "x": 16,
                    "type": "metric",
                    "properties": {
                        "metrics": [
                            [ "AWS/Lambda", "ConcurrentExecutions", "FunctionName", "logs-processing" ]
                        ],
                        "view": "timeSeries",
                        "stacked": False,
                        "region": self.region,
                        "stat": "Maximum",
                        "period": 300
                    }
                },
                {
                    "height": 6,
                    "width": 12,
                    "y": 34,
                    "x": 0,
                    "type": "metric",
                    "properties": {
                        "metrics": [
                            [ "AWS/Lambda", "Throttles", "FunctionName", "logs-processing" ]
                        ],
                        "view": "timeSeries",
                        "stacked": False,
                        "region": self.region,
                        "period": 300,
                        "stat": "Sum"
                    }
                },
                {
                    "height": 6,
                    "width": 12,
                    "y": 34,
                    "x": 12,
                    "type": "metric",
                    "properties": {
                        "metrics": [
                            [ "AWS/Lambda", "Errors", "FunctionName", "logs-processing", { "id": "m1" } ],
                            [ ".", "Invocations", ".", ".", { "visible": False, "id": "m2" } ],
                            [ { "expression": "100 - 100 * m1 / MAX([m1, m2])", "label": "Expression1", "id": "e1", "region": self.region } ]
                        ],
                        "view": "timeSeries",
                        "stacked": False,
                        "region": self.region,
                        "stat": "Sum",
                        "period": 300
                    }
                },
                {
                    "height": 2,
                    "width": 24,
                    "y": 40,
                    "x": 0,
                    "type": "text",
                    "properties": {
                        "markdown": "# Lambda logs-subscription-manager"
                    }
                },
                {
                    "height": 6,
                    "width": 8,
                    "y": 42,
                    "x": 8,
                    "type": "metric",
                    "properties": {
                        "metrics": [
                            [ "AWS/Lambda", "Duration", "FunctionName", "logs-subscription-manager", { "label": "Duration minimum", "stat": "Minimum" } ],
                            [ "...", { "label": "Duration maximum" } ],
                            [ "...", { "stat": "Average" } ]
                        ],
                        "view": "timeSeries",
                        "stacked": False,
                        "region": self.region,
                        "stat": "Maximum",
                        "period": 300
                    }
                },
                {
                    "height": 6,
                    "width": 8,
                    "y": 42,
                    "x": 0,
                    "type": "metric",
                    "properties": {
                        "metrics": [
                            [ "AWS/Lambda", "Errors", "FunctionName", "logs-subscription-manager" ],
                            [ ".", "Invocations", ".", "." ]
                        ],
                        "view": "timeSeries",
                        "stacked": False,
                        "region": self.region,
                        "stat": "Sum",
                        "period": 300
                    }
                },
                {
                    "height": 2,
                    "width": 24,
                    "y": 48,
                    "x": 0,
                    "type": "text",
                    "properties": {
                        "markdown": "# SQS Queues status"
                    }
                },
                {
                    "height": 2,
                    "width": 24,
                    "y": 56,
                    "x": 0,
                    "type": "text",
                    "properties": {
                        "markdown": self.bucket_markdown
                    }
                },
                {
                    "height": 6,
                    "width": 12,
                    "y": 58,
                    "x": 0,
                    "type": "metric",
                    "properties": {
                        "metrics": [
                            [ "AWS/S3", "NumberOfObjects", "StorageType", "AllStorageTypes", "BucketName", self.logs2splunk_bucket_name, { "region": self.region } ]
                        ],
                        "view": "timeSeries",
                        "stacked": False,
                        "region": self.region,
                        "stat": "Maximum",
                        "period": 3600
                    }
                },
                {
                    "height": 6,
                    "width": 12,
                    "y": 58,
                    "x": 12,
                    "type": "metric",
                    "properties": {
                        "metrics": [
                            [ "AWS/S3", "BucketSizeBytes", "StorageType", "StandardStorage", "BucketName", self.logs2splunk_bucket_name ]
                        ],
                        "view": "timeSeries",
                        "stacked": False,
                        "region": self.region,
                        "period": 3600,
                        "stat": "Maximum"
                    }
                },
                {
                    "height": 6,
                    "width": 8,
                    "y": 50,
                    "x": 0,
                    "type": "metric",
                    "properties": {
                        "metrics": [
                            [ "AWS/SQS", "NumberOfMessagesReceived", "QueueName", self.queue_name ]
                        ],
                        "view": "timeSeries",
                        "stacked": False,
                        "region": self.region,
                        "stat": "Sum",
                        "period": 300,
                        "title": "Dead letter queue NumberOfMessagesReceived"
                    }
                }
            ]
        }
        return json.dumps(body)
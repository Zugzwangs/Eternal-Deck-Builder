from aws_cdk import aws_iam
from cdk_stacks.config import ENV
from cdk_stacks.utils import get_context_by_env, lambda_arn_prefix

context = get_context_by_env(ENV)

policy = {
    "cdkId": "CdkPolicy2s33FireHoseCallLambda",
    "policyName": "cdkPolicy2s33FireHoseCallLambda",
    "statements": [
        {
            "effect": aws_iam.Effect.ALLOW,
            "actions": [
                "lambda:InvokeFunctionUrl",
                "lambda:GetProvisionedConcurrencyConfig",
                "lambda:InvokeFunction",
                "lambda:GetFunctionConcurrency",
                "lambda:GetFunctionConfiguration"
            ],
            "resources": [f"{lambda_arn_prefix}*:{context['accountId']}:function:*"]
        }
    ]
}


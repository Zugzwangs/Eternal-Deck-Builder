from aws_cdk import aws_iam

policy = {
    "cdkId": "CdkPolicy2s33CloudwatchLogs2Splunk",
    "policyName": "cdkPolicy2s33CloudwatchLogs2Splunk",
    "statements": [
        {
            "effect": aws_iam.Effect.ALLOW,
            "actions": [
                "logs:CreateLogGroup",
                "logs:CreateLogStream",
                "logs:PutLogEvents",
                "logs:DescribeLogStreams",                
                "logs:GetLogEvents"
            ],
            "resources": ["*"]
        }
    ]
}


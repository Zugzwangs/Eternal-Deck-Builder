from aws_cdk import aws_iam
from cdk_stacks.config import ENV
from cdk_stacks.utils import get_context_by_env, s3_arn_prefix, logs_arn_prefix, kms_arn_prefix, bucket_naming

context = get_context_by_env(ENV)

policy = {
    "cdkId": "CdkPolicy2s33FireHoseToLogsBucket",
    "policyName": "cdkPolicy2s33FireHoseToLogsBucket",
    "statements": [
        {
            "effect": aws_iam.Effect.ALLOW,
            "actions": [
                "kms:Decrypt",
                "kms:DescribeKey",
                "kms:Encrypt",
                "kms:ReEncrypt*",
                "kms:GenerateDataKey*"
            ],
            "resources": [f"{kms_arn_prefix}{context['region']}:{context['accountId']}:key/*"]
        },
        {
            "effect": aws_iam.Effect.ALLOW,
            "actions": [
                "s3:GetObject*",
                "s3:GetBucket*",
                "s3:List*",
                "s3:DeleteObject*",
                "s3:PutObject*",
                "s3:Abort*"
            ],
            "resources": [  
                f"{s3_arn_prefix}{bucket_naming('logs2splunk',ENV,context['region'])}",
                f"{s3_arn_prefix}{bucket_naming('logs2splunk',ENV,context['region'])}/*"
            ]
        },
        {
            "effect": aws_iam.Effect.ALLOW,
            "actions": [
                "logs:CreateLogGroup",
            ],
            "resources": [f"{logs_arn_prefix}{context['region']}:{context['accountId']}:*"]
        },
        {
            "effect": aws_iam.Effect.ALLOW,
            "actions": [
                "logs:PutLogEvents",
                "logs:CreateLogStream",
            ],
            "resources": [f"{logs_arn_prefix}{context['region']}:{context['accountId']}:log-group:*:*"]
        }
    ]
}


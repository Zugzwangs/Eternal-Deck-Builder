from aws_cdk import aws_iam
from cdk_stacks.config import ENV
from cdk_stacks.utils import get_context_by_env, firehose_arn_prefix

context = get_context_by_env(ENV)

policy = {
    "cdkId": "CdkPolicy2s33CloudWatchStreamToFireHose",
    "policyName": "cdkPolicy2s33CloudWatchStreamToFireHose",
    "statements": [
        {
            "effect": aws_iam.Effect.ALLOW,
            "actions": [
                "firehose:ListDeliveryStreams"
            ],
            "resources": ["*"]
        },
        {
            "effect": aws_iam.Effect.ALLOW,
            "actions": [
                "firehose:*"
            ],           
            "resources": [f"{firehose_arn_prefix}{context['region']}:{context['accountId']}:deliverystream/*"]
        }
    ]
}


from aws_cdk import aws_iam
from cdk_stacks.config import ENV
from cdk_stacks.utils import get_context_by_env, firehose_arn_prefix

context = get_context_by_env(ENV)

policy = {
    "cdkId": "CdkPolicy2s33FirehoseSplunkDatastreamPublishAccess",
    "policyName": "cdkPolicy2s33FirehoseSplunkDatastreamPublishAccess",
    "statements": [
        {
            "effect": aws_iam.Effect.ALLOW,
            "actions": [
                "firehose:DescribeDeliveryStream",
                "firehose:PutRecord",
                "firehose:PutRecordBatch",
                "firehose:ListTagsForDeliveryStream"
            ],
            "resources": [f"{firehose_arn_prefix}{context['region']}:{context['accountId']}:deliverystream/2s33-test-cloudwatch-to-s3"]
        },
        {
            "effect": aws_iam.Effect.ALLOW,
            "actions": [
                "firehose:ListDeliveryStreams"
            ],
            "resources": ["*"]
        }        
    ]
}


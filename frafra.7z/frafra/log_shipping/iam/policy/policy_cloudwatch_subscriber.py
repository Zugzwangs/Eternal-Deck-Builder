from aws_cdk import aws_iam
from cdk_stacks.config import ENV
from cdk_stacks.utils import get_context_by_env, iam_arn_prefix, logs_arn_prefix

context = get_context_by_env(ENV)

policy = {
    "cdkId": "CdkPolicy2s33CloudwatchSubscriber",
    "policyName": "cdkPolicy2s33CloudwatchSubscriber",
    "statements": [
        {
            "effect": aws_iam.Effect.ALLOW,
            "actions": [                
                "logs:DescribeQueries",
                "logs:GetLogRecord",
                "logs:PutDestinationPolicy",
                "logs:StopQuery",
                "logs:TestMetricFilter",
                "logs:DeleteDestination",
                "logs:DeleteQueryDefinition",
                "logs:PutQueryDefinition",
                "logs:GetLogDelivery",
                "logs:ListLogDeliveries",
                "logs:CreateLogDelivery",
                "logs:DeleteResourcePolicy",
                "logs:PutResourcePolicy",
                "logs:DescribeExportTasks",
                "logs:GetQueryResults",
                "logs:UpdateLogDelivery",
                "logs:CancelExportTask",
                "logs:DeleteLogDelivery",
                "logs:DescribeQueryDefinitions",
                "logs:PutDestination",
                "logs:DescribeResourcePolicies",
                "logs:DescribeDestinations"                
            ],
            "resources": ["*"]
        },
        {
            "effect": aws_iam.Effect.ALLOW,
            "actions": [
                "iam:PassRole",
                "logs:*"
            ],
            "resources": [
                f"{iam_arn_prefix}{context['accountId']}:role/Cdk2s33RoleCloudWatchLogsToFireHose",
                f"{logs_arn_prefix}*:{context['accountId']}:log-group:*"
            ]
        },
        {
            "effect": aws_iam.Effect.ALLOW,
            "actions": [
                "logs:*"
            ],
            "resources": [
                f"{logs_arn_prefix}*:{context['accountId']}:log-group:*:log-stream:*",
                f"{logs_arn_prefix}*:{context['accountId']}:destination:*"
            ]
        }        
    ]
}


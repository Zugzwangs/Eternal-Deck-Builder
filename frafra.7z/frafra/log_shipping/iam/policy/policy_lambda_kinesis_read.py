from aws_cdk import aws_iam

policy = {
    "cdkId": "CdkPolicy2s33LambdaKinesisExecutionRole",
    "policyName": "cdkPolicy2s33LambdaKinesisExecutionRole",
    "statements": [
        {
            "effect": aws_iam.Effect.ALLOW,
            "actions": [
                "kinesis:DescribeStream",
                "kinesis:DescribeStreamSummary",
                "kinesis:GetRecords",
                "kinesis:GetShardIterator",
                "kinesis:ListShards",
                "kinesis:ListStreams",
                "kinesis:SubscribeToShard",
                "logs:CreateLogGroup",
                "logs:CreateLogStream",
                "logs:PutLogEvents"
            ],
            "resources": ["*"]
        }       
    ]
}

    
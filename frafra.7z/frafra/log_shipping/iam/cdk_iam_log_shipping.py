from aws_cdk import (
    NestedStack,
    aws_iam,
    CfnOutput,
    Duration
)
from constructs import Construct

from cdk_stacks.config import ENV
from cdk_stacks.utils import (
    iam_arn_prefix,
    aws_iam_role,
    aws_iam_role_cfn,
    firehose_arn_prefix,
    handle_policy_creation,
    add_managed_policy,
    handle_role_creation
)

from cdk_stacks.log_shipping.iam.policy import (
    policy_cloudwatch_logs_2_splunk,
    policy_cloudwatch_stream_firehose,
    policy_cloudwatch_subscriber,
    policy_firehose_call_lambda,
    policy_firehose_splunk_datastream,
    policy_firehose_to_bucket,
    policy_lambda_kinesis_read
)


# check policies
# policy_cloudwatch_logs ok
# policy_cloudwatch_stream_firehose
#

class CdkLogShippingIam(NestedStack):

    def __init__(self, scope: Construct, construct_id: str, **kwargs) -> None:
        super().__init__(scope, construct_id, **kwargs)

        #############################
        # get context               #
        #############################
        self.context = self.node.try_get_context(ENV)

        #############################
        # Global configuration data #
        #############################
        # TODO : implement condition to assumeRome for role_cloudwatch_firehose (https://confluence.airbus.corp/display/Z2S33INPR/Log+Shipping+to+RTM+Splunk)
        self.configuration_data = {
            "policy": {
                "policy_cloudwatch_logs_2_splunk": policy_cloudwatch_logs_2_splunk.policy,
                "policy_cloudwatch_stream_firehose": policy_cloudwatch_stream_firehose.policy,
                "policy_cloudwatch_subscriber": policy_cloudwatch_subscriber.policy,
                "policy_firehose_call_lambda": policy_firehose_call_lambda.policy,
                "policy_firehose_splunk_datastream": policy_firehose_splunk_datastream.policy,
                "policy_firehose_to_bucket": policy_firehose_to_bucket.policy,
                "policy_lambda_kinesis_read": policy_lambda_kinesis_read.policy
            },
            # TODO CHANGE ROLE DEFINITION
            "role": {
                "role_lambda_basic": {
                    "constructor": aws_iam_role,
                    "cdkId": "Cdk2s33RoleForBasicLambda",
                    "assumedBy": "lambda.amazonaws.com",
                    "roleName": "Cdk2s33RoleForBasicLambda",
                    "managedPolicies": {
                        "inbuilt": [
                            "policy_cloudwatch_logs_2_splunk"
                        ]
                    }
                },
                "role_lambda_subscriber": {
                    "constructor": aws_iam_role,
                    "cdkId": "Cdk2s33RoleForSubscriberLambda",
                    "assumedBy": "lambda.amazonaws.com",
                    "roleName": "Cdk2s33RoleForSubscriberLambda",
                    "managedPolicies": {
                        "inbuilt": [
                            "policy_cloudwatch_subscriber"
                        ]
                    }
                },
                "role_cloudwatch_firehose": {
                    "constructor": aws_iam_role,
                    "cdkId": "Cdk2s33RoleCloudWatchLogsToFireHose",
                    "assumedBy": "logs.eu-west-1.amazonaws.com",
                    "roleName": "Cdk2s33RoleCloudWatchLogsToFireHose",
                    "managedPolicies": {
                        "inbuilt": [
                            "policy_cloudwatch_stream_firehose"
                        ]
                    }
                },
                "role_firehose_stream_s3": {
                    "constructor": aws_iam_role,
                    "cdkId": "Cdk2s33RoleFireHoseLogsStreaming",
                    "assumedBy": "firehose.amazonaws.com",
                    "roleName": "Cdk2s33RoleFireHoseLogsStreaming",
                    "managedPolicies": {
                        "inbuilt": [
                            "policy_firehose_to_bucket",
                            "policy_firehose_call_lambda"
                        ]
                    }
                },
                "role_lambda_firehose_transformation": {
                    "constructor": aws_iam_role,
                    "cdkId": "Cdk2s33RoleFireHoseLambdaTransformation",
                    "assumedBy": "lambda.amazonaws.com",
                    "roleName": "Cdk2s33RoleFireHoseLambdaTransformation",
                    "managedPolicies": {
                        "inbuilt": [
                            "policy_firehose_splunk_datastream",
                            "policy_lambda_kinesis_read"
                        ]
                    }
                }
            }
        }

        #############################
        # Resources creation        #
        #############################
      
        ### IAM Policies
        self.policy_container = {}
        for policy, policy_props in self.configuration_data["policy"].items():
            self.policy_container[policy] = handle_policy_creation(
                self,
                resource_id=policy_props["cdkId"],
                policy_name=policy_props["policyName"],
                statements_list=policy_props["statements"],
                description=policy_props["description"] if "description" in policy_props else None
            )

        ### IAM Roles
        self.role_container = {}
        for role, role_props in self.configuration_data["role"].items():
            self.role_container[role] = handle_role_creation(self, role_props)
            


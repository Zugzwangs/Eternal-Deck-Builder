"""
### TODO ###
    - (-) create the cloudwatch monitoring dashboard 
    - (-) create more SSM parameters for all SQS+DLQ and maybe the 'control table'
    - (-) refactor lambda log-processing (enhance log transformation, variable naming, more comments, complete README)
    - (-) think about '"sqs_suffix_name": "None"' with boolean instead string for None
---------------------------------------------------------------------------------------------------------
    - (✓) implement test mode in lambda log-suscription-manager to help add more log groups. 
    - (✓) create and use a KMS key for SQS <= default AWS Key for now
    - (✓) create tests event for all the lambdas => no straightforward option to do that i use README file as helper
    - (✓) make sure log-subscription-manager handle regex for logs-group 
    - (✓) enable dynamic partitioning in the firehose stream
    - (✓) rework lambda log-processing to handle the dynamic partitioning
    - (✓) create a dynamic number of S3 notifications settings for each logs type
    - (✓) create a dynamic number of SQS queues for each logs s3 notifications set
    - (✓) create s3 lifecycle rule to expire logs files after 2 weeks
    - (✓) create SSM parameters to store/share buckets/queues references
    - (✓) accounts Ids 087244168513 || 804338691354 || 792769672142 => no required anymore
    - (✓) create dead letter queue
    - (✓) interdependences between bucket and sqs
    - (✓) review IAM nested stack - check if no policies/roles/permissions are missing
    - (✓) logsBucketKmsKeyArn is hard coded and with wrong value 
    - (✓) implement utils.handle_firehose_datasteam_creation()
    - (✓) delete every resources in DEV
    - (✓) finish logs-subscription-manager manager implementation
    - (✓) review all manually created resources in DEV to make sure everything is define/build in this stack
    - (✓) extend utils.handle_bucket_creation() with add 'notifications' settings
    - (✓) IAM Role and Policies creation functions need moved to utils.py
    - (✓) define a stack dictionary attribute for customization options (naming and settings...)
"""
import json
import os
from pathlib import Path

from aws_cdk import (Stack, Tags, aws_iam, aws_lambda, aws_sqs)
from constructs import Construct

from cdk_stacks.config import ENV
from cdk_stacks.log_shipping.dashboards.log_shipping_monitoring import LogShippingMonitoringDashboard
from cdk_stacks.log_shipping.iam.cdk_iam_log_shipping import CdkLogShippingIam
from cdk_stacks.utils import (
    ssm_base_path,
    bucket_naming,
    iam_arn_prefix,
    s3_arn_prefix,
    firehose_arn_prefix,
    sqs_arn_prefix,
    lambda_arn_prefix,
    aws_events_rule,
    aws_iam_role,
    retrieve_role_attr,
    handle_bucket_creation,
    handle_kms_key_creation,
    handle_lambda_function_creation,
    handle_events_rule_creation,
    handle_cfn_sqs_queue_creation,
    handle_policy_statement_creation,
    handle_firehose_datastream_creation,
    handle_ssm_parameter_creation
)

STACK_DIR = os.path.dirname(os.path.abspath(__file__))


class CdkLogShipping(Stack):
    def __init__(self, scope: Construct, construct_id: str, layer_container, **kwargs) -> None:
        super().__init__(scope, construct_id, **kwargs)

        #######################################################################
        # get context and set class variables                                 #
        # layer_custom_logging is the only one dependency of the stack        
        ####################################################################### 
        self.context = self.node.try_get_context(ENV)
        self.layer_container = layer_container

        #######################################################################
        # General Stack configuration                                         #
        #######################################################################

        # log shipping settings (logs groups, filters and more)
        # you MUST define all fields in the Filters list (log_group, filter, partition, sqs_suffix_name)
        # if multiple lines have the same 'sqs_suffix_name' value, only one SQS queue will be created
        # also "partition" have some limitations -overlapping- has there are used as prefix filter rule for s3 notifications (see https://docs.aws.amazon.com/AmazonS3/latest/userguide/notification-how-to-filtering.html)
        # changing sqs_suffix_name CAN BREAK the Splunk collect as the SQS URL has to be set on Splunk inputs.conf
        self.stack_settings = {
            "Filters": [
                {
                    "log_group": "/aws/lambda/logs-generator",
                    "filter": "?WARNING ?ERROR",
                    "partition": "TEST",
                    "sqs_suffix_name": "None"
                },
                {
                    "log_group": "\/2s33\/computing\/algorithm\/ac_.{0,3}_2s33",
                    "filter": "?WARNING ?ERROR ?INFO",
                    "partition": "COMPUTING",
                    "sqs_suffix_name": "algo"
                },
                {
                    "log_group": "/2s33/nifi/nifi-user",
                    "filter": "?WARNING ?ERROR ?INFO",
                    "partition": "NIFI-USER",
                    "sqs_suffix_name": "nifiuser"
                },
            ]
        }

        # resources names (buckets, lambdas, queues, streams...)
        self.stack_names = {
            "Logs2SplunkBucketName": "logs2splunk",
            "KmsAliasKeyName": "alias/cdk/logBucket/s3",
            "FirehoseDeliveryStreamName": "2s33-cloudwatch2s3",
            "SqsDeadLetterQueueName": f"sqs-2s33-{ENV}-logs2splunk-dlq-{self.context['accountId']}-{self.context['region']}",
            "LambdaLogsGeneratorName": "logs-generator",
            "LambdaLogTransformName": "logs-processing",
            "LambdaSubscriptionManagerName": "logs-subscription-manager",
            "LogSubscriptionName": "2s33-CloudWatchSubscriptionLogsToSplunk"
        }

        # inferred resources ARNs 
        self.stack_arns = {
            "Logs2SplunkBucketArn": f"{s3_arn_prefix}{bucket_naming(self.stack_names['Logs2SplunkBucketName'], ENV, self.context['region'])}",
            "FirehoseDeliveryStreamArn": f"{firehose_arn_prefix}{self.context['region']}:{self.context['accountId']}:deliverystream/{self.stack_names['FirehoseDeliveryStreamName']}",
            "SqsDeadLetterQueueArn": f"{sqs_arn_prefix}{self.context['region']}:{self.context['accountId']}:{self.stack_names['SqsDeadLetterQueueName']}",
            "LogsProcessingArn": f"{lambda_arn_prefix}{self.context['region']}:{self.context['accountId']}:function:{self.stack_names['LambdaLogTransformName']}"
        }

        #######################################################################
        # NESTED STACK for IAM Roles and Policies                             #
        #######################################################################
        self.CdkLogShippingIamNestedStack = CdkLogShippingIam(
            self,
            "CdkLogShippingIam"
        )
        # allow retrieve_role_attr() to access role container through the 'self' param
        self.role_container = self.CdkLogShippingIamNestedStack.role_container

        #######################################################################
        # SQS CREATION                                                        #
        #######################################################################
        # first create the common Dead Letter Queue
        self.sqs_deadletterqueue_configuration = {
            "common_deadletter_queue": {
                "cdkId": "CdkDlqSqsLogs2SplunkNotif",
                "queueName": f"{self.stack_names['SqsDeadLetterQueueName']}",
                "fifoQueue": False,
                "retentionPeriodSeconds": 3600,
                "receiveMessageWaitTimeSeconds": 10,
                "visibilityTimeoutSeconds": 600,
                "contentBasedDeduplication": None,
            }
        }

        self.deadlettersqs_queue_container = {}
        for sqs_queue, sqs_queue_props in self.sqs_deadletterqueue_configuration.items():
            self.deadlettersqs_queue_container[sqs_queue] = handle_cfn_sqs_queue_creation(self, sqs_queue_props)

            # generate a SQS configuration for each destinations declared in stack_settings{}:
        self.sqs_queue_configuration = {}
        for current_destination in self.stack_settings["Filters"]:
            if current_destination['sqs_suffix_name'] != "None":
                self.sqs_queue_configuration[current_destination['sqs_suffix_name']] = {
                    "cdkId": f"CdkSqsL2s{current_destination['sqs_suffix_name'].title()}",
                    "queueName": f"sqs-2s33-{ENV}-l2s-{current_destination['sqs_suffix_name']}-{self.context['accountId']}-{self.context['region']}",
                    "fifoQueue": False,
                    "retentionPeriodSeconds": 3600,
                    "receiveMessageWaitTimeSeconds": 10,
                    "visibilityTimeoutSeconds": 600,
                    "redrive_policy": {
                        "deadLetterTargetArn": self.stack_arns["SqsDeadLetterQueueArn"],
                        "maxReceiveCount": 10
                    },
                }

        self.sqs_queue_container = {}
        for sqs_queue, sqs_queue_props in self.sqs_queue_configuration.items():
            self.sqs_queue_container[sqs_queue] = handle_cfn_sqs_queue_creation(self, sqs_queue_props)
            # queue required the DLQ to exists first
            self.sqs_queue_container[sqs_queue].add_depends_on(
                self.deadlettersqs_queue_container["common_deadletter_queue"]
            )

        #######################################################################
        # QUEUE POLICY CREATION                                               #
        #######################################################################

        # prepare a policy document for each SQS object created before
        self.queue_policy_configuration = {}
        for sqs_queue_index, sqs_queue_object in self.sqs_queue_container.items():
            self.queue_policy_configuration[sqs_queue_index] = [
                {
                    "sid": "allow s3 to push notifications",
                    "effect": aws_iam.Effect.ALLOW,
                    "principals": [
                        aws_iam.ServicePrincipal("s3.amazonaws.com")
                    ],
                    "actions": [
                        "sqs:SendMessage",
                        "sqs:GetQueueAttributes",
                        "sqs:GetQueueUrl"
                    ],
                    "resources": [
                        sqs_queue_object.attr_arn
                    ],
                    "conditions": {
                        "stringEquals": {
                            "aws:SourceAccount": self.context['accountId']
                        },
                        "noBoolSecureTransportCondition": True
                    }
                },
                {
                    "sid": "allow Splunk consumer to read notifications",
                    "effect": aws_iam.Effect.ALLOW,
                    "principals": [
                        aws_iam.ArnPrincipal(
                            f'{iam_arn_prefix}{self.context["accountId"]}:role/role-splunk-aws-collect'
                        )
                    ],
                    "actions": [
                        "sqs:ReceiveMessage",
                        "sqs:GetQueueAttributes",
                        "sqs:DeleteMessage",
                        "sqs:GetQueueUrl"
                    ],
                    "resources": ["*"]
                }
            ]

        # create the policy and attach them to their respectives queues
        self.sqs_queue_policy_container = {}
        for queue_policy, queue_policy_props in self.queue_policy_configuration.items():
            statements = []
            for queue_policy_statement in queue_policy_props:
                policy_statement_created = handle_policy_statement_creation(self, statement=queue_policy_statement)
                statements.append(policy_statement_created)

            # compile all policies statements into a policy document
            current_policy_document = aws_iam.PolicyDocument(statements=statements)

            # apply the policy document to the relevant SQS queue
            self.sqs_queue_policy_container[queue_policy] = aws_sqs.CfnQueuePolicy(
                self,
                f"Cdk{queue_policy.title()}",
                policy_document=current_policy_document,
                queues=[self.sqs_queue_container[queue_policy].attr_queue_url]
            )
            # explicit dependency
            self.sqs_queue_policy_container[queue_policy].add_depends_on(
                self.sqs_queue_container[queue_policy]
            )

        #######################################################################
        # KMS CREATION                                                        #
        #######################################################################
        self.kms_configuration = {
            "logs2splunk_bucket": {
                "kmsKeyDescription": "Symmetric CMK used to secure data on logs transit bucket.",
                "cdkId": "CdkLogs2SplunkKey",
                "kmsKeyAliasId": "CdkLogs2SplunkKeyAlias",
                "kmsKeyAliasName": self.stack_names["KmsAliasKeyName"],
                "kmsRoleAuthorized": [
                    {"roleKey": "role_firehose_stream_s3", "roleConstructor": aws_iam_role}
                ],
                "kmsPrincipalAuthorized": [
                    aws_iam.ArnPrincipal(f'{iam_arn_prefix}{self.context["accountId"]}:role/role-splunk-aws-collect')
                ]
            }
        }

        self.kms_container = {}
        self.alias_container = {}
        for kms_name, kms_props in self.kms_configuration.items():
            self.kms_container[kms_name], self.alias_container[kms_name] = handle_kms_key_creation(self, kms_props)

        #######################################################################
        # BUCKETS CREATION 
        #######################################################################

        # compile queue notifications settings: we map each SQS destination created with the correct prefix filter
        queue_notification_configurations = []
        for sqs_queue_index, sqs_queue_object in self.sqs_queue_container.items():
            for current_filter in self.stack_settings["Filters"]:
                if current_filter["sqs_suffix_name"] == sqs_queue_index:
                    queue_notification_configurations.append(
                        {
                            "event": "s3:ObjectCreated:*",
                            "queue": sqs_queue_object.attr_arn,
                            "filterPropertyName": "prefix",
                            "filterPropertyValue": current_filter["partition"]
                        }
                    )

        # generate logs bucket configuration
        self.bucket_configuration = {
            "logs2splunk_bucket": {
                "cdkId": "CdkLogs2SplunkBucket",
                "customBucketName": bucket_naming(
                    self.stack_names['Logs2SplunkBucketName'], ENV, self.context['region']
                ),
                "bucketPolicyId": "CdkLogs2SplunkBucketPolicy",
                "lifecycleConfiguration": [
                    {
                        "id": "DeletionAfterOneWeek",
                        "prefix": "",
                        "expirationInDays": 14,
                        "nonCurrentVersionExpirationInDays": 1
                    }
                ],
                "bucketRoleAuthorized": [
                    {"roleKey": "role_firehose_stream_s3", "roleConstructor": aws_iam_role},
                ],
                "policyStatement": [
                    {
                        "sid": "Custom - Allow list and get to role-splunk-aws-collect",
                        "effect": aws_iam.Effect.ALLOW,
                        "principals": [
                            aws_iam.ArnPrincipal(
                                f'{iam_arn_prefix}{self.context["accountId"]}:role/role-splunk-aws-collect')
                        ],
                        "actions": [
                            "s3:ListBucket",
                            "s3:GetObject"
                        ],
                        "resources": [
                            self.stack_arns["Logs2SplunkBucketArn"],
                            f"{self.stack_arns['Logs2SplunkBucketArn']}/*"
                        ]
                    }
                ],
                "event_notifications_properties": {
                    "queue_configurations": queue_notification_configurations
                }
            }
        }

        # create the log Bucket
        self.bucket_container = {}
        for bucket_name, bucket_props in self.bucket_configuration.items():
            self.bucket_container[bucket_name] = handle_bucket_creation(
                self,
                bucket_props,
                kms_key=self.kms_container[bucket_name]
            )

        # bucket explicit dependency to each SQS notification queues
        for sqs_queue_index, sqs_queue_object in self.sqs_queue_container.items():
            self.bucket_container["logs2splunk_bucket"]["bucket"].add_depends_on(sqs_queue_object)
            self.bucket_container["logs2splunk_bucket"]["bucket"].add_depends_on(
                self.sqs_queue_policy_container[sqs_queue_index]
            )

        #######################################################################
        # LAMBDA CREATION                                                     #
        #######################################################################
        self.lambda_configuration = {
            "logs_generator": {
                "cdkId": "CdkLambdaLogsGenerator",
                "functionName": self.stack_names["LambdaLogsGeneratorName"],
                "handler": "main.lambda_handler",
                "role": self.CdkLogShippingIamNestedStack.role_container["role_lambda_basic"],
                "codePath": f"{Path(STACK_DIR)}/lambda_code/logs-generator",
                "layers": [
                    self.layer_container["layer_custom_logging"]
                ],
                "environmentVariables": {
                    "REGION": self.context["region"],
                    "LOGGING_LEVEL": "INFO",
                },
                "runtime": aws_lambda.Runtime.PYTHON_3_8,
                "timeout": 600
            },
            "logs_processing": {
                "cdkId": "CdkLambdaLogTransform",
                "functionName": self.stack_names["LambdaLogTransformName"],
                "handler": "main.lambda_handler",
                "role": self.CdkLogShippingIamNestedStack.role_container["role_lambda_firehose_transformation"],
                "codePath": f"{Path(STACK_DIR)}/lambda_code/logs-processing",
                "layers": [
                    self.layer_container["layer_custom_logging"]
                ],
                "environmentVariables": {
                    "REGION": self.context["region"],
                    "LOGGING_LEVEL": "INFO",
                    "LOG_GROUP_PARTITIONS": json.dumps(self.stack_settings["Filters"]),
                },
                "runtime": aws_lambda.Runtime.PYTHON_3_8,
                "timeout": 300,
                "memorySize": 256,
                "reservedConcurrentExecutions": 40
            },
            "logs-subscription-manager": {
                "cdkId": "CdkLambdaSubscriptionManager",
                "functionName": self.stack_names["LambdaSubscriptionManagerName"],
                "handler": "main.handler",
                "role": self.CdkLogShippingIamNestedStack.role_container["role_lambda_subscriber"],
                "codePath": f"{Path(STACK_DIR)}/lambda_code/logs-subscription-manager",
                "layers": [
                    self.layer_container["layer_custom_logging"]
                ],
                "environmentVariables": {
                    "REGION": self.context["region"],
                    "LOGGING_LEVEL": "INFO",
                    "DESTINATION_ARN": self.stack_arns["FirehoseDeliveryStreamArn"],
                    "SUBSCRIPTION_NAME": self.stack_names["LogSubscriptionName"],
                    "SUBSCRIPTION_IAM_ROLE": retrieve_role_attr(
                        self.CdkLogShippingIamNestedStack,
                        "arn",
                        {"roleKey": "role_cloudwatch_firehose", "roleConstructor": aws_iam_role}),
                    "LOG_GROUP_FILTERS": json.dumps(self.stack_settings["Filters"]),
                    "TRANSFORM_LAMBDA_NAME": self.stack_names["LambdaLogTransformName"]
                },
                "runtime": aws_lambda.Runtime.PYTHON_3_8,
                "timeout": 300
            },
        }

        self.lambda_container = {}
        for lambda_function, lambda_props in self.lambda_configuration.items():
            self.lambda_container[lambda_function] = handle_lambda_function_creation(self, lambda_props)

        #######################################################################
        # EVENT RULES Creation                                                #
        #######################################################################
        self.events_rule_configuration = {
            "start_log_subs_manager": {
                "cdkId": "CdkEventsRuleStartLogSubsManager",
                "constructor": aws_events_rule,
                "ruleName": "start-log-subs-manager",
                "enabled": True,
                "schedule": "0 7 * * ? *",
                "targets": [
                    self.lambda_container["logs-subscription-manager"],
                ]
            }
        }

        self.events_rule_container = {}
        for events_rule, events_rule_props in self.events_rule_configuration.items():
            self.events_rule_container[events_rule] = handle_events_rule_creation(
                self,
                events_rule_props=events_rule_props
            )

        #######################################################################
        # FIREHOSE CREATION                                                   #
        # TODO
        # how to set transformation timeout to 4 minutes ?
        #######################################################################
        self.firehose_configuration = {
            "splunk_firehose": {
                "cdkId": "CdkLogs2SplunkDeliveryStream",
                "deliveryStreamName": self.stack_names["FirehoseDeliveryStreamName"],
                "deliveryStreamType": "DirectPut",
                "ExtendedS3DestinationConfiguration": {
                    "role_arn": retrieve_role_attr(
                        self,
                        "arn",
                        {"roleKey": "role_firehose_stream_s3", "roleConstructor": aws_iam_role}
                    ),
                    "bucket_arn": self.bucket_container["logs2splunk_bucket"]["bucket"].attr_arn,
                    "interval_in_seconds": 120,
                    "size_in_mBs": 128,
                    "CloudWatchLogging": True,
                    "logGroupName": f"/aws/kinesisfirehose/{self.stack_names['FirehoseDeliveryStreamName']}",
                    "logStreamName": "DestinationDelivery",
                    "lambda_processor_arn": self.stack_arns["LogsProcessingArn"],
                    "dynamicPartitioningConfiguration": {
                        "dynamicPartitionRetry": 300
                    },
                    "prefix": "!{partitionKeyFromLambda:sourcetype}/!{partitionKeyFromLambda:year}/!{partitionKeyFromLambda:month}/!{partitionKeyFromLambda:day}/!{partitionKeyFromLambda:hour}/",
                    "errorPrefix": "ERROR/"
                }
            }
        }
        self.firehose_container = {}
        for firehose_stream_name, firehose_props in self.firehose_configuration.items():
            self.firehose_container[firehose_stream_name] = handle_firehose_datastream_creation(self, firehose_props)
            self.firehose_container[firehose_stream_name].add_depends_on(
                self.bucket_container["logs2splunk_bucket"]["bucket"]
                )

        #######################################################################
        # SSM CREATION                                                        #
        # TODO  add all sqs queues/the control table as well ?                #
        #######################################################################
        self.ssm_configuration = {
            "bucket_param": {
                "cdkId": "CdkSsmLogs2SplunkBucketName",
                "ssmParameterDescription": "Platform logs transit bucket name parameter.",
                "ssmParameterName": f'{ssm_base_path}bucket/logs2splunk',
                "ssmParameterTier": "Standard",
                "ssmParameterType": "String",
                "ssmParameterValue": bucket_naming(
                    self.stack_names['Logs2SplunkBucketName'], ENV, self.context['region']
                )
            },
            "firehose_param": {
                "cdkId": "CdkSsmFirehoseStreamName",
                "ssmParameterDescription": "Name of the firehose data stream serving logs to the log2splunk bucket.",
                "ssmParameterName": f'{ssm_base_path}firehose/logs2splunk',
                "ssmParameterTier": "Standard",
                "ssmParameterType": "String",
                "ssmParameterValue": self.stack_names["FirehoseDeliveryStreamName"]
            }
        }

        # create parameters to manifest some characteristics of the 
        self.ssm_container = {}
        for ssm_container_index, ssm_container_props in self.ssm_configuration.items():
            self.ssm_container[ssm_container_index] = handle_ssm_parameter_creation(
                self,
                value=ssm_container_props["ssmParameterValue"],
                ssm_props=ssm_container_props
            )

        #######################################################################
        # DASHBOARD CREATION                                                  #
        # TODO                                                                #        
        #######################################################################
        self.dashboard_configuration = {
            "log-shipping-monitoring": {
                "cdkId": "CdkCloudwatchDashboardLogShippingMonitoring",
                "name": "log-shipping-monitoring"
            }
        }

        self.dashboard_container = {
            "log-shipping-monitoring": LogShippingMonitoringDashboard(
                scope=self,
                cdk_id=self.dashboard_configuration["log-shipping-monitoring"]["cdkId"],
                cdk_name=self.dashboard_configuration["log-shipping-monitoring"]["name"],
                logs2splunk_bucket_name=bucket_naming(self.stack_names['Logs2SplunkBucketName'], ENV, self.context['region']),
                queue_name=self.stack_names["SqsDeadLetterQueueName"],
                region=self.context['region']
            ).get_dashboard()
        }

        #######################################################################
        # Tags for the stack                                                  #
        #######################################################################
        Tags.of(self).add("airbus:application-code", self.context["applicationCode"])
        Tags.of(self).add("airbus:environment", ENV)
        Tags.of(self).add("2s33:service-type", "log-shipping")

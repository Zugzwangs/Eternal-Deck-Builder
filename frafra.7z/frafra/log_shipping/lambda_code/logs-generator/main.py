import os
import json
from custom_logging_2s33.insider_protection_logging import InsiderProtectionLogging
import time
import string,random

LOGGING_LEVEL = os.environ["LOGGING_LEVEL"]
logger = InsiderProtectionLogging(__name__, LOGGING_LEVEL).logger

DURATION = 60       #default duration in seconds
LENGTH = 100        #default message characters length
BATCH_SIZE = 100    #default logs number
MAX_LOG_COUNT_GENERATION = 100000  #max cap


"""
generate logs during [generation_duration] secondes for a given [log_level].
log_lenth is the number of random character puts in the payload of the log line
"""
def timeBoundLogsGeneration(generation_duration, log_lenth, log_level):

    i=0
    start = time.time()
    if log_level == "info":
        selectedLogger = logger.info
    elif log_level == "warning":
        selectedLogger = logger.warning
    elif log_level == "error":
        selectedLogger = logger.error
    else:
        logger.error(f"unknownlog level passed to timeBoundLogsGeneration function")
        return False

    ### LOG GENERATION        
    while (time.time()-start) < generation_duration:
        log_text = ''.join(random.choice(string.ascii_lowercase) for _ in range(log_lenth))
        selectedLogger(f"generated: {log_text}")
        i+=1

    logger.info(f"{i} logs have been generated in {time.time()-start} seconds")
    return True

"""
generate [logs_count] lines of logs with a given [log_level].
log_lenth is the number of random character puts in the payload of the log line
"""
def countBoundLogsGeneration(logs_count, log_lenth, log_level):

    i=0
    start = time.time()
    if log_level == "info":
        selectedLogger = logger.info
    elif log_level == "warning":
        selectedLogger = logger.warning
    elif log_level == "error":
        selectedLogger = logger.error
    else:
        logger.error(f"unknownlog level passed to countBoundLogsGeneration function")
        return False
    
    ### LOG GENERATION
    for iteration in list(range(logs_count)):
        log_text = ''.join(random.choice(string.ascii_lowercase) for _ in range(log_lenth))
        selectedLogger(f"generated: {log_text}")
        i+=1

    logger.info(f"{i} logs have been generated in {time.time()-start} seconds")
    return True


def lambda_handler(event, context):

    logger.info(f"Lambda startup...")

    try:
        selected_method = event["method"]
        selected_weight = int(event["weight"])
        selected_level = event["level"]
        logger.info(f"settings: method {selected_method}, weight: {selected_weight}, log level: {selected_level}")
        
        # check method 
        if not selected_method in ["time","count"]:
            logger.warning(f"selected method {selected_method} is not allowed.")
            return False
        else:
            logger.info(f"method {selected_method} is correct")
        # check log level
        if not selected_level in ["info","warning","error"]:
            logger.warning(f"required log level {selected_level} is not allowed.")
            return False
        else:
            logger.info(f"log level {selected_level} is correct")
            
        ### TIME BASED
        if selected_method == 'time':
            remainingTimeInMilliSeconds = context.get_remaining_time_in_millis()
            remainingTimeInSeconds = remainingTimeInMilliSeconds/1000
            if (selected_weight*1000) > (remainingTimeInMilliSeconds-5):
                logger.warning(f"required duration {selected_weight}s is to long for the lambda remaining TTL {remainingTimeInSeconds}s.")
                return False
            elif selected_weight <= 0:
                logger.warning(f"null or negative duration {selected_weight}s is not allowed.")
                return False     
            else:
                logger.info(f"Starting logs generation for {selected_weight} secondes...")
                timeBoundLogsGeneration(selected_weight, LENGTH, selected_level)
        
        ### COUNT BASED 
        elif selected_method == 'count':
            if selected_weight > MAX_LOG_COUNT_GENERATION:
                logger.warning(f"required logs count {selected_weight} is too high, set to the maximum allowed {MAX_LOG_COUNT_GENERATION} instead.")
                selected_weight = MAX_LOG_COUNT_GENERATION
            logger.info(f"Starting logs generation for {selected_weight} lines...")
            countBoundLogsGeneration(selected_weight, LENGTH, selected_level)
        
        
        ### CATCHUP CASE
        else:
            logger.warning(f"unknown selected method {selected_method}")

        return True

    except:
        logger.error(f"event passed to the lambda is incorrect!")
        return False


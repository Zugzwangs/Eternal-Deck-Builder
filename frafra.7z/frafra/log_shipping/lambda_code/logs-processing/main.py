import os
import traceback
import base64
import json
import gzip
from io import BytesIO
import boto3
from datetime import datetime, timezone
import re
from custom_logging_2s33.insider_protection_logging import InsiderProtectionLogging

"""
For processing data sent to Firehose by Cloudwatch Logs subscription filters.
Cloudwatch Logs sends to Firehose records that look like this:

{
  "messageType": "DATA_MESSAGE",
  "owner": "123456789012",
  "logGroup": "log_group_name",
  "logStream": "log_stream_name",
  "subscriptionFilters": [
    "subscription_filter_name"
  ],
  "logEvents": [
    {
      "id": "01234567890123456789012345678901234567890123456789012345",
      "timestamp": 1510109208016,
      "message": "log message 1"
    },
    {
      "id": "01234567890123456789012345678901234567890123456789012345",
      "timestamp": 1510109208017,
      "message": "log message 2"
    }
    ...
  ]
}

The data is additionally compressed with GZIP.

NOTE: It is suggested to test the cloudwatch logs processor lambda function in a pre-production environment to ensure
the 6000000 limit meets your requirements. If your data contains a sizable number of records that are classified as
Dropped/ProcessingFailed, then it is suggested to lower the 6000000 limit within the function to a smaller value
(eg: 5000000) in order to confine to the 6MB (6291456 bytes) payload limit imposed by lambda. You can find Lambda
quotas at https://docs.aws.amazon.com/lambda/latest/dg/gettingstarted-limits.html

The code below will:

1) Gunzip the data
2) Parse the json
3) Set the result to ProcessingFailed for any record whose messageType is not DATA_MESSAGE, thus redirecting them to the
   processing error output. Such records do not contain any log events. You can modify the code to set the result to
   Dropped instead to get rid of these records completely.
4) For records whose messageType is DATA_MESSAGE, extract the individual log events from the logEvents field, and pass
   each one to the transformLogEvent method. You can modify the transformLogEvent method to perform custom
   transformations on the log events.
5) Concatenate the result from (4) together and set the result as the data of the record returned to Firehose. Note that
   this step will not add any delimiters. Delimiters should be appended by the logic within the transformLogEvent
   method.
6) Any individual record exceeding 6,000,000 bytes in size after decompression and encoding is marked as
   ProcessingFailed within the function. The original compressed record will be backed up to the S3 bucket
   configured on the Firehose.
7) Any additional records which exceed 6MB will be re-ingested back into Firehose.
8) The retry count for intermittent failures during re-ingestion is set 20 attempts. If you wish to retry fewer number
   of times for intermittent failures you can lower this value.
"""
LOGGING_LEVEL = os.environ["LOGGING_LEVEL"]
logger = InsiderProtectionLogging(__name__, LOGGING_LEVEL).logger

# load dynamic partitionning settings
log_group_partitions = json.loads(os.environ["LOG_GROUP_PARTITIONS"])

# logs groups naming paterns:
LAMBDA_PREFIX = '/aws/lambda/'
NIFI_PREFIX = '/2s33/nifi/'
COMPUTING_PREFIX = '/2s33/computing/algorithm/'
TEST_LAMBDA_PREFIX = '/aws/lambda/logs-generator'

# Regex definitions
lambdaWrapperRegExpPattern =  re.compile("^(START|END|REPORT) (RequestId): ([a-z0-9-]+) ?(?:(Version): (\S+))?\t?(?:(Duration): ([\S ]+))?\t?(?:(Billed Duration): ([\S ]+))?\t?(?:(Memory Size): ([\S ]+))?\t?(?:(Max Memory Used): ([\S ]+))?\t?(?:(Init Duration): ([\S ]+))?\s*$")

### custom transformation for Insider Protection at log level
def transformInsiderLogEvent(owner, log_group, log_stream, log_event, log_ingestion_request_id):
    """
    Args:
    owner: The aws account from where the Cloudwatch event came from
    log_group: Cloudwatch log group name
    log_stream: CloudWatch log stream name 
    log_event (dict): The original log event. Structure is {"id": str, "timestamp": long, "message": str}
    log_ingestion_request_id: Identifier of the invocation request

    Returns:
    json: The transformed log event.
    """

    # specific treatment for lambda logs
    if log_group.startswith(LAMBDA_PREFIX):
        source_name = log_group.replace(LAMBDA_PREFIX, '')
        data_source = "Lambda"
        matcher = lambdaWrapperRegExpPattern.match(log_event['message'])
        if (matcher == None):
            message_payload = log_event['message']
        else:
            matcherResult = matcher.groups()
            index = 1
            message_payload = { "message" : log_event['message'], "LambdaProcessingStep" : matcherResult[0] }
            while len(matcherResult) >= index+1:
                if matcherResult[index] == None:
                    index = index + 2
                    continue
                if matcherResult[index] == 'RequestId':
                    aws_request_id = matcherResult[index+1]
                else:
                    message_payload[matcherResult[index]] = matcherResult[index+1]
                index = index + 2
    
    # specific treatment for NiFi logs
    elif log_group.startswith(NIFI_PREFIX):
        source_name = log_group.replace(NIFI_PREFIX, '')
        data_source = "Nifi"
        message_payload = log_event['message']
        
    # specific treatment for Computing logs        
    elif log_group.startswith(COMPUTING_PREFIX):
        source_name = log_group.replace(COMPUTING_PREFIX, '')
        data_source = "Computing"
        message_payload = log_event['message']
    
    # default/generic operation for others logs    
    else:
        source_name = log_group
        data_source = "Others"
        message_payload = log_event['message']

    # build transformed data bundle
    DATE_FORMAT = '%Y-%m-%dT%H:%M:%S.%f%z'
    attributes = {
                    "source_name": source_name,
                    "data_source": data_source,
                    "log_stream": log_stream,
                    "aws_account_id": owner,
                    "log_timestamp": log_event['timestamp'],
                    "log_ingestion_time": str(datetime.fromtimestamp(log_event['timestamp'] / 1000.0).replace(tzinfo=timezone.utc).strftime(DATE_FORMAT)),
                    "log_ingestion_id": log_ingestion_request_id
                    }
    
    # add aws_request_id to the bundle only for control logs generated by AWS Lambda service (START/STOP lambda and so on...)
    if 'aws_request_id' in locals():
        attributes['AwsRequestId'] = aws_request_id
    
    # formatting the log payload and add it to the bundle
    if type(message_payload) is dict:
        #lowercase message field for lambda logs
        if message_payload.get('Message') is not None :
            message_payload['message'] = message_payload.pop('Message')
        attributes.update(message_payload)
    else:
        try:
            attributes.update(json.loads(message_payload))
        except Exception as e:
            attributes['message'] = message_payload

    # return transformed data
    transformed_log = json.dumps(attributes)
    return transformed_log
    
### Handle the records[] payload passed to this lambda
def processRecords(records, request_id):
    logger.debug("enter processRecords")
    logger.debug("request ID " + str(request_id))
    logger.debug("records count " + str(len(records)))
    for r in records:
        data = base64.b64decode(r['data'])
        striodata = BytesIO(data)
        with gzip.GzipFile(fileobj=striodata, mode='r') as f:
            data = json.loads(f.read())
        logger.debug("--------------------------------------------------------------")
        logger.debug(json.dumps(data))
        logger.debug("--------------------------------------------------------------")
        recId = r['recordId']

        # CONTROL_MESSAGE are sent by CWL to check if the subscription is reachable. They do not contain actual data.
        if data['messageType'] == 'CONTROL_MESSAGE':
            yield {
                'result': 'Dropped',
                'recordId': recId
            }

        # DATA_MESSAGE are the containing the logs send by the CW subscription
        elif data['messageType'] == 'DATA_MESSAGE':
            
            ### get transformed payload
            logger.debug("Events count for recordId " + str(recId) + " is " + str(len(data['logEvents'])) )
            joinedData = ''.join([transformInsiderLogEvent(data['owner'], data['logGroup'], data['logStream'], e, request_id) + "\n" for e in data['logEvents']])


            ### Define partition Keys based on log group source and record timestamp
            sourcetype = "UNSORTED" # default value if nothing match
            for log_group_partition in log_group_partitions:
                try:
                    current_log_group_regex = re.compile(log_group_partition['log_group'])
                    if current_log_group_regex.match(data['logGroup']):
                        logger.debug(f'log group {data["logGroup"]} match with regex {log_group_partition["log_group"]}')
                        sourcetype = log_group_partition['partition']
                        break # first match will win
                    else:
                        logger.debug(f'log group {data["logGroup"]} do NOT match with regex {log_group_partition["log_group"]}')
                except:
                    logger.debug("error when evaluating sourcetype partition key, program skip to next evaluation.")
                    continue


            record_timestamp = datetime.fromtimestamp(r['approximateArrivalTimestamp']/1000)
            partition_keys = {
                "sourcetype": sourcetype,
                "year": record_timestamp.strftime('%Y'), 
				"month": record_timestamp.strftime('%m'),
				"day": record_timestamp.strftime('%d'),
				"hour": record_timestamp.strftime('%H'),
				"minute": record_timestamp.strftime('%M')
            }
            logger.debug(f"partition key for record {recId}:")
            logger.debug(json.dumps(partition_keys))
            
            
            ### encode payload
            dataBytes = joinedData.encode("utf-8")
            logger.debug("--------------------------------------------------------------")
            logger.debug(dataBytes)
            logger.debug("--------------------------------------------------------------")
            encodedData = base64.b64encode(dataBytes)
            
            ### prevent payload overload
            if len(encodedData) <= 6000000:
                yield {
                    'data': encodedData,
                    'result': 'Ok',
                    'recordId': recId,
                    'metadata' : { 'partitionKeys': partition_keys }
                }
            else:
                yield {
                    'result': 'ProcessingFailed',
                    'recordId': recId
                }
        else:
            yield {
                'result': 'ProcessingFailed',
                'recordId': recId
            }

### push records back to a firehose stream
def putRecordsToFirehoseStream(streamName, records, client, attemptsMade, maxAttempts):
    failedRecords = []
    codes = []
    errMsg = ''
    # if put_record_batch throws for whatever reason, response['xx'] will error out, adding a check for a valid
    # response will prevent this
    response = None
    try:
        response = client.put_record_batch(DeliveryStreamName=streamName, Records=records)
    except Exception as e:
        failedRecords = records
        errMsg = str(e)

    # if there are no failedRecords (put_record_batch succeeded), iterate over the response to gather results
    if not failedRecords and response and response['FailedPutCount'] > 0:
        for idx, res in enumerate(response['RequestResponses']):
            # (if the result does not have a key 'ErrorCode' OR if it does and is empty) => we do not need to re-ingest
            if 'ErrorCode' not in res or not res['ErrorCode']:
                continue

            codes.append(res['ErrorCode'])
            failedRecords.append(records[idx])

        errMsg = 'Individual error codes: ' + ','.join(codes)

    if len(failedRecords) > 0:
        if attemptsMade + 1 < maxAttempts:
            print('Some records failed while calling PutRecordBatch to Firehose stream, retrying. %s' % (errMsg))
            putRecordsToFirehoseStream(streamName, failedRecords, client, attemptsMade + 1, maxAttempts)
        else:
            raise RuntimeError('Could not put records after %s attempts. %s' % (str(maxAttempts), errMsg))

### push records back to regular Kinesis stream
def putRecordsToKinesisStream(streamName, records, client, attemptsMade, maxAttempts):
    logger.debug("entering putRecordsToKinesisStream")
    failedRecords = []
    codes = []
    errMsg = ''
    # if put_records throws for whatever reason, response['xx'] will error out, adding a check for a valid
    # response will prevent this
    response = None
    try:
        response = client.put_records(StreamName=streamName, Records=records)
    except Exception as e:
        failedRecords = records
        errMsg = str(e)

    # if there are no failedRecords (put_record_batch succeeded), iterate over the response to gather results
    if not failedRecords and response and response['FailedRecordCount'] > 0:
        for idx, res in enumerate(response['Records']):
            # (if the result does not have a key 'ErrorCode' OR if it does and is empty) => we do not need to re-ingest
            if 'ErrorCode' not in res or not res['ErrorCode']:
                continue

            codes.append(res['ErrorCode'])
            failedRecords.append(records[idx])

        errMsg = 'Individual error codes: ' + ','.join(codes)

    if len(failedRecords) > 0:
        if attemptsMade + 1 < maxAttempts:
            print('Some records failed while calling PutRecords to Kinesis stream, retrying. %s' % (errMsg))
            putRecordsToKinesisStream(streamName, failedRecords, client, attemptsMade + 1, maxAttempts)
        else:
            raise RuntimeError('Could not put records after %s attempts. %s' % (str(maxAttempts), errMsg))

### reformat data for re ingest
def createReingestionRecord(isSas, originalRecord):
    logger.debug("entering createReingestionRecord")
    if isSas:
        return {'data': base64.b64decode(originalRecord['data']), 'partitionKey': originalRecord['kinesisRecordMetadata']['partitionKey']}
    else:
        return {'data': base64.b64decode(originalRecord['data'])}

### TODO: describe function usage here
def getReingestionRecord(isSas, reIngestionRecord):
    logger.debug("entering getReingestionRecord")
    if isSas:
        return {'Data': reIngestionRecord['data'], 'PartitionKey': reIngestionRecord['partitionKey']}
    else:
        return {'Data': reIngestionRecord['data']}

### Lambda Entry point
def lambda_handler(event, context):
 
    logger.debug("entering lambda_handler")
    logger.debug("**************************************************************************")
    logger.debug(json.dumps(event))
    logger.debug("**************************************************************************")    
    
    isSas = 'sourceKinesisStreamArn' in event
    
    if isSas:
        logger.debug("isSas is True")
    else:
        logger.debug("isSas is False")
        
    try:
        # streamARN = event['sourceKinesisStreamArn'] if isSas else event['deliveryStreamArn']   # REPLACE by try/except bloc to avoid exception        
        streamARN = event['deliveryStreamArn']
    except:
        traceback.print_exc()
        return { 'status': 'failed' }

    region = streamARN.split(':')[3]
    streamName = streamARN.split('/')[1]
    request_id = context.aws_request_id
    records = list(processRecords(event['records'], request_id))
    projectedSize = 0
    dataByRecordId = {rec['recordId']: createReingestionRecord(isSas, rec) for rec in event['records']}
    putRecordBatches = []
    recordsToReingest = []
    totalRecordsToBeReingested = 0

    for idx, rec in enumerate(records):
        if rec['result'] != 'Ok':
            continue
        projectedSize += len(rec['data']) + len(rec['recordId'])
        # 6000000 instead of 6291456 to leave ample headroom for the stuff we didn't account for
        if projectedSize > 6000000:
            totalRecordsToBeReingested += 1
            recordsToReingest.append(
                getReingestionRecord(isSas, dataByRecordId[rec['recordId']])
            )
            records[idx]['result'] = 'Dropped'
            del(records[idx]['data'])

        # split out the record batches into multiple groups, 500 records at max per group
        if len(recordsToReingest) == 500:
            putRecordBatches.append(recordsToReingest)
            recordsToReingest = []

    if len(recordsToReingest) > 0:
        # add the last batch
        putRecordBatches.append(recordsToReingest)

    # iterate and call putRecordBatch for each group
    recordsReingestedSoFar = 0
    if len(putRecordBatches) > 0:
        client = boto3.client('kinesis', region_name=region) if isSas else boto3.client('firehose', region_name=region)
        for recordBatch in putRecordBatches:
            if isSas:
                putRecordsToKinesisStream(streamName, recordBatch, client, attemptsMade=0, maxAttempts=10)
            else:
                putRecordsToFirehoseStream(streamName, recordBatch, client, attemptsMade=0, maxAttempts=10)
            recordsReingestedSoFar += len(recordBatch)
            print('Reingested %d/%d records out of %d' % (recordsReingestedSoFar, totalRecordsToBeReingested, len(event['records'])))
    else:
        logger.info('No records to be reingested')

    return {"records": records}
    
### alternative handler function to quickly write tests
def lambda_handler_test(event, context):
    output = []
    
    ### DEBUG
    logger.info("*******************************************************************************************")
    logger.info(json.dumps(event))
    #json.dumps(context)
    logger.info("*******************************************************************************************")

    for record in event['records']:
        print(record['recordId'])
        payload = base64.b64decode(record['data']).decode('utf-8')

        # Do custom processing on the payload here

        output_record = {
            'recordId': record['recordId'],
            'result': 'Ok',
            'data': base64.b64encode(payload.encode('utf-8')).decode('utf-8')
        }
        output.append(output_record)

    print('Successfully processed {} records.'.format(len(event['records'])))

    return {'records': output}


									#############################
									### Lambda log-processing ###
									#############################

# TODO LIST:
 - rename 'request_id' to aws_request_id in the code
 - quid de 'invocationId' ?
 - quid des recordID ?
 - do we provide the correct timestamp in the output (for correct Splunk time indexation) ?

###########################################################
# TESTS EVENTS
###########################################################
Generate logs directly in a subscribed log group to test this lambda
Don't use test events

###########################################################
# conf for partitionning:
###########################################################
log_group_partitions = [
    {
	"log_group": "\/2s33\/computing\/algorithm\/ac_.{0,3}_2s33", <= Regex too match
	"filter": "?WARNING ?ERROR ?INFO", 
	"partition": "COMPUTING",  <= value to apply in partition key 'sourcetype'
	"sqs_suffix_name" : "algo"
	}
]


###########################################################
# Event passed to lambda_handler(event, context):
###########################################################
event = {
    "invocationId": "fa7304d5-eb51-4251-97b5-9f37e6e021d1",
    "deliveryStreamArn": "arn:aws:firehose:eu-west-1:309711267128:deliverystream/2s33-test-partitioning",
    "region": "eu-west-1",
    "records": [
        {
            "recordId": "49638159422386035278188558189651719045009259606380118018000000",
            "approximateArrivalTimestamp": 1676826208709,
            "data": "H4sIAAAAAAAAAD1Qy2rDMBD8FaNTC3Esaa2HfQs0CT2kPSS3EoRqC0fgF5LcUkL+vVIfOa00s7O7M1c0GO91Z05fs0E1etqcNuqwPR43+y1aoelzNC7CgCtBCOWCUBnhfur2blrmyBTUAxTNNMxLsGNX6L6bnA2XodCNwpVK9K/iGJzRQ5SwnGIKOaY5gXx2prVNyEnJK5nf1VHil3ffODsHO4072wfjPKrfUDA+qFm7YBMRV6Lzz/jthxlD6rgi26aTBVRlKUpMKAGQsgIAJpgEyiJDy0ow4KVkDFMp0oPQElccx83BxlCCHqI/wgWXlFMsKcjVf1hx/N2CzLCsgddAVsBYlmfPL7vXWA7ajqdLtNzGzzC1pk81gqrXy9hcjFsr1ei+V6oWIglSz/ovj4fHrM4wG+yYMezR7Xz7BrjWBeiqAQAA"
        },
        {
            "recordId": "49638159422386035278188558189654136896649048722306498562000000",
            "approximateArrivalTimestamp": 1676834355816,
            "data": "H4sIAAAAAAAAAD1QyWrDMBD9FaNTC3GsxdbiW6BJ6CHtIbmVIFRbOAJbNpLcUkL+veMuOQ16y4zeu6LBxmg6e/qaLKrR0+a00Yft8bjZb9EKjZ/eBoAZVoIQygWhEuB+7PZhnCdgChoZK5pxmObkfFeYvhuDS5ehMI3GSi/0r+OYgjUDWKqcYspyTHPC8inY1jUpJyVXMr+7wRLn99gENyU3+p3rkw0R1W8o2Zj0ZEJyCwEn0fln/fbD+rQorsi1y5cFUyWvKoGxoLjiihEiBeFMScWFoLSqSoIrJSnBirISyJJLieFyclBKMgPkI1xwyUoGYsZX/2XB+nsEmWFZM14zsgJVlmfPL7tXGAfj/OkCkVt4DGNr+2UCqHsz++Ziw1rrxvS91rXgi2HRrP/6eHjM6gyzwfkM04hu59s39PeGmaoBAAA="
        }
    ]
}

context.aws_request_id => 065cb96e-2fa0-49a0-aa5b-3d9860f6f409

###########################################################
# parameter passed to processRecords(records, request_id):
###########################################################
request_id = 065cb96e-2fa0-49a0-aa5b-3d9860f6f409
records = [
        {
            "recordId": "49638159422386035278188558189651719045009259606380118018000000",
            "approximateArrivalTimestamp": 1676826208709,
            "data": "H4sIAAAAAAAAAD1Qy2rDMBD8FaNTC3Esaa2HfQs0CT2kPSS3EoRqC0fgF5LcUkL+vVIfOa00s7O7M1c0GO91Z05fs0E1etqcNuqwPR43+y1aoelzNC7CgCtBCOWCUBnhfur2blrmyBTUAxTNNMxLsGNX6L6bnA2XodCNwpVK9K/iGJzRQ5SwnGIKOaY5gXx2prVNyEnJK5nf1VHil3ffODsHO4072wfjPKrfUDA+qFm7YBMRV6Lzz/jthxlD6rgi26aTBVRlKUpMKAGQsgIAJpgEyiJDy0ow4KVkDFMp0oPQElccx83BxlCCHqI/wgWXlFMsKcjVf1hx/N2CzLCsgddAVsBYlmfPL7vXWA7ajqdLtNzGzzC1pk81gqrXy9hcjFsr1ei+V6oWIglSz/ovj4fHrM4wG+yYMezR7Xz7BrjWBeiqAQAA"
        },
        {
            "recordId": "49638159422386035278188558189654136896649048722306498562000000",
            "approximateArrivalTimestamp": 1676834355816,
            "data": "H4sIAAAAAAAAAD1QyWrDMBD9FaNTC3GsxdbiW6BJ6CHtIbmVIFRbOAJbNpLcUkL+veMuOQ16y4zeu6LBxmg6e/qaLKrR0+a00Yft8bjZb9EKjZ/eBoAZVoIQygWhEuB+7PZhnCdgChoZK5pxmObkfFeYvhuDS5ehMI3GSi/0r+OYgjUDWKqcYspyTHPC8inY1jUpJyVXMr+7wRLn99gENyU3+p3rkw0R1W8o2Zj0ZEJyCwEn0fln/fbD+rQorsi1y5cFUyWvKoGxoLjiihEiBeFMScWFoLSqSoIrJSnBirISyJJLieFyclBKMgPkI1xwyUoGYsZX/2XB+nsEmWFZM14zsgJVlmfPL7tXGAfj/OkCkVt4DGNr+2UCqHsz++Ziw1rrxvS91rXgi2HRrP/6eHjM6gyzwfkM04hu59s39PeGmaoBAAA="
        }		
    ]

# iterate over records and decode "data" field
{
    "messageType": "DATA_MESSAGE",
    "owner": "309711267128",
    "logGroup": "/2s33/computing/algorithm/ac_09_2s33",
    "logStream": "5-2023-02-13-predict-14698-algorithm",
    "subscriptionFilters": [
        "test_partitioning"
    ],
    "logEvents": [
        {
            "id": "37394474012133889333575832573924975364855028764851240960",
            "timestamp": 1676826208238,
            "message": "2023-02-18 08:36:31,355 - INFO - MainThread - model - main_launcher.__call__:77 - Model.predict() : 05min 50s"
        }
    ]
}

###########################################################
# iterate over logEvents and pass to 
# transformInsiderLogEvent(owner, log_group, log_stream, log_event, log_ingestion_request_id):
###########################################################
owner = "309711267128"
log_group = "/2s33/computing/algorithm/ac_09_2s33"
log_stream = "5-2023-02-13-predict-14698-algorithm"
log_ingestion_request_id = 065cb96e-2fa0-49a0-aa5b-3d9860f6f409
log_event = {
	"id": "37394474012133889333575832573924975364855028764851240960",
	"timestamp": 1676826208238,
	"message": "2023-02-18 08:36:31,355 - INFO - MainThread - model - main_launcher.__call__:77 - Model.predict() : 05min 50s"
}


# data return by transformInsiderLogEvent()
joinedData = {
    "source_name": "ac_09_2s33",
    "data_source": "Computing",
    "log_stream": "5-2023-02-13-predict-14698-algorithm",
    "aws_account_id": "309711267128",
    "log_timestamp": 1676826208238,
    "log_ingestion_time": "2023-02-19T17:03:28.238000+0000",
    "log_ingestion_id": "065cb96e-2fa0-49a0-aa5b-3d9860f6f409",
    "message": "2023-02-18 08:36:31,355 - INFO - MainThread - model - main_launcher.__call__:77 - Model.predict() : 05min 50s"
}

# bundle returned by processRecords()
{
	'data': base64.b64encode(joinedData.encode("utf-8")),
	'result': 'Ok',
	'recordId': recId,
	'metadata' : { 'partitionKeys': partition_keys }
}


# retour attendue de la lambda_handler# record output format:
firehose_record_output = {
	'recordId': firehose_record_input['recordId'],
	'data': firehose_record_input['data'],
	'result': 'Ok',
	'metadata': { 'partitionKeys': partition_keys }
}




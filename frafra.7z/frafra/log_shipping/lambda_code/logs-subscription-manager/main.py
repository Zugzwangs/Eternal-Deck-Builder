import boto3
import os
import re
import json

from custom_logging_2s33.insider_protection_logging import InsiderProtectionLogging

LOGGING_LEVEL = os.environ["LOGGING_LEVEL"]
logger = InsiderProtectionLogging(__name__, LOGGING_LEVEL).logger

dest_arn = os.environ["DESTINATION_ARN"]
subscription_role_arn = os.environ["SUBSCRIPTION_IAM_ROLE"]
subscription_name = os.environ["SUBSCRIPTION_NAME"]
log_group_function_processor = f'/aws/lambda/{os.environ["TRANSFORM_LAMBDA_NAME"]}'
log_group_filters = json.loads(os.environ["LOG_GROUP_FILTERS"])

clientLogs = boto3.client('logs')

# return the list of all logs group in the current AWS account
def get_log_groups():
    response = clientLogs.describe_log_groups()
    log_groups = response["logGroups"]
    next_token = response.get("nextToken")
    while next_token:
        response = clientLogs.describe_log_groups(nextToken=next_token)
        log_groups.extend(response["logGroups"])
        next_token = response.get("nextToken")
    return log_groups

# mark each matching log group in the inventory with the filtering rule set in 'log_group_filters'
def enrich_log_groups(log_groups, log_group_filters):
    for log_group in log_groups:
        log_group["targetfilter"] = None
        for log_group_filter in log_group_filters:
            log_group_regexp_pattern = re.compile(log_group_filter["log_group"])
            if log_group_regexp_pattern.match(log_group["logGroupName"]) is not None and log_group["logGroupName"] != log_group_function_processor:
                log_group["targetfilter"] = log_group_filter["filter"]
    return log_groups

# return all logs group in log_groups{} matching at least one of the regex rules in log_group_filters[]
def detect_log_groups(log_groups, log_group_filters):
    matching_log_groups = []
    for log_group in log_groups:
        matching_regex = []
        for log_group_filter in log_group_filters:
            log_group_regexp_pattern = re.compile(log_group_filter["log_group"])
            if log_group_regexp_pattern.match(log_group["logGroupName"]) is not None and log_group["logGroupName"] != log_group_function_processor:
                matching_regex.append(log_group_filter["log_group"])
        if len(matching_regex) > 0:
            matching_log_groups.append({"logGroupName": log_group["logGroupName"], "Matching regex": matching_regex})

    return matching_log_groups
    
# return all subscriptions configurations for a log group
def get_subscription_filters(log_group_name):
    response = clientLogs.describe_subscription_filters(
        logGroupName=log_group_name
        )
    subscription_filters = response["subscriptionFilters"]
    next_token = response.get("nextToken")
    while next_token:
        response = clientLogs.describe_subscription_filters(nextToken=next_token)
        subscription_filters.extend(response["subscriptionFilters"])
        next_token = response.get("nextToken")
    return subscription_filters 

def get_subscription_filters_to_delete(subscription_filters, log_group_enriched):
    subscription_filters_to_delete = []
    for subscription_filter in subscription_filters:
            if log_group_enriched["targetfilter"] is None and subscription_filter["destinationArn"] == dest_arn:
                subscription_filters_to_delete.append(subscription_filter)
            if log_group_enriched["targetfilter"] and subscription_filter["destinationArn"] == dest_arn:
                if subscription_filter["filterPattern"] != log_group_enriched["targetfilter"] or subscription_filter["filterName"] != f'{log_group_enriched["logGroupName"]}-filter':
                    subscription_filters_to_delete.append(subscription_filter)
    return subscription_filters_to_delete

def get_subscription_filters_to_create(subscription_filters, log_group_enriched):
    subscription_filters_to_create = []
    subscription_filters_already_existing = []
    for subscription_filter in subscription_filters:
        if subscription_filter["destinationArn"] == dest_arn and subscription_filter["filterPattern"] == log_group_enriched["targetfilter"] and subscription_filter["filterName"] == f'{log_group_enriched["logGroupName"]}-filter':
            subscription_filters_already_existing.append(subscription_filter)

    if len(subscription_filters_already_existing) == 0 and log_group_enriched["targetfilter"]:
        subscription_filters_to_create.append({
            "destinationArn": dest_arn,
            "filterPattern": log_group_enriched["targetfilter"],
            "logGroupName": log_group_enriched["logGroupName"],
            "filterName": f'{log_group_enriched["logGroupName"]}-filter'
        })
    return subscription_filters_to_create
    

def handler(event, context):

    ### test mode ###
    if "tests" in event:
        logger.info('test mode')
        if isinstance(event["tests"], list):
            
            logger.info("Scanning current log groups inventory...")
            log_groups = get_log_groups()
            logger.info(f"Number of log groups found: {len(log_groups)}")
            #logger.debug(json.dumps(log_groups))
            
            # get all logs groups matching tests regex:
            logger.info("matching logs groups with the tests regex...")
            log_groups_detected = detect_log_groups(log_groups, event["tests"])
            logger.info(json.dumps(log_groups_detected))

            return "Test done"      
        
        else:
            logger.error("'tests' item in event{} must a list of dict")
            return("KO")

    ### test mode ###
    elif "dry-run" in event:
        logger.info('dry run mode')
        logger.warning('not implemented !')
        return"OK"
    
    ### regular mode ###
    else:
        logger.info('regular mode')
        logger.info("Scanning current log groups inventory...")
        log_groups = get_log_groups()
        logger.info(f"Number of log groups found: {len(log_groups)}")
        logger.debug(json.dumps(log_groups))
    
        logger.info(f"Log groups enrichment starting ...")
        log_groups_enriched = enrich_log_groups(log_groups,log_group_filters)
        logger.debug(json.dumps(log_groups_enriched))
        
        logger.info(f"Determination of subscription filters to create and delete...")
        subscription_filters_to_delete = []
        subscription_filters_to_create = []
        for log_group_enriched in log_groups_enriched:
            subscription_filters = get_subscription_filters(log_group_enriched["logGroupName"])
            
            subscription_filters_to_delete_temp = get_subscription_filters_to_delete(subscription_filters, log_group_enriched)
            (subscription_filters_to_delete.extend(subscription_filters_to_delete_temp) if subscription_filters_to_delete_temp else None)
            
            subscription_filters_to_create_temp = get_subscription_filters_to_create(subscription_filters, log_group_enriched)
            (subscription_filters_to_create.extend(subscription_filters_to_create_temp) if subscription_filters_to_create_temp else None)
        
        logger.info(f"Deleting subscription filters ...")
        logger.debug(f"subscription_filters_to_delete: {subscription_filters_to_delete}")
        for subscription_filter in subscription_filters_to_delete:
            clientLogs.delete_subscription_filter(
                                logGroupName=subscription_filter["logGroupName"],
                                filterName=subscription_filter["filterName"]
                            )
            logger.info(f'Subscription deleted for : {subscription_filter["logGroupName"]}')
        
        logger.info(f"Creating subscription filters ...")
        logger.debug(f"subscription_filters_to_create: {subscription_filters_to_create}")
        for subscription_filter in subscription_filters_to_create:
            clientLogs.put_subscription_filter(
                destinationArn=subscription_filter["destinationArn"],
                filterPattern=subscription_filter["filterPattern"],
                logGroupName=subscription_filter["logGroupName"],
                filterName=subscription_filter["filterName"],
                roleArn=subscription_role_arn
            )
            logger.info(f'Subscription done for : {subscription_filter["logGroupName"]}')
    
        return "OK"

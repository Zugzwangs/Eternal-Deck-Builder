###########################################################
# TESTS EVENTS
###########################################################

Regular usage of the lambda don't required particular event to be passed, so this is ok:
{
  "key1": "no input required"
}


If you want to test a regex and see what are the correspondings logs groups being subscribed, adapt the following:
{
  "tests": [
    {
      "log_group": "/2s33/log/group/that/dont/exitsts"
    },
    {
      "log_group": "/2s33/computing/algorithm/.*"
    }
  ]
}

Dry run mode is not implemented yet, so this don't do anything:
{
  "dry-run" : ""
}



function get_log_groups() return a list with this content:
log_group = [
    {
        "logGroupName": "/aaa/bbb/ccc",
        "creationTime": 1632234265696,
        "retentionInDays": 60,
        "metricFilterCount": 0,
        "arn": "arn:aws:logs:eu-west-1:309711267128:log-group:/2s33/administration/deployer:*",
        "storedBytes": 31417,
        "targetfilter" : <<log_group_filter["filter"]>>
    },  
...
]


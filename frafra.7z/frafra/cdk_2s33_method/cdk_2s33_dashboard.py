from abc import ABC, abstractmethod
from aws_cdk import aws_cloudwatch


class Cdk2s33Dashboard(ABC):
    def __init__(self, scope, cdk_id: str, cdk_name: str):
        self.scope = scope
        self.cdk_id = cdk_id
        self.cdk_name = cdk_name

    @abstractmethod
    def _build_body(self):
        """
        Overwrite this function to create the dashboard body.
        """
        pass

    def get_dashboard(self):
        return aws_cloudwatch.CfnDashboard(
            self.scope,
            self.cdk_id,
            dashboard_name=self.cdk_name,
            dashboard_body=self._build_body()
            )
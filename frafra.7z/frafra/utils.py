import json
import os
from pathlib import Path
import base64

from aws_cdk import (
    aws_ssm,
    aws_lambda,
    Duration,
    aws_ec2,
    RemovalPolicy,
    aws_secretsmanager,
    aws_iam,
    aws_kms,
    CfnOutput,
    aws_s3,
    aws_events,
    aws_events_targets,
    aws_sqs,
    Stack,
    aws_dynamodb,
    aws_kinesisfirehose,
    aws_glue
)

from cdk_stacks.config import ENV

import json
import os
from pathlib import Path


sqs_arn_prefix = "arn:aws:sqs:"
firehose_arn_prefix = "arn:aws:firehose:"
s3_arn_prefix = "arn:aws:s3:::"
iam_arn_prefix = "arn:aws:iam::"
glue_arn_prefix = "arn:aws:glue:"
kms_arn_prefix = "arn:aws:kms:"
lambda_arn_prefix = "arn:aws:lambda:"
ec2_arn_prefix = "arn:aws:ec2:"
cloudformation_arn_prefix = "arn:aws:cloudformation:"
athena_arn_prefix = "arn:aws:athena:"
logs_arn_prefix = "arn:aws:logs:"
aws_user_id_prefix = "aws:userId"
aws_source_arn_prefix = "aws:SourceArn"
aws_iam_role = "aws_iam.Role"
aws_iam_role_cfn = "aws_iam.CfnRole"
aws_events_rule = "aws_events.Rule"
aws_events_rule_cfn = "aws_events.CfnRule"
ROOT_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
ssm_base_path = "/airbus/2s33/ssm/"
aws_principal_arn_prefix = "aws:PrincipalArn"
aws_principal_service_name = "aws:PrincipalServiceName"
common_lambda_handler = "main.lambda_handler"
lambda_runtime_python37 = aws_lambda.Runtime.PYTHON_3_7
lambda_runtime_python38 = aws_lambda.Runtime.PYTHON_3_8
ssm_arn_prefix = "arn:aws:ssm:"
sns_arn_prefix = "arn:aws:sns:"
cloudwatch_arn_prefix = "arn:aws:cloudwatch:"


# general
def get_context_by_env(env):
    with open(f'{ROOT_DIR}{Path("/cdk.json")}', 'r') as f:
        cdk_json_file = json.load(f)

    return cdk_json_file["context"][env]


context = get_context_by_env(ENV)


def bucket_naming(bucket_name, env, region):
    """
    Method to handle bucket naming with 2s33 convention or custom name
    """
    complete_name = "s3-2s33-" + env + "-" + bucket_name + "-" + region
    return complete_name


def retrieve_role_attr(self, attr, role_props):
    """
    * self is passed as we need to access to the role_container of the stack
    * attr: must be in ["arn","id"] depending on the attribute we want to retrieve
    * role_props: dict of properties
      * roleKey: is the key of the role given in CdkIam stack
                for inbuilt roles or the key given in cdk.json for imported roles
      * roleConstructor: optional, must be in [aws_iam_role_cfn, aws_iam_role],
                           if None is passed the role will assumed imported from cdk.json
      * accountOriginId: account id, passing this argument
                            will return only the arn of the role modified with the given account id
    """
    role_key = role_props["roleKey"]
    role_constructor = role_props["roleConstructor"] if "roleConstructor" in role_props else None
    account_origin_id = role_props["accountOriginId"] if "accountOriginId" in role_props else None

    # if role is part of this Cdk Apps
    if role_constructor:
        role = self.role_container[role_key] if "role_container" in dir(self) else self.container["role"][role_key]

        if account_origin_id:
            role_attr = {
                "arn": f"{iam_arn_prefix}{account_origin_id}:role/{role.role_name}",
                "id": None
            }
        else:
            role_attr = {
                "arn": role.attr_arn if (role_constructor == aws_iam_role_cfn) else role.role_arn,
                "id": role.attr_role_id if (role_constructor == aws_iam_role_cfn) else role.role_id,
            }

    # if role parameters imported from cdk.json
    else:
        if account_origin_id:
            role_attr = {
                "arn": f'{iam_arn_prefix}{account_origin_id}:role/'
                       f'{self.context["iam"]["role"][role_key]["name"]}',
                "id": None
            }
        else:
            role_attr = {
                "arn": f'{iam_arn_prefix}{self.account}:role/'
                       f'{self.context["iam"]["role"][role_key]["name"]}',
                "id": f'{self.context["iam"]["role"][role_key]["id"]}'
            }

    return role_attr[attr]


def __get_logical_id(stack: Stack, resource):
    """
    Get logical ID from a resource
    """
    return stack.get_logical_id(resource.node.find_child('Resource'))


# SSM Parameter
def handle_ssm_parameter_creation(self, value, ssm_props):
    """
    Method to handle ssm parameter creation based on value and config object
    # TODO interface for config object AND expected type for value
    """
    ssm_parameter = aws_ssm.CfnParameter(
        self,
        ssm_props["cdkId"],
        description=ssm_props["ssmParameterDescription"],
        name=ssm_props["ssmParameterName"],
        tier=ssm_props["ssmParameterTier"],
        type=ssm_props["ssmParameterType"],
        value=value
    )

    return ssm_parameter


# Lambda
def handle_lambda_function_creation(self, lambda_props):
    """
    Create lambda resource
    """
    # Prepare current version options - if the currentVersionOptions object is passed in the lambda_props
    lambda_version_options = None
    if "currentVersionOptions" in lambda_props:
        lambda_version_options = aws_lambda.VersionOptions(
            removal_policy=lambda_props["currentVersionOptions"]["removalPolicy"]
            if "removalPolicy" in lambda_props["currentVersionOptions"] else None,
            retry_attempts=lambda_props["currentVersionOptions"]["retryAttempts"]
            if "retryAttempts" in lambda_props["currentVersionOptions"] else None,
            max_event_age=lambda_props["currentVersionOptions"]["maxEventAge"]
            if "maxEventAge" in lambda_props["currentVersionOptions"] else None,
            on_success=lambda_props["currentVersionOptions"]["onSuccess"]
            if "onSuccess" in lambda_props["currentVersionOptions"] else None,
            on_failure=lambda_props["currentVersionOptions"]["onFailure"]
            if "onFailure" in lambda_props["currentVersionOptions"] else None,
        )

    lambda_function = aws_lambda.Function(
        self,
        lambda_props["cdkId"],
        code=aws_lambda.Code.from_asset(lambda_props["codePath"]),
        handler=lambda_props["handler"],
        runtime=lambda_props["runtime"],
        environment=lambda_props["environmentVariables"] if "environmentVariables" in lambda_props else None,
        function_name=lambda_props["functionName"],
        layers=lambda_props["layers"] if "layers" in lambda_props else None,
        memory_size=lambda_props["memorySize"] if "memorySize" in lambda_props else None,
        reserved_concurrent_executions=lambda_props["reservedConcurrentExecutions"]
        if "reservedConcurrentExecutions" in lambda_props else None,
        role=lambda_props["role"],
        timeout=Duration.seconds(lambda_props["timeout"]) if "timeout" in lambda_props else None,
        vpc=lambda_props["vpc"] if "vpc" in lambda_props else None,
        vpc_subnets=aws_ec2.SubnetSelection(subnets=lambda_props["subnets"]) if "subnets" in lambda_props else None,
        security_groups=lambda_props["security_groups"] if "security_groups" in lambda_props else None,
        current_version_options=lambda_version_options if "currentVersionOptions" in lambda_props else None,
    )
<<<<<<< HEAD
    if "additionalPermissionFromPrincipal" in lambda_props:
        lambda_function.add_permission(
            f'{lambda_props["cdkId"]}{lambda_props["additionalPermissionFromPrincipal"]["cdkIdSuffix"]}',
            action="lambda:InvokeFunction",
            principal=aws_iam.ServicePrincipal(lambda_props["additionalPermissionFromPrincipal"]["principal"]),
            source_arn=lambda_function.function_arn
=======
    if "additionalPermissionInvokeLambda" in lambda_props:
        lambda_function.add_permission(
            f'{lambda_props["cdkId"]}{lambda_props["additionalPermissionInvokeLambda"]["cdkIdSuffix"]}',
            action="lambda:InvokeFunction",
            principal=aws_iam.ServicePrincipal(lambda_props["additionalPermissionInvokeLambda"]["principal"]),
            source_arn=lambda_props["additionalPermissionInvokeLambda"]["sourceArn"]
            if "sourceArn" in lambda_props["additionalPermissionInvokeLambda"] else None,
>>>>>>> 9378bd6418aa3a5e1971176f7c9b6cea9bf9ff96
        )

    return lambda_function


def handle_layer_creation(self, layer_props):
    """
        Create a layer from code source with cdk construct aws_lambda.LayerVersion
        :rtype: object
    """
    layer = aws_lambda.LayerVersion(
        self,
        layer_props["cdkId"],
        layer_version_name=layer_props["layerName"],
        removal_policy=RemovalPolicy.RETAIN,
        code=aws_lambda.Code.from_asset(layer_props["codePath"]),
        description=layer_props["description"] if "description" in layer_props else None,
        compatible_runtimes=layer_props["compatibleRuntimes"] if "compatibleRuntimes" in layer_props else None,
        license=layer_props["license"] if "license" in layer_props else None,
    )
    return layer


# KMS
def handle_kms_key_creation(self, kms_props):
    """

    """
    policy_statements = handle_default_kms_policy_statement_creation(
        self,
        kms_props.get("kmsRoleAuthorized"),
        kms_props.get("kmsPrincipalAuthorized"),
        kms_props.get("kmsPrincipalServiceAuthorized")
    )

    if kms_props.get("policyStatement"):
        policy_statements.extend(
            [handle_policy_statement_creation(self, statement)
             for statement in kms_props["policyStatement"] if statement is not None])

    kms_key = aws_kms.Key(
        self,
        kms_props["cdkId"],
        removal_policy=RemovalPolicy.RETAIN,
        description=kms_props["kmsKeyDescription"],
        enabled=True,
        enable_key_rotation=True,
        key_usage=aws_kms.KeyUsage.ENCRYPT_DECRYPT,
        policy=aws_iam.PolicyDocument(
            statements=policy_statements
        )
    )
    key_alias = aws_kms.Alias(
        self,
        kms_props["kmsKeyAliasId"],
        # alias_name is required
        alias_name=kms_props["kmsKeyAliasName"],
        target_key=kms_key,
        removal_policy=RemovalPolicy.DESTROY
    )

    # Handle exports for both classParameter and cfnOutputs
    if "exports" in kms_props:
        handle_key_exports_creation(self, kms_props["exports"], kms_key, key_alias)

    return kms_key, key_alias


def handle_key_exports_creation(self, export_props, kms_key, key_alias):
    """

    """
    for key, item in export_props.items():
        if key == "arn":
            value = kms_key.key_arn

        elif key == "id":
            value = kms_key.key_id

        elif key == "alias":
            value = key_alias.alias_name

        else:
            raise ValueError(f'<<kms exports object>> must contain keys in ["arn", "id","alias"]')

        CfnOutput(
            self,
            item["cdkId"],
            value=value,
            description=item["cfnOutputDescription"] if "cfnOutputDescription" in item else None,
            export_name=item["cfnOutputName"]
        )


# BUCKET
def handle_bucket_creation(self, bucket_props, bucket_key=None, kms_key=None, backup_bucket=None):
    """

    """
    # Handle event notifications settings (only notifications to SQS queues is implemented)
    queues_notifications_properties = []
    if "event_notifications_properties" in bucket_props:
        if "queue_configurations" in bucket_props["event_notifications_properties"]:
            for queue_configuration in bucket_props["event_notifications_properties"]["queue_configurations"]:
                queues_notifications_properties.append(
                    aws_s3.CfnBucket.QueueConfigurationProperty(
                        event=queue_configuration["event"],
                        queue=queue_configuration["queue"],
                        filter=aws_s3.CfnBucket.NotificationFilterProperty(
                            s3_key=aws_s3.CfnBucket.S3KeyFilterProperty(
                                rules=[aws_s3.CfnBucket.FilterRuleProperty(
                                    name=queue_configuration["filterPropertyName"],
                                    value=queue_configuration["filterPropertyValue"]
                                )
                                ]
                            )
                        )
                    )
                )

    # define lifecycle_configuration_rules
    lifecycle_configuration_rules = []
    if "lifecycleConfiguration" in bucket_props:
        lifecycle_configuration_rules = [
            handle_lifecycle_configuration_rules_creation(rule) for rule in bucket_props["lifecycleConfiguration"]
            if rule is not None
        ]

    # Handle backup replication rules for backup
    replication_rules_properties = []
    if backup_bucket:
        replication_rules_properties.append(
            aws_s3.CfnBucket.ReplicationRuleProperty(
                id="Backup",
                priority=1,
                filter=aws_s3.CfnBucket.ReplicationRuleFilterProperty(prefix=""),
                delete_marker_replication=aws_s3.CfnBucket.DeleteMarkerReplicationProperty(
                    status="Disabled"
                ),
                status="Enabled",
                destination=aws_s3.CfnBucket.ReplicationDestinationProperty(
                    bucket=backup_bucket.attr_arn,
                    storage_class="GLACIER",
                    encryption_configuration=aws_s3.CfnBucket.EncryptionConfigurationProperty(
                        replica_kms_key_id=kms_key.key_arn
                    ),
                ),
                source_selection_criteria=aws_s3.CfnBucket.SourceSelectionCriteriaProperty(
                    sse_kms_encrypted_objects=aws_s3.CfnBucket.SseKmsEncryptedObjectsProperty(
                        status="Enabled"
                    )
                )
            )
        )

    # Handle custom replication rules (this condition is only for platform-logging bucket)
    if "replication" in bucket_props:
        replication_rules_properties.append(
            aws_s3.CfnBucket.ReplicationRuleProperty(
                id=bucket_props["replication"]["id"],
                priority=3,
                filter=aws_s3.CfnBucket.ReplicationRuleFilterProperty(prefix=""),
                delete_marker_replication=aws_s3.CfnBucket.DeleteMarkerReplicationProperty(
                    status="Disabled"
                ),
                status="Enabled",
                destination=aws_s3.CfnBucket.ReplicationDestinationProperty(
                    bucket=bucket_props["replication"]["destinationBucketArn"],
                    storage_class="STANDARD",
                    encryption_configuration=aws_s3.CfnBucket.EncryptionConfigurationProperty(
                        replica_kms_key_id=self.context["orchestration"]["platformLoggingReplicationKmsKeyArn"]
                    ),
                ),
                source_selection_criteria=aws_s3.CfnBucket.SourceSelectionCriteriaProperty(
                    sse_kms_encrypted_objects=aws_s3.CfnBucket.SseKmsEncryptedObjectsProperty(
                        status="Enabled"
                    )
                )
            )
        )

    # Handle cross account replication rules for PROD to DEV && PROD to INT
    if "crossAccountReplication" in bucket_props:
        priority = 1
        for destination_env in ["int", "dev"]:
            priority += 1
            env_account_id = f'{destination_env}AccountId'
            kms_env_id = f'{destination_env}KmsIdForReplication'
            if bucket_props["crossAccountReplication"][destination_env] and \
                    bucket_props["crossAccountReplication"][destination_env] is True:
                replication_rules_properties.append(
                    aws_s3.CfnBucket.ReplicationRuleProperty(
                        id=f"crossAccountReplication-{destination_env}",
                        priority=priority,
                        filter=aws_s3.CfnBucket.ReplicationRuleFilterProperty(prefix=""),
                        delete_marker_replication=aws_s3.CfnBucket.DeleteMarkerReplicationProperty(
                            status="Disabled"
                        ),
                        status="Enabled",
                        destination=aws_s3.CfnBucket.ReplicationDestinationProperty(
                            access_control_translation=aws_s3.CfnBucket.AccessControlTranslationProperty(
                                owner="Destination"),
                            account=self.context[env_account_id],
                            bucket=f'{s3_arn_prefix}'
                                   f'{bucket_naming(bucket_props["bucketName"], destination_env, self.context["region"])}',
                            encryption_configuration=aws_s3.CfnBucket.EncryptionConfigurationProperty(
                                replica_kms_key_id=f'{kms_arn_prefix}'
                                                   f'{self.context["region"]}:'
                                                   f'{self.context[env_account_id]}:key/'
                                                   f'{self.context["dataLake"]["bucket"][bucket_key][kms_env_id]}'
                            ),
                        ),
                        source_selection_criteria=aws_s3.CfnBucket.SourceSelectionCriteriaProperty(
                            sse_kms_encrypted_objects=aws_s3.CfnBucket.SseKmsEncryptedObjectsProperty(
                                status="Enabled"
                            )
                        )
                    )
                )

    replication_configuration_property = None
    if len(replication_rules_properties) > 0:
        replication_configuration_property = aws_s3.CfnBucket.ReplicationConfigurationProperty(
            role=self.role_container["role_bucket_backup"].role_arn
            if "role_container" in dir(self) else self.container["role"]["role_bucket_backup"].role_arn,
            rules=replication_rules_properties
        )

    bucket = aws_s3.CfnBucket(
        self,
        bucket_props["cdkId"],
        bucket_name=bucket_naming(
            bucket_props["bucketName"],
            ENV,
            self.context["region"]
        ) if "bucketName" in bucket_props else bucket_props["customBucketName"],
        public_access_block_configuration=aws_s3.CfnBucket.PublicAccessBlockConfigurationProperty(
            block_public_acls=True,
            block_public_policy=True,
            ignore_public_acls=True,
            restrict_public_buckets=True
        ),
        access_control="Private",
        versioning_configuration=aws_s3.CfnBucket.VersioningConfigurationProperty(
            status="Enabled"
        ),
        bucket_encryption=aws_s3.CfnBucket.BucketEncryptionProperty(
            server_side_encryption_configuration=[
                aws_s3.CfnBucket.ServerSideEncryptionRuleProperty(
                    bucket_key_enabled=False,
                    server_side_encryption_by_default=aws_s3.CfnBucket.ServerSideEncryptionByDefaultProperty(
                        sse_algorithm="aws:kms",
                        kms_master_key_id=kms_key.key_arn
                    ) if kms_key else aws_s3.CfnBucket.ServerSideEncryptionByDefaultProperty(
                        sse_algorithm="AES256"
                    )
                )
            ]
        ),
        lifecycle_configuration=aws_s3.CfnBucket.LifecycleConfigurationProperty(
            rules=lifecycle_configuration_rules
        ) if lifecycle_configuration_rules else None,
        replication_configuration=replication_configuration_property,
        notification_configuration=aws_s3.CfnBucket.NotificationConfigurationProperty(
            queue_configurations=queues_notifications_properties
        ) if queues_notifications_properties else None
    )
    bucket.apply_removal_policy(RemovalPolicy.RETAIN)

    # add bucket policy
    policy_statements = handle_default_bucket_policy_statement_creation(
        self,
        bucket.bucket_name,
        bucket_props.get("bucketRoleAuthorized"),
        bucket_props.get("bucketPrincipalAuthorized"),
        bucket_props.get("bucketPrincipalServiceAuthorized"),
        bucket_props.get("sslOnly")
    )
    if "policyStatement" in bucket_props:
        policy_statements.extend([
            handle_policy_statement_creation(self, statement) for statement in bucket_props["policyStatement"]
            if statement is not None
        ]
        )

    bucket_policy = None
    if len(policy_statements) > 0:
        bucket_policy = aws_s3.CfnBucketPolicy(
            self,
            bucket_props["bucketPolicyId"],
            bucket=bucket.bucket_name,
            policy_document=aws_iam.PolicyDocument(statements=policy_statements)
        )
        bucket_policy.apply_removal_policy(RemovalPolicy.RETAIN)
        bucket_policy.add_depends_on(bucket)
    else:
        print("***************************************************************************")
        print("0 policy statement ? WHEN this is encounter ???")
        print("***************************************************************************")

    # Handle cfnOutputsExports
    if "exports" in bucket_props:
        handle_bucket_exports_creation(self, bucket_props["exports"], bucket)

    return {
        "bucket": bucket,
        "bucketPolicy": bucket_policy,
    }


def handle_bucket_exports_creation(self, export_props, bucket):
    """

    """
    for key, item in export_props.items():
        if key == "arn":
            value = bucket.attr_arn

        elif key == "name":
            value = bucket.bucket_name

        else:
            raise ValueError('<< bucket exports object>> must contain keys in ["arn", "name"]')

        CfnOutput(
            self,
            item["cdkId"],
            value=value,
            description=item["cfnOutputDescription"] if "cfnOutputDescription" in item else None,
            export_name=item["cfnOutputName"]
        )


def handle_lifecycle_configuration_rules_creation(props):
    """

    """
    lifecycle_configuration_rule = aws_s3.CfnBucket.RuleProperty(
        id=props["id"],
        prefix=props["prefix"],
        status="Enabled",
        expiration_in_days=props["expirationInDays"],
        noncurrent_version_expiration=aws_s3.CfnBucket.NoncurrentVersionExpirationProperty(
            noncurrent_days=props["nonCurrentVersionExpirationInDays"]
        ),
        transition=aws_s3.CfnBucket.TransitionProperty(
            storage_class=props["transition"]["storageClass"],
            transition_in_days=props["transition"]["transitionInDays"]
        ) if "transition" in props else None
    )
    return lifecycle_configuration_rule


# POLICY
def handle_default_bucket_policy_statement_creation(
        self,
        bucket_name,
        role_authorized=None,
        principal_authorized=None,
        principal_service_authorized=None,
        ssl_only=None
):

    if not role_authorized:
        role_authorized = []
    else:
        role_authorized = [role for role in role_authorized if role is not None]

    if not principal_authorized:
        principal_authorized = []
    else:
        principal_authorized = [principal for principal in principal_authorized if principal is not None]

    if not principal_service_authorized:
        principal_service_authorized = []
    else:
        principal_service_authorized = [principal_service for principal_service in principal_service_authorized
                                        if principal_service is not None]

    policy_statement_list = []

    statements = {
        "Deny": {
            "sid": "Default - "
                   "Explicit deny except whitelisted roles, root, admin and cdk",
            "effect": aws_iam.Effect.DENY,
            "principals": [aws_iam.AnyPrincipal()],
            "actions": ["S3:*"],
            "resources": [
                f'{s3_arn_prefix}{bucket_name}',
                f'{s3_arn_prefix}{bucket_name}/*'
            ],
            "conditions": {
                "arnNotLike": {
                    aws_principal_arn_prefix: {
                        "wysiwyg": [f"{iam_arn_prefix}{self.account}:root"] +
                                   [principal.arn for principal in principal_authorized],
                        "fromRoleArn": [
                            {"roleKey": "roleUserAdministrator", "roleConstructor": None},
                            {"roleKey": "roleCdkExecution", "roleConstructor": None}
                        ] + role_authorized,
                    },
                },
            }
        }
    }
    if principal_service_authorized:
        statements["Deny"]["conditions"]["stringNotLike"] = {
            aws_principal_service_name: {
                "wysiwyg": principal_service_authorized
            }
        }

    if ssl_only:
        statements["sslOnly"] = {
            "sid": "Custom - explicit deny for all non SSL connections",
            "effect": aws_iam.Effect.DENY,
            "principals": [aws_iam.AnyPrincipal()],
            "actions": ["S3:*"],
            "resources": [
                f'{s3_arn_prefix}{bucket_name}',
                f'{s3_arn_prefix}{bucket_name}/*'
            ],
            "conditions": {
                "bool": {"aws:SecureTransport": False}
            }
        }

    for statement, statement_props in statements.items():
        policy_statement = handle_policy_statement_creation(self, statement_props)
        policy_statement_list.append(policy_statement)

    return policy_statement_list


def handle_default_kms_policy_statement_creation(
        self,
        role_authorized=None,
        principal_authorized=None,
        principal_service_authorized=None
):

    policy_statement_list = []

    if not role_authorized:
        role_authorized = []
    else:
        role_authorized = [role for role in role_authorized if role is not None]

    if not principal_authorized:
        principal_authorized = []
    else:
        principal_authorized = [principal for principal in principal_authorized if principal is not None]

    if not principal_service_authorized:
        principal_service_authorized = []
    else:
        principal_service_authorized = [principal_service for principal_service in principal_service_authorized
                                        if principal_service is not None]

    statements = {
        "Deny": {
            "sid": "Default - "
                   "Explicit deny except whitelisted roles, root, admin and cdk",
            "effect": aws_iam.Effect.DENY,
            "principals": [aws_iam.AnyPrincipal()],
            "actions": ["kms:*"],
            "resources": ["*"],
            "conditions": {
                "arnNotLike": {
                    aws_principal_arn_prefix: {
                        "wysiwyg": [f"{iam_arn_prefix}{self.account}:root"] +
                                   [principal.arn for principal in principal_authorized],
                        "fromRoleArn": [
                            {"roleKey": "roleUserAdministrator", "roleConstructor": None},
                            {"roleKey": "roleCdkExecution", "roleConstructor": None},
                        ] + role_authorized
                    }
                }
            }
        },
        "AllowRoot": {
            "sid": "Default - Allow access for Key Administrators: root, admin and cdk",
            "effect": aws_iam.Effect.ALLOW,
            "principalsRoleList": [
                {"roleKey": "roleUserAdministrator", "roleConstructor": None},
                {"roleKey": "roleCdkExecution", "roleConstructor": None},
            ],
            "principals": [
                aws_iam.ArnPrincipal(f'{iam_arn_prefix}{self.account}:root'),
            ],
            "actions": ["kms:*"],
            "resources": ["*"]
        },

    }

    if principal_service_authorized:
        statements["Deny"]["conditions"]["stringNotLike"] = {
            aws_principal_service_name: {
                "wysiwyg": principal_service_authorized
            }
        }
        statements["AllowRoot"]["principals"] += [aws_iam.ServicePrincipal(principal_service)
                                                  for principal_service in principal_service_authorized
                                                  if "*" not in principal_service]

    if role_authorized or principal_authorized:
        statements["AllowUser"] = {
            "sid": "Custom - Allow use of the key for whitelisted roles and principals",
            "effect": aws_iam.Effect.ALLOW,
            "principalsRoleList": role_authorized,
            "principals": principal_authorized,
            "resources": ["*"],
            "actions": [
                "kms:DescribeKey",
                "kms:Encrypt",
                "kms:Decrypt",
                "kms:ReEncrypt*",
                "kms:GenerateDataKey",
                "kms:GenerateDataKeyWithoutPlaintext",
                "kms:CreateGrant"
            ],
        }

    for statement, statement_props in statements.items():
        policy_statement = handle_policy_statement_creation(self, statement_props)
        policy_statement_list.append(policy_statement)

    return policy_statement_list


def handle_policy_statement_creation(self, statement):
    """

    """
    principals = []

    if "principalsRoleList" in statement:
        principals = [
            aws_iam.ArnPrincipal(retrieve_role_attr(self, "arn", principal))
            for principal in statement["principalsRoleList"] if principal is not None
        ]

    if "principals" in statement:
        principals.extend([principal for principal in statement["principals"] if principal is not None])

    conditions = None
    if "conditions" in statement:
        conditions = {}

        if "stringLike" in statement["conditions"]:
            conditions["StringLike"] = {}
            for key, value in statement["conditions"]["stringLike"].items():
                conditions["StringLike"][key] = handle_condition_string_list_creation(
                    self,
                    value
                )

        if "stringNotLike" in statement["conditions"]:
            conditions["StringNotLike"] = {}
            for key, value in statement["conditions"]["stringNotLike"].items():
                conditions["StringNotLike"][key] = handle_condition_string_list_creation(
                    self,
                    value
                )

        if "arnNotLike" in statement["conditions"]:
            conditions["ArnNotLike"] = {}
            for key, value in statement["conditions"]["arnNotLike"].items():
                conditions["ArnNotLike"][key] = handle_condition_string_list_creation(
                    self,
                    value
                )

        if "arnEquals" in statement["conditions"]:
            conditions["ArnEquals"] = {
                aws_source_arn_prefix: handle_condition_string_list_creation(
                    self,
                    statement["conditions"]["arnEquals"]
                )
            }

        if "stringEquals" in statement["conditions"]:
            conditions["StringEquals"] = statement["conditions"]["stringEquals"]

        if "stringNotEquals" in statement["conditions"]:
            conditions["StringNotEquals"] = {}
            for key, value in statement["conditions"]["stringNotEquals"].items():
                conditions["StringNotEquals"][key] = handle_condition_string_list_creation(
                    self,
                    value
                )

        if "bool" in statement["conditions"]:
            conditions["Bool"] = statement["conditions"]["bool"]

    if len(principals) > 0:
        policy_statement = aws_iam.PolicyStatement(
            sid=statement["sid"] if "sid" in statement else None,
            effect=statement["effect"],
            principals=principals,
            actions=statement["actions"],
            resources=statement["resources"],
            conditions=conditions
        )

        return policy_statement
    else:
        raise ValueError("No principal given for policy statement creation")


def handle_condition_string_list_creation(self, string_condition_props):
    """

    """
    string_list = []
    if string_condition_props.get("wysiwyg"):
        string_list.extend([item for item in string_condition_props["wysiwyg"]])

    if string_condition_props.get("fromRoleId"):
        string_list.extend([f'{retrieve_role_attr(self, "id", item)}:*'
                            for item in string_condition_props["fromRoleId"]])

    if string_condition_props.get("fromRoleArn"):
        string_list.extend([f'{retrieve_role_attr(self, "arn", item)}'
                            for item in string_condition_props["fromRoleArn"]])

    if string_condition_props.get(aws_source_arn_prefix):
        string_list.extend([item for item in string_condition_props[aws_source_arn_prefix]])

    return string_list


def handle_events_rule_creation(self, events_rule_props):
    """

    """
    if events_rule_props["constructor"] == aws_events_rule:
        events_targets = []
        # Handle events targets types
        for target in events_rule_props["targets"]:
            if type(target) is aws_lambda.Function:
                events_targets.append(aws_events_targets.LambdaFunction(target))

        rule = aws_events.Rule(
            self,
            events_rule_props["cdkId"],
            rule_name=events_rule_props["ruleName"],
            description=events_rule_props["description"] if "description" in events_rule_props else None,
            enabled=events_rule_props["enabled"],
            schedule=aws_events.Schedule.expression(f'cron({events_rule_props["schedule"]})')
            if "schedule" in events_rule_props else None,
            targets=[target for target in events_targets],
            event_pattern=aws_events.EventPattern(
                source=events_rule_props["event_pattern"]["source"],
                detail_type=events_rule_props["event_pattern"]["detail_type"],
                detail=events_rule_props["event_pattern"]["detail"],
            ) if "event_pattern" in events_rule_props else None
        )

        # Check the targets - looking for extra actions depends on the target type
        for target in events_rule_props["targets"]:
            if type(target) is aws_events_targets.LambdaFunction:
                # Add Events Permission to the targeted-lambda with the rule as source
                target.add_permission(
                    f'{events_rule_props["cdkId"]}EventsPermission',
                    action="lambda:InvokeFunction",
                    principal=aws_iam.ServicePrincipal("events.amazonaws.com"),
                    source_arn=rule.rule_arn
                )

        return rule

    elif events_rule_props["constructor"] == aws_events_rule_cfn:
        rule = aws_events.CfnRule(
            self,
            events_rule_props["cdkId"],
            name=events_rule_props["ruleName"],
            description=events_rule_props["description"] if "description" in events_rule_props else None,
            state="ENABLED" if events_rule_props["enabled"] is True else "DISABLED",
            schedule_expression=f'cron({events_rule_props["schedule"]})',
            targets=[
                aws_events.CfnRule.TargetProperty(
                    arn=target["arn"],
                    id=target["id"],
                    input_transformer=aws_events.CfnRule.InputTransformerProperty(
                        input_template=json.dumps(target["inputTransformer"]["inputTemplate"]),
                        input_paths_map=target["inputTransformer"]["inputPathsMap"]
                        if "inputPathsMap" in target["inputTransformer"] else None,
                    ),
                    sqs_parameters=aws_events.CfnRule.SqsParametersProperty(
                        message_group_id=target["sqsParametersGroupId"]
                    ) if "sqsParametersGroupId" in target else None,
                ) for target in events_rule_props["targets"]
            ]
        )

        return rule

    else:
        raise ValueError(f'Events Rule constructor property of ruleName {events_rule_props["ruleName"]} must be in ' +
                         f'[{aws_events_rule}, {aws_events_rule_cfn}]')


def handle_sqs_queue_creation(self, sqs_queue_props):
    """

    """
    sqs_queue = aws_sqs.Queue(
        self,
        sqs_queue_props["cdkId"],
        queue_name=sqs_queue_props["queueName"],
        fifo=sqs_queue_props["fifoQueue"],
        retention_period=Duration.seconds(sqs_queue_props["retentionPeriodSeconds"]),
        content_based_deduplication=sqs_queue_props["contentBasedDeduplication"],
        deduplication_scope=aws_sqs.DeduplicationScope[f'{sqs_queue_props["deduplicationScope"]}']
        if "deduplicationScope" in sqs_queue_props else None,
        receive_message_wait_time=Duration.seconds(sqs_queue_props["receiveMessageWaitTimeSeconds"]),
        visibility_timeout=Duration.seconds(sqs_queue_props["visibilityTimeoutSeconds"]),
    )
    if "lambdaAsDestination" in sqs_queue_props:
        sqs_queue_props["lambdaAsDestination"].add_permission(
            f'{__get_logical_id(self, sqs_queue_props["lambdaAsDestination"])}SqsPermission',
            action="lambda:InvokeFunction",
            principal=aws_iam.ServicePrincipal("sqs.amazonaws.com"),
            source_arn=sqs_queue.queue_arn
        )
        sqs_queue_props["lambdaAsDestination"].add_event_source_mapping(
            f'{__get_logical_id(self, sqs_queue_props["lambdaAsDestination"])}EventSourceMapping',
            batch_size=1,
            enabled=True,
            event_source_arn=sqs_queue.queue_arn,
        )
    return sqs_queue


# note: known bug here https://github.com/aws/aws-cdk/issues/8550
def handle_cfn_sqs_queue_creation(self, sqs_queue_props):
    sqs_queue = aws_sqs.CfnQueue(
        self,
        sqs_queue_props["cdkId"],
        queue_name=sqs_queue_props["queueName"],
        fifo_queue=True if sqs_queue_props["fifoQueue"] else None,
        message_retention_period=sqs_queue_props["retentionPeriodSeconds"],
        receive_message_wait_time_seconds=sqs_queue_props["receiveMessageWaitTimeSeconds"],
        visibility_timeout=sqs_queue_props["visibilityTimeoutSeconds"],
        redrive_policy={
            "deadLetterTargetArn": sqs_queue_props["redrive_policy"]["deadLetterTargetArn"],
            "maxReceiveCount": sqs_queue_props["redrive_policy"]["maxReceiveCount"]
        } if "redrive_policy" in sqs_queue_props else None
    )
    return sqs_queue


def handle_dynamodb_table_creation(self, dynamodb_table_props):
    """

    """
    dynamodb_cfn_table = aws_dynamodb.CfnTable(
        self,
        dynamodb_table_props["cdkId"],
        table_name=dynamodb_table_props["tableName"],
        billing_mode=dynamodb_table_props["billingMode"],
        attribute_definitions=[aws_dynamodb.CfnTable.AttributeDefinitionProperty(
            attribute_name=attribute["attributeName"],
            attribute_type=attribute["attributeType"],
        ) for attribute in dynamodb_table_props["attributeDefinitions"]],
        key_schema=[aws_dynamodb.CfnTable.KeySchemaProperty(
            attribute_name=schema["attributeName"],
            key_type=schema["keyType"],
        ) for schema in dynamodb_table_props["keySchema"]],
        global_secondary_indexes=[
            aws_dynamodb.CfnTable.GlobalSecondaryIndexProperty(
                index_name=index["indexName"],
                key_schema=[aws_dynamodb.CfnTable.KeySchemaProperty(
                    attribute_name=index_schema["attributeName"],
                    key_type=index_schema["keyType"],
                ) for index_schema in index["keySchema"]],
                projection=aws_dynamodb.CfnTable.ProjectionProperty(
                    non_key_attributes=index["projection"]["nonKeyAttributes"]
                    if "nonKeyAttributes" in index["projection"] else None,
                    projection_type=index["projection"]["projectionType"],
                ),
            ) for index in dynamodb_table_props["globalSecondaryIndexes"]
        ] if "globalSecondaryIndexes" in dynamodb_table_props else None,
        stream_specification=aws_dynamodb.CfnTable.StreamSpecificationProperty(
            stream_view_type=dynamodb_table_props["streamSpecification"]["streamViewType"]
        ) if "streamSpecification" in dynamodb_table_props else None,
    )
    dynamodb_cfn_table.apply_removal_policy(RemovalPolicy.RETAIN)

    return dynamodb_cfn_table


def handle_glue_database_creation(self, database_props):
    """

    """
    database = aws_glue.CfnDatabase(
        self,
        database_props["cdkId"],
        catalog_id=f"{self.account}",
        database_input=aws_glue.CfnDatabase.DatabaseInputProperty(
            description=database_props["databaseDescription"],
            name=database_props["databaseName"],
        )
    )
    # Handle exports for both classParameter and cfnOutputs
    if "exports" in database_props:
        for key, item in database_props["exports"].items():
            if key == "databaseName":
                setattr(self, item["cdkId"], database.database_input.name)
                CfnOutput(
                    self,
                    item["cdkId"],
                    value=database.database_input.name,
                    description=item["cfnOutputDescription"],
                    export_name=item["cfnOutputName"]
                )

    return database


def handle_glue_table_creation(self, database, table_props):
    """

    """
    # Define partition keys
    table_partition_keys = []
    for partition_key in (table_props["tablePartitionKeys"]):
        table_partition_keys.append(
            aws_glue.CfnTable.ColumnProperty(
                name=partition_key["partitionKeyName"],
                type=partition_key["partitionKeyType"]
            )
        )

    # Define table
    table = aws_glue.CfnTable(
        self,
        table_props["cdkId"],
        catalog_id=f"{self.account}",
        database_name=database.database_input.name,
        table_input=aws_glue.CfnTable.TableInputProperty(
            description=table_props["tableDescription"],
            name=table_props["tableName"],
            partition_keys=table_partition_keys,
            parameters=table_props["tableParameters"],
            storage_descriptor=aws_glue.CfnTable.StorageDescriptorProperty(
                input_format=table_props["storageInputFormat"],
                output_format=table_props["storageOutputFormat"],
                columns=[
                    aws_glue.CfnTable.ColumnProperty(
                        name=column,
                        type="string"
                    ) for column in table_props["storageColumns"]
                ],
                serde_info=aws_glue.CfnTable.SerdeInfoProperty(
                    parameters=table_props["serdeInfoParameters"]
                    if "serdeInfoParameters" in table_props else None,
                    serialization_library=table_props["serdeInfoSerializationLib"]
                ),
                location=f'{table_props["tableLocationPrefix"]}{table_props["tableName"]}',
            ),
            table_type=table_props["tableType"]
        )
    )

    # Handle exports for both classParameter and cfnOutputs
    if "exports" in table_props:
        for key, item in table_props["exports"].items():
            if key == "tableName":
                setattr(self, item["cdkId"], table.table_input.name)
                CfnOutput(
                    self,
                    item["cdkId"],
                    value=table.table_input.name,
                    description=item["cfnOutputDescription"],
                    export_name=item["cfnOutputName"]
                )

    return table


def handle_firehose_datastream_creation(self, deliverystream_props):
    delivery_stream = aws_kinesisfirehose.CfnDeliveryStream(
        self,
        deliverystream_props["cdkId"],
        delivery_stream_name=deliverystream_props["deliveryStreamName"],
        delivery_stream_type=deliverystream_props["deliveryStreamType"],
        extended_s3_destination_configuration=aws_kinesisfirehose.CfnDeliveryStream.ExtendedS3DestinationConfigurationProperty(
            bucket_arn=deliverystream_props["ExtendedS3DestinationConfiguration"]["bucket_arn"],
            role_arn=deliverystream_props["ExtendedS3DestinationConfiguration"]["role_arn"],
            buffering_hints=aws_kinesisfirehose.CfnDeliveryStream.BufferingHintsProperty(
                interval_in_seconds=deliverystream_props["ExtendedS3DestinationConfiguration"]["interval_in_seconds"],
                size_in_m_bs=deliverystream_props["ExtendedS3DestinationConfiguration"]["size_in_mBs"]
            ),
            cloud_watch_logging_options=aws_kinesisfirehose.CfnDeliveryStream.CloudWatchLoggingOptionsProperty(
                enabled=deliverystream_props["ExtendedS3DestinationConfiguration"]["CloudWatchLogging"],
                log_group_name=deliverystream_props["ExtendedS3DestinationConfiguration"]["logGroupName"],
                log_stream_name=deliverystream_props["ExtendedS3DestinationConfiguration"]["logStreamName"]
            ) if "CloudWatchLogging" in deliverystream_props["ExtendedS3DestinationConfiguration"] else None,
            dynamic_partitioning_configuration=aws_kinesisfirehose.CfnDeliveryStream.DynamicPartitioningConfigurationProperty(
                enabled=True,
                retry_options=aws_kinesisfirehose.CfnDeliveryStream.RetryOptionsProperty(
                    duration_in_seconds=
                    deliverystream_props["ExtendedS3DestinationConfiguration"]["dynamicPartitioningConfiguration"][
                        "dynamicPartitionRetry"]
                )
            ) if "dynamicPartitioningConfiguration" in deliverystream_props["ExtendedS3DestinationConfiguration"] else None,
            prefix=deliverystream_props["ExtendedS3DestinationConfiguration"]["prefix"]
            if "prefix" in deliverystream_props["ExtendedS3DestinationConfiguration"] else None,
            error_output_prefix=deliverystream_props["ExtendedS3DestinationConfiguration"]["errorPrefix"]
            if "errorPrefix" in deliverystream_props["ExtendedS3DestinationConfiguration"] else None,
            processing_configuration=aws_kinesisfirehose.CfnDeliveryStream.ProcessingConfigurationProperty(
                enabled=True,
                processors=[aws_kinesisfirehose.CfnDeliveryStream.ProcessorProperty(
                    type="Lambda",
                    parameters=[
                        aws_kinesisfirehose.CfnDeliveryStream.ProcessorParameterProperty(
                            parameter_name="LambdaArn",
                            parameter_value=deliverystream_props["ExtendedS3DestinationConfiguration"][
                                "lambda_processor_arn"]
                        ),
                        aws_kinesisfirehose.CfnDeliveryStream.ProcessorParameterProperty(
                            parameter_name="BufferIntervalInSeconds",
                            parameter_value="120"
                        ),
                        aws_kinesisfirehose.CfnDeliveryStream.ProcessorParameterProperty(
                            parameter_name="BufferSizeInMBs",
                            parameter_value="3"
                        ),
                        aws_kinesisfirehose.CfnDeliveryStream.ProcessorParameterProperty(
                            parameter_name="NumberOfRetries",
                            parameter_value="2"
                        )
                    ]
                )]
            ) if "lambda_processor_arn" in deliverystream_props["ExtendedS3DestinationConfiguration"] else None
        ) if "ExtendedS3DestinationConfiguration" in deliverystream_props else None
    )

    return delivery_stream


def handle_policy_creation(self, resource_id, policy_name, statements_list,
                           description=None, imported=False, exports_props=None):
    """
    :return: object aws_iam.ManagedPolicy
    """

    if imported:
        policy = aws_iam.ManagedPolicy.from_managed_policy_name(
            self,
            resource_id,
            managed_policy_name=policy_name
        )

    else:
        policy = aws_iam.ManagedPolicy(
            self,
            resource_id,
            managed_policy_name=policy_name,
            description=description,
            statements=[
                aws_iam.PolicyStatement(
                    actions=statement["actions"],
                    resources=statement["resources"],
                    effect=statement["effect"]
                ) for statement in statements_list if statement is not None
            ]
        )
        if exports_props:
            handle_policy_exports_creation(self, exports_props=exports_props, policy=policy)
    return policy


def add_managed_policy(self, managed_policies_config):
    managed_policies = []

    if "inbuilt" in managed_policies_config:
        managed_policies.extend(
            [
                self.policy_container[policy] if "policy_container" in dir(self) else self.container["policy"][policy]
                for policy in managed_policies_config["inbuilt"]
            ]
        )

    if "awsPolicy" in managed_policies_config:
        managed_policies.extend(
            [aws_iam.ManagedPolicy.from_aws_managed_policy_name(policy_name)
             for policy_name in managed_policies_config["awsPolicy"]]
        )

    return managed_policies


def handle_role_creation(self, role_props):
    try:
        if not role_props["constructor"]:
            raise KeyError(f"The <<constructor>> role type is missing in role definition")

        if role_props["constructor"] == aws_iam_role:
            role = aws_iam.Role(
                self,
                role_props["cdkId"],
                role_name=role_props["roleName"],
                assumed_by=aws_iam.ServicePrincipal(role_props["assumedBy"]),
                description=role_props["description"] if "description" in role_props else None,
                managed_policies=add_managed_policy(self, role_props["managedPolicies"]),
                max_session_duration=Duration.seconds(int(role_props["maxSessionDuration"]))
                if "maxSessionDuration" in role_props else None
            )
        elif role_props["constructor"] == aws_iam_role_cfn:
            role = aws_iam.CfnRole(
                self,
                role_props["cdkId"],
                role_name=role_props["roleName"],
                assume_role_policy_document=role_props["assumeRolePolicyDocument"],
                description=role_props["description"] if "description" in role_props else None,
                managed_policy_arns=[
                    policy.managed_policy_arn for policy in add_managed_policy(self, role_props["managedPolicies"])
                ],
                max_session_duration=int(role_props["maxSessionDuration"])
                if "maxSessionDuration" in role_props else None
            )
        else:
            raise ValueError(
                f"Role constructor property of {role_props['roleName']} must be in "
                f"[{aws_iam_role}, {aws_iam_role_cfn}]"
            )
        return role

    except Exception as ex:
        print(f"Unknown exception occurred during role creation: {ex}")
        print("If a 'policy_name' is present in exception message, check if the policy exist in the container in self")


def handle_instance_profile_creation(self, instance_profile_props):
    instance_profile = aws_iam.CfnInstanceProfile(
        self,
        instance_profile_props["cdkId"],
        roles=instance_profile_props["roles"],
        instance_profile_name=instance_profile_props["instanceProfileName"]
    )
    return instance_profile


def handle_ec2_creation(self, ec2_props):
    instance_profile = None
    if "iamInstanceProfile" in ec2_props:
        instance_profile = aws_iam.CfnInstanceProfile(
            self,
            ec2_props["iamInstanceProfile"]["cdkId"],
            roles=[role_name for role_name in ec2_props["iamInstanceProfile"]["roles"]],
            instance_profile_name=ec2_props["iamInstanceProfile"]["instanceProfileName"]
        )
    ec2 = aws_ec2.CfnInstance(
        self,
        ec2_props["cdkId"],
        additional_info=ec2_props["additionalInfo"],
        key_name=ec2_props["keyName"],
        image_id=ec2_props["imageId"],
        instance_type=ec2_props["instanceType"],
        network_interfaces=ec2_props["networkInterfaces"],
        disable_api_termination=ec2_props["disableApiTermination"],
        ebs_optimized=ec2_props["ebsOptimized"],
        block_device_mappings=ec2_props["blockDeviceMappings"],
        hibernation_options=ec2_props["hibernationOptions"],
        instance_initiated_shutdown_behavior=ec2_props["instanceInitiatedShutdownBehavior"],
        iam_instance_profile=instance_profile.instance_profile_name,
        tags=ec2_props["tags"],
        monitoring=ec2_props["monitoring"],
        user_data=ec2_props["userData"] if "userData" in ec2_props else None
    )

    return ec2


def handle_policy_exports_creation(self, exports_props, policy):
    """
    """
    for key, item in exports_props.items():
        if key == "arn":
            value = policy.managed_policy_arn

        else:
            raise ValueError(f'<<policy exports object>> must contain keys in ["arn"]')

        CfnOutput(
            self,
            item["cdkId"],
            value=value,
            description=item["cfnOutputDescription"] if "cfnOutputDescription" in item else None,
            export_name=item["cfnOutputName"]
        )


def encode_ec2_userdata(raw_data):
    """
    :param raw_data: list of strings
    :return: encoded raw data to ec2 linux expected format
    """
    user_data = aws_ec2.UserData.for_linux()

    for raw in raw_data:
        user_data.add_commands(raw)

    user_data_bytes = user_data.render().encode("ascii")
    user_data_base64_bytes = base64.b64encode(user_data_bytes)
    user_data_base64_string = user_data_base64_bytes.decode("ascii")

    return user_data_base64_string

#!/usr/bin/env python3
from aws_cdk import (
    App,
    Environment,
    DefaultStackSynthesizer
)

from cdk_stacks.config import (
    DEPLOY_ROLE_ARN,
    FILE_ASSET_PUBLISHING_ROLE_ARN,
    IMAGE_ASSET_PUBLISHING_ROLE_ARN,
    CLOUD_FORMATION_EXECUTION_ROLE,
    BOOTSTRAP_STACK_VERSION_SSM_PARAMETER,
    ENV
)
from cdk_2s33_method.colors import Colors

from cdk_stacks.shared_resources.cdk_shared_resources import CdkSharedResources
from cdk_stacks.playground_stateful.cdk_playground_stateful import CdkPlaygroundStateful
from cdk_stacks.playground_stateless.cdk_playground_stateless import CdkPlaygroundStateless
from cdk_stacks.data_lake_stateful.cdk_data_lake_stateful import CdkDataLakeStateful
from cdk_stacks.data_lake_stateless.cdk_data_lake_stateless import CdkDataLakeStateless
from cdk_stacks.orchestration_stateful.cdk_orchestration_stateful import CdkOrchestrationStateful
from cdk_stacks.orchestration_stateless.cdk_orchestration_stateless import CdkOrchestrationStateless
from cdk_stacks.monitoring.cdk_monitoring import CdkMonitoring
from cdk_stacks.deployer.cdk_deployer import CdkDeployer
from cdk_stacks.log_shipping.cdk_log_shipping import CdkLogShipping
from cdk_stacks.ami_factory.cdk_ami_factory import CdkAmiFactory
from cdk_stacks.nifi_stateful.nifi_stateful import CdkNifiStateful
from cdk_stacks.nifi_stateless.nifi_stateless import CdkNifiStateless
from cdk_stacks.devops.cdk_devops import CdkDevOps


app = App()
context = app.node.try_get_context(ENV)
# print(f"Context data are: {json.dumps(context, indent=2)}")


def handle_synthesizer_creation():
    synthesizer = DefaultStackSynthesizer(
        deploy_role_arn=DEPLOY_ROLE_ARN,
        file_asset_publishing_role_arn=FILE_ASSET_PUBLISHING_ROLE_ARN,
        image_asset_publishing_role_arn=IMAGE_ASSET_PUBLISHING_ROLE_ARN,
        cloud_formation_execution_role=CLOUD_FORMATION_EXECUTION_ROLE,
        bootstrap_stack_version_ssm_parameter=BOOTSTRAP_STACK_VERSION_SSM_PARAMETER
    )
    return synthesizer


STACK_ENV_CONF = {
    "CdkSharedResourcesStack":          {"dev": True, "int": True, "prod": True},
    "CdkPlaygroundStatefulStack":       {"dev": True, "int": True, "prod": True},
    "CdkPlaygroundStatelessStack":      {"dev": True, "int": True, "prod": True},
    "CdkDataLakeStatefulStack":         {"dev": True, "int": True, "prod": True},
    "CdkDataLakeStatelessStack":        {"dev": True, "int": True, "prod": True},
    "CdkOrchestrationStatefulStack":    {"dev": True, "int": True, "prod": True},
    "CdkOrchestrationStatelessStack":   {"dev": True, "int": True, "prod": True},
    "CdkMonitoringStack":               {"dev": True, "int": True, "prod": True},
    "CdkLogShippingStack":              {"dev": True, "int": True, "prod": True},
    "CdkDeployerStack":                 {"dev": True, "int": True, "prod": True},
    "CdkNifiStatefulStack":             {"dev": False, "int": False, "prod": False},
    "CdkNifiStatelessStack":            {"dev": False, "int": False, "prod": False},
    "CdkAmiFactoryStack":               {"dev": True, "int": False, "prod": False},
    "CdkDevOpsStack":                   {"dev": True, "int": False, "prod": False},
}

print(f"############################################")
print(f"# Stack Deployment configuration for {ENV} #")
print(f"############################################")
for stack_name, config in STACK_ENV_CONF.items():
    if config[ENV]:
        color = Colors.GREEN
    else:
        color = Colors.WARNING
    print(f"{stack_name}:   {color}{config[ENV]}{Colors.ENDC}")
print(f"######################################")
print(f"# Stack Deployment configuration END #")
print(f"######################################")


CdkSharedResourcesStack = CdkSharedResources(
    app,
    "CdkSharedResources",
    synthesizer=handle_synthesizer_creation(),
    env=Environment(account=context["accountId"], region=context["region"])
) if STACK_ENV_CONF["CdkSharedResourcesStack"][ENV] else None

CdkPlaygroundStatefulStack = CdkPlaygroundStateful(
    app,
    "CdkPlaygroundStateful",
    synthesizer=handle_synthesizer_creation(),
    env=Environment(account=context["accountId"], region=context["region"]),
    role_container=CdkSharedResourcesStack.CdkIamNestedStack.role_container
) if STACK_ENV_CONF["CdkPlaygroundStatefulStack"][ENV] else None

CdkPlaygroundStatelessStack = CdkPlaygroundStateless(
    app,
    "CdkPlaygroundStateless",
    synthesizer=handle_synthesizer_creation(),
    env=Environment(account=context["accountId"], region=context["region"]),
    notebook_kms_key=CdkPlaygroundStatefulStack.kms_container["notebook"],
    cdk_notebook_backup_bucket=CdkPlaygroundStatefulStack.bucket_container["notebook-backup"],
    role_sagemaker_playground=CdkSharedResourcesStack.CdkIamNestedStack.role_container["role_sagemaker_playground"],
    layer_croniter=CdkSharedResourcesStack.CdkLayersNestedStack.layer_container["layer_croniter"],
    layer_custom_logging=CdkSharedResourcesStack.CdkLayersNestedStack.layer_container["layer_custom_logging"]
) if STACK_ENV_CONF["CdkPlaygroundStatelessStack"][ENV] else None

CdkDataLakeStatefulStack = CdkDataLakeStateful(
    app,
    "CdkDataLakeStateful",
    synthesizer=handle_synthesizer_creation(),
    env=Environment(account=context["accountId"], region=context["region"]),
    role_container=CdkSharedResourcesStack.CdkIamNestedStack.role_container
) if STACK_ENV_CONF["CdkDataLakeStatefulStack"][ENV] else None

CdkDataLakeStatelessStack = CdkDataLakeStateless(
    app,
    "CdkDataLakeStateless",
    synthesizer=handle_synthesizer_creation(),
    env=Environment(account=context["accountId"], region=context["region"]),
    bucket_scheduled_raw_data=CdkDataLakeStatefulStack.bucket_container["raw-data"]
) if STACK_ENV_CONF["CdkDataLakeStatelessStack"][ENV] else None

CdkOrchestrationStatefulStack = CdkOrchestrationStateful(
    app,
    "CdkOrchestrationStateful",
    synthesizer=handle_synthesizer_creation(),
    env=Environment(account=context["accountId"], region=context["region"]),
    role_container=CdkSharedResourcesStack.CdkIamNestedStack.role_container
) if STACK_ENV_CONF["CdkOrchestrationStatefulStack"][ENV] else None

CdkOrchestrationStatelessStack = CdkOrchestrationStateless(
    app,
    "CdkOrchestrationStateless",
    synthesizer=handle_synthesizer_creation(),
    env=Environment(account=context["accountId"], region=context["region"]),
    vpc=CdkSharedResourcesStack.vpc,
    subnet_container=CdkSharedResourcesStack.container["subnet"],
    secg_2s33_computing_lambda=CdkSharedResourcesStack.container["security_group"]["secg_2s33_computing_lambda"],
    layer_container=CdkSharedResourcesStack.CdkLayersNestedStack.layer_container,
    bucket_scheduled_athena_query_results=CdkDataLakeStatefulStack.bucket_container["athena-query-results"],
    glue_database_container=CdkDataLakeStatelessStack.glue_database_container,
    role_container=CdkSharedResourcesStack.CdkIamNestedStack.role_container,
    dynamodb_container=CdkOrchestrationStatefulStack.dynamodb_container
) if STACK_ENV_CONF["CdkOrchestrationStatelessStack"][ENV] else None

CdkLogShippingStack = CdkLogShipping(
    app,
    "CdkLogShipping",
    synthesizer=handle_synthesizer_creation(),
    env=Environment(account=context["accountId"], region=context["region"]),
    layer_container=CdkSharedResourcesStack.CdkLayersNestedStack.layer_container
) if STACK_ENV_CONF["CdkLogShippingStack"][ENV] else None

CdkMonitoringStack = CdkMonitoring(
    app,
    "CdkMonitoring",
    synthesizer=handle_synthesizer_creation(),
    env=Environment(account=context["accountId"], region=context["region"]),
    bucket_container_data_lake=CdkDataLakeStatefulStack.bucket_container,
    layer_container=CdkSharedResourcesStack.CdkLayersNestedStack.layer_container,
<<<<<<< HEAD
=======
    policy_container=CdkSharedResourcesStack.CdkIamNestedStack.policy_container,
>>>>>>> 9378bd6418aa3a5e1971176f7c9b6cea9bf9ff96
) if STACK_ENV_CONF["CdkMonitoringStack"][ENV] else None

CdkDeployerStack = CdkDeployer(
    app,
    "CdkDeployer",
    synthesizer=handle_synthesizer_creation(),
    env=Environment(account=context["accountId"], region=context["region"]),
    role_container=CdkSharedResourcesStack.CdkIamNestedStack.role_container,
    kms_container=CdkSharedResourcesStack.CdkKmsNestedStack.kms_container,
    alias_container=CdkSharedResourcesStack.CdkKmsNestedStack.alias_container,
    ssm_container=CdkSharedResourcesStack.container["ssm"],
) if STACK_ENV_CONF["CdkDeployerStack"][ENV] else None

CdkNifiStatefulStack = CdkNifiStateful(
    app,
    "CdkNifiStateful",
    synthesizer=handle_synthesizer_creation(),
    env=Environment(account=context["accountId"], region=context["region"])
) if STACK_ENV_CONF["CdkNifiStatefulStack"][ENV] else None


CdkNifiStatelessStack = CdkNifiStateless(
    app,
    "CdkNifiStateless",
    synthesizer=handle_synthesizer_creation(),
    env=Environment(account=context["accountId"], region=context["region"]),
    subnet_container=CdkSharedResourcesStack.container["subnet"]
) if STACK_ENV_CONF["CdkNifiStatelessStack"][ENV] else None


CdkAmiFactoryStack = CdkAmiFactory(
    app,
    "CdkAmiFactory",
    synthesizer=handle_synthesizer_creation(),
    env=Environment(account=context["accountId"], region=context["region"]),
    bucket_platform_backend=CdkOrchestrationStatefulStack.bucket_container["platform-backend"],
    policy_container=CdkSharedResourcesStack.CdkIamNestedStack.policy_container,
    role_container=CdkSharedResourcesStack.CdkIamNestedStack.role_container,
    layer_container=CdkSharedResourcesStack.CdkLayersNestedStack.layer_container,
    ssm_container=CdkSharedResourcesStack.container["ssm"],
) if STACK_ENV_CONF["CdkAmiFactoryStack"][ENV] else None


CdkDevOpsStack = CdkDevOps(
    app,
    "CdkDevOps",
    synthesizer=handle_synthesizer_creation(),
    env=Environment(account=context["accountId"], region=context["region"]),
    ssm_container=CdkSharedResourcesStack.container["ssm"],
    policy_container=CdkSharedResourcesStack.CdkIamNestedStack.policy_container,
) if STACK_ENV_CONF["CdkDevOpsStack"][ENV] else None

app.synth()
